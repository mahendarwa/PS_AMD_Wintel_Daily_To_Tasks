$compList =(Get-Content "D:\Server.txt")
$D = @()
foreach ($computerName in $compList)
{
try
{
$objDisks = Get-WmiObject  -Class win32_logicaldisk -computername $computerName  | Where-Object { $_.DriveType -eq 3 }
ForEach( $disk in $objDisks )
  {
     $i = "" | select ServerName,DriveLetter,totalsizeinGB,FreeSpaceinGB
      $i.ServerName = $computerName
      $i.DriveLetter = $disk.DeviceID
      $i.totalsizeinGB = $([Math]::Round($disk.Size/1073741824,2))
      $i.FreeSpaceinGB = $([Math]::Round($disk.FreeSpace/1073741824,2))
      $D +=   $i 
     
  }
  } 
  
catch 
{
$msg="Computer Name: $computerName Error: $($_.Exception.Message )" 
$msg >> text.txt

}finally{"end"}
}  $D | Export-csv "D:\serverdiskspace_amd.csv"