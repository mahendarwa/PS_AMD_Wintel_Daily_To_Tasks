﻿Write-Host "  ===========Decommission Tool for Virtual Machines ================" -ForegroundColor Yellow
write-host "                                                                              "
Write-Host "Email 'Mahendar.sirarapu@amd.com' to report Bugs related to Decom Tool..." -ForegroundColor Cyan
write-host "                                                                              "
write-host "                                                                              "

do {$UserResponce = Read-Host "
Please select the desirable options from below...

Type 'D' for Decommissioning the server.
Press 'Q' to quit.
Type 'D' again for another server decommission.

"
Switch ($UserResponce)
{
D {
do 
{
     $s = read-host "Enter the SERVER NAME that needs to be decommissioned"
     if ($s -eq "atlvcsvm01" -or  $s -eq "atlvcs04" -or $s -eq "mkdcvcsvm01" -or $s -eq "cybvcsvm01" -or $s -eq "atlvcs02") 
     {   

write-warning "You have just entered vCenter server name instead decommission server name, please check agagin...!" 
     } else
     {
write-host "Alright, you need to decommission this server '$s'...!!!" -ForegroundColor Green
     } 
 }


 until ($s -ne "atlvcsvm01" -and $s -ne "atlvcs04" -and $s -ne "mkdcvcsvm01" -and $s -ne "cybvcsvm01" -and $s -ne "atlvcs02" )
 write-host "                                                                              "
 write-host "                                                                              "
 write-host "Enter your p1 credentials here, I.E amd\username and password...!" -ForegroundColor Cyan
 sleep 3
 $creden = Get-Credential
 write-host "                                                                              "

do {$hostname = Read-Host  "Enter the vCenter Name where server $s locates/resides in?"
if ($hostname -ne "atlvcsvm01" -and  $hostname -ne "atlvcs04" -and $hostname -ne "mkdcvcsvm01" -and $hostname -ne "cybvcsvm01" -and $hostname -ne "atlvcs02") {
write-warning "Appears to be, you have just entered wrong vCenter name, please try agagin...!" 
}  

else {
write-host "you have entered the vCenter name $hostname, proceeding further...!!!" -ForegroundColor Green 
     }
}

   until ($hostname -eq "atlvcsvm01" -or $hostname -eq "atlvcs04" -or $hostname -eq "mkdcvcsvm01" -or $hostname -eq "cybvcsvm01" -or $hostname -eq "atlvcs02" )


   If (-not (Get-PSSnapin VMware.VimAutomation.Core -ErrorAction SilentlyContinue))

    {
        Add-PSSnapin VMware.VimAutomation.Core > $null
    }

  #$hostname = 'atlvcsvm01','cybvcsvm01',mkdcvcsvm01'
  write-host "                                                     "
  $s2 = read-host "Enter the server name again that you need to decommission, just to cross varify"
  $s3 = $s -eq $s2
  $Cred = Connect-viserver -server $hostname -Credential $creden -warningaction 0 -ErrorAction Stop

  $Cred
  $s1 ="$s"+"_decom"
  $pathl = "C:\$s.txt"

  $testconnection =Test-Connection -ComputerName $s -Quiet -Count 1
  $testconnection1 = $testconnection -eq $true
  $domain =gwmi win32_computersystem -ComputerName $s |select domain  -ErrorAction SilentlyContinue
  $domain11 =$domain.domain
  $domain12 = $domain11 -match "amd*"
  
  
  $vm =get-vm -name $s
  $vm1 =$vm -ne $null

  
  if ($testconnection1 -and $domain12 -and $vm1 -and $s3)

  
    {

        write-host "

=========$s is reachable and

        Found in the vCenter of $hostname==========" -ForegroundColor Green
         write-host "                                     "
 
        Sleep 2

        write-warning "Are you sure that you want to decommission this $s...?"

        read-host " Press 'Enter' to proceed (or) 'CTRL+C' to stop/end the script"
        write-host "                                     "


        write-host " Proceeding with the decommissioning the server $s" -ForegroundColor Green

         write-host "--------------------------------------"
 write-host "                                     "

 #collecting OS Info
write-host "    Fetching '$s' OS info here..."  -fore Green
$operatingsystem =gwmi win32_operatingsystem -ComputerName $s |select caption
$operatingsystem1 =$operatingsystem.caption
#$operatingsystem12 = $operatingsystem1 -eq "Microsoft Windows 10 Home Single Language"

$s123 = $s + ' ' + '**' + $operatingsystem1 +'**'

$task = read-host "Enter the decommission reqeust number for $s" 
$IP =Get-WmiObject win32_networkadapterconfiguration -filter "ipenabled = 'True'" -ComputerName $s |select Ipaddress
$ip1 =$IP.Ipaddress

$userID =$env:USERNAME


$operatingsystem =gwmi win32_operatingsystem -ComputerName $s |select caption
$operatingsystem1 =$operatingsystem.caption

$domain = gwmi win32_computersystem -ComputerName $s -ErrorAction SilentlyContinue |select domain 
$domain11 =$domain.domain
write-host "
ServerName = $s 
OSinfo = $operatingsystem1
Domain Name = $domain11
IP Address = $ip1
User ID who's doing decommissioning this server = $userID
"  -fore Yellow

function write-message {

Write-Output "
ServerName = $s 
OSinfo = $operatingsystem1
Domain Name = $domain11
IP Address = $ip1
User ID, who's decommissioning this server = $userID
Decom request = $task
----------------------------------------------------

"
  } 
   
  function receive-text {
  
  process {Write-Host "received:$_"}
    }
     write-message |out-file $pathl -append

     write-host "                                     "

         write-host "--------------------------------------"


     #validates if Csosysadmin is present
     Sleep 3

     write-host "====validating, if the csosysadmin account is present on the $s=====" -ForegroundColor Green
     write-host "                                     "



     $name = Get-WmiObject -Query "Select * from Win32_UserAccount Where LocalAccount = 'True' AND Name='csosysadmin' " -ComputerName $S |  Select-Object -ExpandProperty Name -ErrorAction Stop

     if ($name -eq "csosysadmin")

   {

      Write-host "csosysadmin is present and proceeding with the password reset" -ForegroundColor Yellow

      #$userlist  = get-wmiobject win32_useraccount -ComputerName $s

      #$userlist[0].caption.replace(“\”,”/”)

      #[adsi]“WinNT://$s/csosysadmin”

      #([adsi]“WinNT://$s/csosysadmin”).SetPassword(“Z3N@md072017”)

      $admin=[adsi]("WinNT://" + $s + "/csosysadmin, user")

      $admin.psbase.invoke("SetPassword", "Z3N@md072017")

       function write-message

       {

          Write-Output "===csosysadmin is present already and have done reseting the passwored successfully==="

       }

      function receive-text

      {

        process {Write-Host "received:$_"}

      }
 
      write-message |out-file $pathl -append
        }
 
  else

  {

      Write-Host "Created a csosysadmin account as it was not present and done setting up the default password." -fore Yellow

      [ADSI]$server="WinNT://$s"

      $HelpDesk=$server.Create("User","csosysadmin")

      #$HelpDesk

      $HelpDesk.SetPassword("Z3N@md072017")

      $HelpDesk.SetInfo() |Out-Null

      [ADSI]$group="WinNT://$s/administrators,Group"

      $helpdesk.path |Out-Null

      $group.Add($helpdesk.path)

 
      function write-message {

       Write-Output "===csosysadmin is not present so a created it and done setting up the passwored successfully==="
      }

      function receive-text {

      process {Write-Host "received:$_"}

      }
 

      write-message |out-file $pathl -append

  }
   
          write-host "                                     "
         write-host "--------------------------------------"



#disabling the DHCP service 

    write-host "===checking, if DHCP service is running===" -ForegroundColor Green
    $dhcp=Get-Service Dhcp -ComputerName $s -ErrorAction SilentlyContinue
    $status11=$dhcp.Status
    If ($status11 -eq 'Running')
     {
     sleep 2
     write-host "                                              "
     Write-Host " Currently DHCP service is running, stopping the service now" -ForegroundColor Yellow

    Invoke-Command -ComputerName $s -ScriptBlock {
    Stop-Service Dhcp -Force -Verbose
    }
     function write-message

           {
             Write-Output "===Found the DHCP service was running state and it is now stopped successfully==="
           }
          function receive-text
          {
            process {Write-Host "received:$_"}
          }
                write-message |out-file $pathl -append
      }


     else   {
     write-host "DHCP service is already stopped." -ForegroundColor Yellow
     function write-message

           {
             Write-Output "===DHCP service is already stopped==="
           }
          function receive-text
          {
            process {Write-Host "received:$_"}
          }
                write-message |out-file $pathl -append
    }

             write-host "--------------------------------------"
             write-host "                                      "

  #removing it from the domain
Write-Host "====Removing the $s from the domain===" -fore Green

$domainr =Add-Computer -Credential $creden -WorkgroupName "wg" -ComputerName $s -Force -Confirm:$false -ErrorAction Stop |Out-Null

$doaminr

sleep 5


$domain =gwmi win32_computersystem -ComputerName $s |select domain  -ErrorAction SilentlyContinue

$domain1 =$domain.domain
 
$domain2 =$domain1 -contains "wg" -or $domain1 -contains "w"

 
if($domain2) 
{

     function write-message {

     Write-Output "===$s is sussessfully removed from the domain==="

      }

      function receive-text {

      process {Write-Host "received:$_"}

      }

 
      write-message |out-file $pathl -append

}

else

{

     function write-message {

     Write-Output "===Seems, the server was not removed from domain,please check manually==="

      }

      function receive-text {

      process {Write-Host "received:$_"}

      }

      write-message |out-file $pathl -append

}

           write-host "                                     "
         write-host "--------------------------------------"

 

sleep 3 
#removing the IP address

Write-Host "====Removing the $s's IP address====" -ForegroundColor  Green
          write-host "                                        "



$testconnection2 =Test-Connection -ComputerName $s -Quiet -Count 3
 $testconnection3 = $testconnection2 -eq $true
 
if ($testconnection3)

  {
  
$NICs = Get-WMIObject Win32_NetworkAdapterConfiguration -ComputerName $s `
|where{$_.IPEnabled -eq “TRUE”}  -ErrorAction SilentlyContinue

Foreach ($NIC in $NICs)

{

    $NIC.EnableDHCP() |Out-Null

    $NIC.SetDNSServerSearchOrder() |Out-Null

}

       function write-message {

     Write-Output "===$s servers IP address is removed==="

      }

      function receive-text {

      process {Write-Host "received:$_"}

      }
      
      write-message |out-file $pathl -append

  } else

{
    function write-message {

     Write-Output "===$s seems to be having some issue in removing the IP address, please check manually==="

      }

      function receive-text {

      process {Write-Host "received:$_"}

      }
       
      write-message |out-file $pathl -append

  }

           write-host "--------------------------------------"
         write-host "                                        "
 


# Renaming the VM name

write-host "====$s VM is getting renamed to $s1===="  -ForegroundColor Green
 Write-host "                                 "

Set-VM -VM $s -Name $s1 -Confirm:$false -Verbose |Out-Null
write-host "                                  "
Sleep 2

$rename = get-vm -name $s1

$rename1 =$rename -ne $null

if ($rename1)

{

      function write-message {

     Write-Output "===$s is now renamed to $s1 successfully==="
      }
      function receive-text {
      process {Write-Host "received:$_"}
      }
          write-message |out-file $pathl -append
} else
   {

function write-message {

     Write-Output "===Seems to be having some issue in renaming the VM name to $s1, please check manually==="

      }

      function receive-text {

      process {Write-Host "received:$_"}

      }
      write-message |out-file $pathl -append
    }

          write-host "--------------------------------------"
         write-host "                                      "



  #disabling the Network adepters at vCenter level

  Write-host "====Disconnecting the Network adepters at vCenter level for the $s====" -ForegroundColor Green

  $rename = get-vm -name $s1

$rename1 =$rename -ne $null

if ($rename)

{

  $Network_Adapter = Get-NetworkAdapter -VM $s1

  Set-NetworkAdapter  -NetworkAdapter $Network_Adapter -StartConnected:$false -Connected:$false -WakeOnLan:$false -Confirm:$false -Verbose |Out-Null
  
  function write-message {

Write-Output "===Network adepters of the VM $s got disconneted successfully at vCenter level==="

  }

  function receive-text {

  process {Write-Host "received:$_"}

  }
 
      write-message |out-file $pathl -append

  }

else {

function write-message {

Write-Output "===Seems having some issue in disconneting the Network adepters at vCenter , please check==="

  }

  function receive-text {

  process {Write-Host "received:$_"}

  }
 
      write-message |out-file $pathl -append
   
  }
 
         write-host "--------------------------------------"
         write-host "                                      "



  ## shutting down the server

Write-host "====shutting down the server $s====" -ForegroundColor Green
Stop-VM $s1 -Confirm:$false |Out-Null
        write-host "                                      "

 Sleep 5

$VMstate =Get-VM  $s1 |select PowerState

   $VMstate1 =$VMstate.PowerState

   if($VMstate1 -ne "PoweredOn") {
 
function write-message {

Write-Output "===$s is now powered off/shut down==="

  }

  function receive-text {

  process {Write-Host "received:$_"}

  }

      write-message |out-file $pathl -append

        }
 
else {

function write-message {

Write-Output "===$s seems having an issue in shutting down the server, please check==="

  }

  function receive-text {

  process {Write-Host "received:$_"}

  }

      write-message |out-file $pathl -append

  }

          write-host "--------------------------------------"
         write-host "                                       "



  ##removing AD Computer Object
 
 Write-host "====Removing the ADComputer object from AD====" -ForegroundColor Green

  Import-Module ActiveDirectory -Verbose:$false | Out-Null
  $adcomputer =Get-ADComputer $s -ErrorAction SilentlyContinue

$adcomputer1 = $adcomputer.Name -contains $S


if($adcomputer1) {

Get-ADComputer -Identity $s | Remove-ADObject -Recursive -ErrorAction SilentlyContinue -Verbose -Confirm:$false
Sleep 5
 function write-message {
 
Write-Output "====$s has been removed from AD successfully===="
         write-host "                                        "

  }

  function receive-text {

  process {Write-Host "received:$_"}

  }
       write-message |out-file $pathl -append

        }

else {

function write-message {

Write-Output "===$s seems having an issue in removing the AD object from AD, please check"

  }

  function receive-text {

  process {Write-Host "received:$_"}

  }
       write-message |out-file $pathl -append

  }
           write-host "--------------------------------------"
          write-host "                                       "

 #Dropping an email to the team... 

  $userresponse =read-host "Do you want to drop an email to respective teams redarding $s's decommission, Press (Y/N) "

 if ($userresponse -eq "Y" -or $userresponse -eq "y")
  {
  sleep 3
  write-host "Please wait, sending an email to the respective teams..."  -ForegroundColor Green
  $tolist = @("TCS_Windows_Admin@amd.com")
  $cclist=@("Pradeepkumar.Kumar@amd.com") #"TCS_Windows_Admin@amd.com"
  Send-MailMessage -SmtpServer aussmtp10.amd.com  -Cc $cclist -To $tolist -From "TCS_Windows_Admin@amd.com" -Subject "$s123 is decommissioned" -Body "Dear Team,
 '$s' has been decommissioned successfully, please update your records accordingly.
 And Please do acknowledge on this.


    Regards,
  Windows Team.

  " -attachment "$pathl"

  Write-host "                   Email has been sent to the respective team..." -ForegroundColor Green 
  function write-message {
 
Write-Output "====Email has been sent to respective team successfully===="

  }

  function receive-text {

  process {Write-Host "received:$_"}

  }
       write-message |out-file $pathl -append

   }
  
  else 
  {
   write-host "You have to notify the respective teams regarding the decommision of this $s server " -ForegroundColor Green
    function write-message {
 
Write-Output "====You have to notify the respective teams regarding the decommision of this $s server===="

  }

  function receive-text {

  process {Write-Host "received:$_"}

  }
       write-message |out-file $pathl -append

sleep 
   }
   
   
 sleep 3
 write-host "=====Please check, your output file is generated in the C:\$s.txt=====" -ForegroundColor Yellow
   write-host "                                                          "
    write-host "           ---------Thanks for using this script------------" -ForegroundColor Cyan 
        write-host "           ---------End---------" -ForegroundColor Cyan 


}
else{
Write-Host "

   Unable to run the script, could be due to below reasons....

   $s is not reachable (or)
   Seems, having an issue log in to the server with your P1 account (or)
   The second time entered server doesn't match with first time entered server (or)
   $s is not a VM that present in the $hostname vCenters, please check manually" -ForegroundColor Yellow
        write-host "           ---------End---------" -ForegroundColor Cyan 

function write-message {

Write-Output "===$s is not reachable or might not be present in the mentioned vCenter $hostname, please check"

  }

  function receive-text {

  process {Write-Host "received:$_"}

  }

      write-message |out-file $pathl -append

   } 
   ################End##########################3
 
}
Q { exit}
}
}
until ($UserResponce -eq "q" -or $UserResponce -eq "Q")