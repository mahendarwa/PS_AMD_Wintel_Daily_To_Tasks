﻿


$ServerName = Get-Content C:\Servers.txt


Foreach ($ServerName in $ServerName)`
{
$Class = gwmi win32_operatingsystem -ComputerName $Servername
$up = ($Class.ConvertToDateTime($Class.LocalDateTime)) - ($Class.ConvertToDateTime($Class.LastBootUpTime))
$output = "Uptime of $Servername, $($up.Days) Days, $($up.Hours) hrs, $($up.Minutes) Mins"
$output | Out-File C:\users -Append
}

