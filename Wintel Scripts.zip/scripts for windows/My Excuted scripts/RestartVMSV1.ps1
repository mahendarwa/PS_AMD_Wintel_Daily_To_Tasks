﻿ $Vcenter = Add-PSSnapIn VMware.VimAutomation.Core > $null
 $hostname = "atlvcsvm01" #,"atlvcs04" #,"cybvcsvm01","atlvcsvm01","atlvcs04","mkdcvcsvm01"
  write-host "Enter your p1 credentials here, I.E amd\username and password...!" -ForegroundColor Cyan
 $creden = Get-Credential
 $Cred = Connect-viserver -server $hostname -Credential $creden -warningaction 0 -ErrorAction Stop
 $Vcenter
 $Cred
 write-host "      "
 write-host "Connected to $hostname" -ForegroundColor Yellow
  write-host "----------------------------------"
 
$Computers = Get-Content "D:\Tcs_Windows_Team\Scripts\Mahendar\RestartVMs\serverslist.txt"
foreach($Computer in $Computers)
 {
  $vm =get-vm -name $Computer  -ErrorAction SilentlyContinue |select name,powerstate, guest
 $vm1 = $vm.PowerState
 $vm2 = $vm1 -ne "PoweredOn"
 $server = Get-vm -Name $Computer  -ErrorAction SilentlyContinue
 $server1 =$server.Name
 $server2 = $server1 -eq $Computer

 if ($vm2 -and $server2) {
  Start-VM -vm $Computer -Confirm:$false |Out-Null
  write-host " $computer is now powered On" -ForegroundColor Cyan
 
   }
 else {write-host " $computer is already poweredOn state or not found in $hostname." -ForegroundColor Cyan }

  }
    write-host "----------------------------------------"
   write-host "    "
  write-host "checking status of all the servers now...!"  -ForegroundColor Yellow
  write-host "See, the results D:\Tcs_Windows_Team\Scripts\Mahendar\RestartVMs..." -ForegroundColor Green

   $Computers = Get-Content "D:\Tcs_Windows_Team\Scripts\Mahendar\RestartVMs\serverslist.txt"
   $date = get-date -uformat “%Y_%m_%d_%I%M%p”
   $name=$date +'.csv'
foreach($Computer in $Computers)
 {
 try {
 $server = Get-vm -Name $Computer -ErrorAction stop
 $server1 =$server.Name 
 $vm23 = get-vm -name $Computer |select name,powerstate,guest
  $vm24 = $vm23.PowerState
  $vm25 = $vm23.guest
  $vm26 = $vm25.OSFullName

   $hash  = @{
  
 "serverName" = $Computer
 "PresentInvCenter" = "yes"
 "powerstate" = $vm24
 "OS" = $vm26

 } 
 
 }
 catch  {[System.Exception] "$Computer is not present in the Vcenter"
  $hash  = @{

  "serverName" = $Computer
 "PresentInvCenter" = "Not present in vCenter"
 "powerstate" = "NA"
 "OS" = "NA"
 }
 }

 finally {
 New-Object -TypeName psobject -Property $hash |select serverName,PresentInvCenter,powerstate,OS |Export-Csv "D:\Tcs_Windows_Team\Scripts\Mahendar\RestartVMs\$name" -NoTypeInformation -Append
 }
  }