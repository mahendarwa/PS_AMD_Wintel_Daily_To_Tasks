﻿$servers =Get-Content -Path "C:\Users\p1_msirarap\Desktop\serverslist.txt"
foreach ($server in $servers) {
    $testconnection =Test-Connection -ComputerName $server -Quiet
    if($testconnection -eq $true) {
            $pagefile =gwmi win32_pagefilesetting -ComputerName $server |Where-Object {$_.caption -match "c:"}
            $pagefile1 =gwmi win32_pagefilesetting -ComputerName $server |Where-Object {$_.caption -match "d:"} -ErrorAction SilentlyContinue
            $pagefile2 =gwmi win32_pagefilesetting -ComputerName $server |Where-Object {$_.caption -match "e:"} -ErrorAction SilentlyContinue
            $total =$pagefile.MaximumSize + $pagefile1.MaximumSize + $pagefile2.maximumsize
            $ram = gwmi win32_computersystem -ComputerName $server |Select-Object @{n="RAM";e={[int]($_.totalphysicalmemory /1mb)}}
            $ratio = $total /$ram.RAM
            $s =[math]::Round($ratio,1)
            $s
            $hash= @{
                "ServerName" = $server
                "PhysicalmeminMBs" =$ram.RAM
                "pagefilesizeinMBs" = $total
                "PagefiletoPhysialMem" =$s
                
                }
                $out = New-Object -TypeName psobject -Property $hash |Select-Object ServerName,PhysicalmeminMBs,pagefilesizeinMBs,PagefiletoPhysialMem
               $out |export-csv "C:\Users\p1_msirarap\Desktop\results\pagefileconf.csv" -NoTypeInformation -Append
               
        }else {
        
              $hash= @{
                "ServerName" = $server
                "PhysicalmeminMBs" ="Not reachable"
                "pagefilesizeinMBs" = "N/A"
                "PagefiletoPhysialMem" ="N/A"
                }
                 $out = New-Object -TypeName psobject -Property $hash |Select-Object ServerName,PhysicalmeminMBs,pagefilesizeinMBs,PagefiletoPhysialMem
               $out |export-csv "C:\Users\p1_msirarap\Desktop\results\pagefileconf.csv" -NoTypeInformation -Append
        }
    }
