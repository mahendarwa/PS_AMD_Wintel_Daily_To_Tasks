Remove-Computer -Force
$NICs = Get-WmiObject Win32_NetworkAdapterConfiguration | Where {$_.IPEnabled -eq �TRUE�}
foreach($NIC in $NICs) {$NIC.EnableDHCP(),$NIC.SetDNSServerSearchOrder()
}
Shutdown /s /t 02