﻿Write-Host "   =================================Server renaming=====================================" -ForegroundColor Yellow

write-host "        "
$s =read-host "Enter server name that needs to be renamed"
write-host "        "
write-host " Enter the p1 account Credentials here I.e, AMD\username "

$cred = Get-Credential

write-host "                                      "

write-host "Checking server's reachability..." -ForegroundColor Green
sleep 2
$testconnection = Test-Connection -ComputerName $s -Quiet -Count 1
$testconnection1 =$testconnection -eq $true

$domain = gwmi win32_computersystem -ComputerName $s -ErrorAction SilentlyContinue |select domain 
$domain11 =$domain.domain
$domain12 = $domain11 -match "amd*"

   write-host "                                      "
  
   $service =Get-Service -Name VMTools -ComputerName $s  -ErrorAction SilentlyContinue
   $service1 =$service -ne $null
   $service2 = $service -eq $null
   


if  ($testconnection1 -and $domain12 -and $service1)
{
write-host "$s reachable over the network and proceeding further...!" -ForegroundColor Yellow
write-host "--------------------------------------------------------"
write-host "                                      "
write-host "Checking, if it is a physical server or a virtual machine..." -ForegroundColor Green
write-host "                                      "

sleep 2
write-host "$s is found to be a virtual machine...!"  -ForegroundColor Yellow
write-host "--------------------------------------------------------"

sleep 3
write-host "                                      "
###
do {
$s1 =read-host "Enter the newname that you want to rename the '$s' server to...?"

Import-Module ActiveDirectory -Verbose:$false | Out-Null
$adcomputer = get-adcomputer -filter {name -eq $s1} -erroraction silentlycontinue
$adcomputer1 = $adcomputer.Name
write-host "                                      "


$s2 = $s1.Length
if ($s1.Length -le 15 -and $adcomputer1 -ne $s1 ) {
write-host "'$s1' is not present in the AD, and '$s1' is total no. of characters are equal to $s2, which is good to proceed...!" -ForegroundColor Green
write-host "--------------------------------------------------------"

write-host "                                      "

}  

else {
$s2 = $s1.Length
write-warning " Seems to be, $s1 is present is in the AD, if not...
The total characters of newname '$s1' is equal to '$s2'.... if it more than 15 characers then it is not allowed as computer name...!" 
write-host "--------------------------------------------------------"

}
}

until ($s1.Length -le 15 -and $adcomputer1 -ne $s1 )
###
  
     #validates if Csosysadmin is present
     Sleep 3

     write-host "====validating, if the csosysadmin account is present on the $s=====" -ForegroundColor Green
     write-host "                                     "



     $name = Get-WmiObject -Query "Select * from Win32_UserAccount Where LocalAccount = 'True' AND Name='csosysadmin' " -ComputerName $S |  Select-Object -ExpandProperty Name -ErrorAction Stop

     if ($name -eq "csosysadmin")

   {

      Write-host "csosysadmin is present and proceeding with the password reset..." -ForegroundColor Yellow

      #$userlist  = get-wmiobject win32_useraccount -ComputerName $s

      #$userlist[0].caption.replace(“\”,”/”)

      #[adsi]“WinNT://$s/csosysadmin”

      #([adsi]“WinNT://$s/csosysadmin”).SetPassword(“Z3N@md072017”)

      $admin=[adsi]("WinNT://" + $s + "/csosysadmin, user")

      $admin.psbase.invoke("SetPassword", "Bu11D0zer")

      Write-host "csosysadmin is present already and have done reseting the passwored successfully" -ForegroundColor Cyan

       
        }
 
  else

  {

      Write-Host "Created a csosysadmin account as it was not present and done setting up the default password." -fore Yellow

      [ADSI]$server="WinNT://$s"

      $HelpDesk=$server.Create("User","csosysadmin")

      #$HelpDesk

      $HelpDesk.SetPassword("Bu11D0zer")

      $HelpDesk.SetInfo() |Out-Null

      [ADSI]$group="WinNT://$s/administrators,Group"

      $helpdesk.path |Out-Null

      $group.Add($helpdesk.path)

             Write-host "===csosysadmin is not present so a created it and done setting up the passwored successfully==="


  }
   
          write-host "                                     "
         write-host "--------------------------------------"



####

       write-host "       =====$s is getting renamed at OS level=====" -ForegroundColor Green
       Rename-Computer -ComputerName $s -NewName $s1 -DomainCredential $Cred  -Verbose -Force -ErrorAction Stop
       write-host "    "
       write-host "--------------------------------------------------------"
       write-host "    "
       sleep 3
       write-host "       =====Rebooting the server $s====="  -ForegroundColor Green
       Restart-Computer -ComputerName $s -Force -verbose
       write-host "    "
       write-host "--------------------------------------------------------"
       write-host "    "
do {$hostname = Read-Host  "Enter the vCenter Name where server $s locates/resides in?"

if ($hostname -ne "atlvcsvm01" -and  $hostname -ne "atlvcs04" -and $hostname -ne "mkdcvcsvm01" -and $hostname -ne "cybvcsvm01" -and $hostname -ne "atlvcs02")
{
write-warning "Appears to be, you have just entered wrong vCenter name, please try agagin...!" 
       write-host "    "

} 

else {
write-host "you have enterd the vCenter name $hostname, proceeding further...!!!" -ForegroundColor green
           write-host "    "

     }

}
until ($hostname -eq "atlvcsvm01" -or $hostname -eq "atlvcs04" -or $hostname -eq "mkdcvcsvm01" -or $hostname -eq "cybvcsvm01" -and $hostname -ne "atlvcs02")


    If (-not (Get-PSSnapin VMware.VimAutomation.Core -ErrorAction SilentlyContinue))
      {

        Add-PSSnapin VMware.VimAutomation.Core > $null

      }

 
   $Cred = Connect-viserver -server $hostname -Credential $cred  -warningaction 0 -ErrorAction SilentlyContinue
   $Cred
      
write-host "====$s VM is getting renamed to $s1===="  -ForegroundColor Yellow
Write-host "                                 "
Set-VM -VM $s -Name $s1 -Confirm:$false -Verbose |Out-Null

sleep 4
$rename = get-vm -name $s1
$rename1 =$rename -eq $null
if ($rename1) {
write-warning  "Seems to be having some issue in renaming the VM name to $s1, please check manually..."
}
else {write-host " $s is got renamed to $s1 successfully"   -ForegroundColor Cyan }

write-host "--------------------------------------------------------"
write-host "                                  "
 


#Dropping an email to the team...
write-host "                                  "

$userresponse =read-host "Do you want to drop an email to respective teams redarding $s's decommission, Press (Y/N) "

if ($userresponse -eq "Y" -or $userresponse -eq "y")

  {

  sleep 3

  write-host "Please wait, sending an email to the respective team..."  -ForegroundColor Green

  $tolist = @("mahendar.sirarapu@amd.com","Pradeepkumar.Kumar@amd.com","Srinivas.Kutigante@amd.com")

  #$cclist=@() #"TCS_Windows_Admin@amd.com""Satishkumar.Maroju@amd.com""Pradeepkumar.Kumar@amd.com","Srinivas.Kutigante@amd.com"

  Send-MailMessage -SmtpServer aussmtp10.amd.com  -Cc $cclist -To $tolist -From "TCS_Windows_Admin@amd.com" -Subject "$s is renamed to $s1 (test mail)" -Body " Dear Teams,

 

  $s has been renamed to '$s1' please update your records accordingly.

  And Please do acknowledge on this.

 

 

  Regards,

  Windows Team."

 

  Write-host " Email has been sent to respective teams...!" -ForegroundColor Yellow
  write-host "You are done renaming the server $s to $s1, Thanks for using the script...!" -ForegroundColor Cyan
        write-host "--------------------------------------------------------"

  }

  else { 
         write-host "    "

  write-host "You have to notify the respective teams regarding the renaming of this $s server....! "  -ForegroundColor Yellow
    write-host "You are done renaming the server $s to $s1, Thanks for using the script...!" -ForegroundColor Cyan

       write-host "--------------------------------------------------------"
      
       }


######

   
   }    

     

############################
   elseif ($testconnection1 -and $domain12 -and $service2)
   {
   write-host "$s reachable over the network and proceeding further...!" -ForegroundColor Yellow
write-host "--------------------------------------------------------"
write-host "                                      "
write-host "Checking, if it is a physical server or virtual machine..." -ForegroundColor Green
sleep 3
 write-host "$s is found to be a physical server...!"  -ForegroundColor yellow
write-host "--------------------------------------------------------"
write-host "                                      "

 write-host "checking, if $s server has an ILo or DRAC configuration and reachability..." -ForegroundColor Green
 sleep 3
 $ping = $s+'-sp'
 $ping1 = $s+'-'+'ilo'

 $test = Test-Connection -ComputerName $ping -Quiet -Count 2
 $test1 = Test-Connection -ComputerName $ping1 -Quiet -Count 2


  if($test -or $test1) 
   {
   write-host "$s server's ILO is reachable with $ping (or) $ping1 and proceeding with the server renaming...!" -ForegroundColor Yellow
   write-host "--------------------------------------------------------"
   do {
   write-host "                                      "

$s1 =read-host "Enter the newname that you want to rename the '$s' server to...?"

Import-Module ActiveDirectory -Verbose:$false | Out-Null
$adcomputer = get-adcomputer -filter {name -eq $s1} -erroraction silentlycontinue
$adcomputer1 = $adcomputer.Name


$s2 = $s1.Length
if ($s1.Length -le 15 -and $adcomputer1 -ne $s1 ) {
write-host "'$s1' is not present in the AD, and '$s1' is total no. of characters are equal to '$s2', which is good to proceed...!" -ForegroundColor yellow
write-host "--------------------------------------------------------"


}  

else {
$s2 = $s1.Length
write-warning " Seems to be, $s1 is present is in the AD, if not
 The total characters of newname '$s1' is equal to '$s2'.... if newname's characters are more than 15 then it is not allowed as computer name...!" 
write-host "--------------------------------------------------------"

}
}

until ($s1.Length -le 15 -and $adcomputer1 -ne $s1 )
###
  write-host "                                     "


     #validates if Csosysadmin is present
     Sleep 3

     write-host "====validating, if the csosysadmin account is present on the $s=====" -ForegroundColor Green
     write-host "                                     "



     $name = Get-WmiObject -Query "Select * from Win32_UserAccount Where LocalAccount = 'True' AND Name='csosysadmin' " -ComputerName $S |  Select-Object -ExpandProperty Name -ErrorAction Stop

     if ($name -eq "csosysadmin")

   {

      Write-host "csosysadmin is present and proceeding with the password reset" -ForegroundColor Yellow

      #$userlist  = get-wmiobject win32_useraccount -ComputerName $s

      #$userlist[0].caption.replace(“\”,”/”)

      #[adsi]“WinNT://$s/csosysadmin”

      #([adsi]“WinNT://$s/csosysadmin”).SetPassword(“Z3N@md072017”)

      $admin=[adsi]("WinNT://" + $s + "/csosysadmin, user")

      $admin.psbase.invoke("SetPassword", "Z3N@md072017")

       Write-host "csosysadmin is present already and have done reseting the passwored successfully" -ForegroundColor Cyan

       
        }
 
  else

  {

      Write-Host "Created a csosysadmin account as it was not present and done setting up the default password." -fore Yellow

      [ADSI]$server="WinNT://$s"

      $HelpDesk=$server.Create("User","csosysadmin")

      #$HelpDesk

      $HelpDesk.SetPassword("Z3N@md072017")

      $HelpDesk.SetInfo() |Out-Null

      [ADSI]$group="WinNT://$s/administrators,Group"

      $helpdesk.path |Out-Null

      $group.Add($helpdesk.path)

             Write-host "csosysadmin is not present so a created it and done setting up the passwored successfully"


  }
   
          write-host "                                     "
         write-host "--------------------------------------"



   write-host "    "

       write-host "       =====$s is getting renamed at OS level=====" -ForegroundColor Green
       Rename-Computer -ComputerName $s -NewName $s1 -DomainCredential $cred -Verbose -Force -ErrorAction Stop
       write-host "    "
       write-host "--------------------------------------------------------"
       write-host "    "
       sleep 2
       write-host "       =====Rebooting the server $s====="  -ForegroundColor Green
       Restart-Computer -ComputerName $s -Force -verbose
       write-host "--------------------------------------------------------"
       write-host "    "
       
       write-warning "****please make a note, we need to change the ILO name accordingly to the '$s1'****"
       write-host "                                      "

       write-host "--------------------------------------------------------"

       sleep 3
       write-host "    "

   

   #Dropping an email to the team...
write-host "                                  "

$userresponse =read-host "Do you want to drop an email to respective teams redarding $s's decommission, Press (Y/N) "

if ($userresponse -eq "Y" -or $userresponse -eq "y")

  {

  sleep 3

  write-host "Please wait, sending an email to the respective team..."  -ForegroundColor Green

  $tolist = @("mahendar.sirarapu@amd.com","Pradeepkumar.Kumar@amd.com","Srinivas.Kutigante@amd.com")

  $cclist=@("TCS_Windows_Admin@amd.com")

  Send-MailMessage -SmtpServer aussmtp10.amd.com  -Cc $cclist -To $tolist -From "TCS_Windows_Admin@amd.com" -Subject "$s is renamed to $s1 (test mail)" -Body " Dear Teams,

 

  $s has been renamed to '$s1' please update your records accordingly.

  And Please do acknowledge on this.

 

 

  Regards,

  Windows Team."

 

  Write-host " Email has been sent to respective teams...!" -ForegroundColor Yellow
 write-host "--------------------------------------------------------"

  write-host "You are done renaming the server $s to $s1, Thanks for using the script...!" -ForegroundColor Cyan
        write-host "--------------------------------------------------------"

  }

  else { 
         write-host "    "

  write-host "You have to notify the respective teams regarding the renaming of this $s server....! "  -ForegroundColor Yellow
    write-host "You are done renaming the server $s to $s1, Thanks for using the script...!" -ForegroundColor Cyan

       write-host "--------------------------------------------------------"
      
       }
      
 }


###################################
 else { 
 write-warning " '$ping' and '$ping1' are not reachable. You need to check, if ILO/DRAC is configured or not for this server $s...!"
 write-host "--------------------------------------------------------"

   write-host "    " 

 $iLO =read-host "Do you still need to proceed with renaming the server without ILo, press (Y/N)"
 if ($iLO -eq "Y" -or $iLO -eq "y")
 {
       do {
       write-host "                                      "

$s1 =read-host "Enter the newname that you want to rename the '$s' server to...?"
###############################################################

Import-Module ActiveDirectory -Verbose:$false | Out-Null
$adcomputer = get-adcomputer -filter {name -eq $s1} -erroraction silentlycontinue
$adcomputer1 = $adcomputer.Name


$s2 = $s1.Length
if ($s1.Length -le 15 -and $adcomputer1 -ne $s1 ) {
write-host "'$s1' is not present in the AD, and '$s1' is total no. of characters are equal to '$s2', which is good to proceed...!" -ForegroundColor yellow
write-host "--------------------------------------------------------"


}  

else {
$s2 = $s1.Length
write-warning " Seems to be, $s1 is present is in the AD, if not
 The total characters of newname '$s1' is equal to '$s2'.... if newname's characters are more than 15 then it is not allowed as computer name...!" 
write-host "--------------------------------------------------------"

}
}

until ($s1.Length -le 15 -and $adcomputer1 -ne $s1 )
###

  write-host "                                     "


     #validates if Csosysadmin is present
     Sleep 3

     write-host "====validating, if the csosysadmin account is present on the $s=====" -ForegroundColor Green
     write-host "                                     "



     $name = Get-WmiObject -Query "Select * from Win32_UserAccount Where LocalAccount = 'True' AND Name='csosysadmin' " -ComputerName $S |  Select-Object -ExpandProperty Name -ErrorAction Stop

     if ($name -eq "csosysadmin")

   {

      Write-host "csosysadmin is present and proceeding with the password reset" -ForegroundColor Yellow

      #$userlist  = get-wmiobject win32_useraccount -ComputerName $s

      #$userlist[0].caption.replace(“\”,”/”)

      #[adsi]“WinNT://$s/csosysadmin”

      #([adsi]“WinNT://$s/csosysadmin”).SetPassword(“Z3N@md072017”)

      $admin=[adsi]("WinNT://" + $s + "/csosysadmin, user")

      $admin.psbase.invoke("SetPassword", "Z3N@md072017")

                Write-host "===csosysadmin is present already and have done reseting the passwored successfully==="

       
        }
 
  else

  {

      Write-Host "Created a csosysadmin account as it was not present and done setting up the default password." -fore Yellow

      [ADSI]$server="WinNT://$s"

      $HelpDesk=$server.Create("User","csosysadmin")

      #$HelpDesk

      $HelpDesk.SetPassword("Z3N@md072017")

      $HelpDesk.SetInfo() |Out-Null

      [ADSI]$group="WinNT://$s/administrators,Group"

      $helpdesk.path |Out-Null

      $group.Add($helpdesk.path)

             Write-host "===csosysadmin is not present so a created it and done setting up the passwored successfully==="


  }
   
          write-host "                                     "
         write-host "--------------------------------------"


   write-host "    "

       write-host "       =====$s is getting renamed at OS level=====" -ForegroundColor Green
       Rename-Computer -ComputerName $s -NewName $s1 -Verbose -Force -ErrorAction Stop
       write-host "    "
       write-host "--------------------------------------------------------"
       write-host "    "
       sleep 2
       write-host "       =====Rebooting the server $s====="  -ForegroundColor Green
       Restart-Computer -ComputerName $s -Force -verbose
       write-host "--------------------------------------------------------"
       write-host "    "
       
       write-warning "****please make a note, we need to change the ILO name accordingly to the '$s1'****"
       write-host "                                      "

       write-host "--------------------------------------------------------"

       sleep 3
       write-host "    "

   

  
   #Dropping an email to the team...
write-host "                                  "

$userresponse =read-host "Do you want to drop an email to respective teams redarding $s's decommission, Press (Y/N) "

if ($userresponse -eq "Y" -or $userresponse -eq "y")

  {

  sleep 3

  write-host "Please wait, sending an email to the respective team..."  -ForegroundColor Green

  $tolist = @("mahendar.sirarapu@amd.com","Pradeepkumar.Kumar@amd.com","Srinivas.Kutigante@amd.com")

  #$cclist=@() #"TCS_Windows_Admin@amd.com""Satishkumar.Maroju@amd.com"

  Send-MailMessage -SmtpServer aussmtp10.amd.com  -Cc $cclist -To $tolist -From "TCS_Windows_Admin@amd.com" -Subject "$s is renamed to $s1 (testing mail)" -Body " Dear Teams,

 

  $s has been renamed to '$s1' please update your records accordingly.

  And Please do acknowledge on this.

 

 

  Regards,

  Windows Team."

 

  Write-host " Email has been sent to respective teams...!" -ForegroundColor Yellow
 write-host "--------------------------------------------------------"

  write-host "You are done renaming the server $s to $s1, Thanks for using the script...!" -ForegroundColor Cyan
        write-host "--------------------------------------------------------"

  }

  else { 
         write-host "    "

  write-host "You have to notify the respective teams regarding the renaming of this $s server....! "  -ForegroundColor Yellow
   write-host "--------------------------------------------------------"
            write-host "    "

    write-host "You are done renaming the server $s to $s1, Thanks for using the script...!" -ForegroundColor Cyan
             write-host "    "

       write-host "--------------------------------------------------------"
      
       }
  ###############################################################################################################
  
 }
  else { 
  Sleep 2
    write-host "--------------------------------------------------------"

  write-host "stopping the script for now, please check and try again...!"  -ForegroundColor Cyan
  write-host "--------------------------------------------------------"

   }
   }
   }


 else
   {
   write-host "--------------------------------------------------------"
   
   write-host "               $s is not reachable (or)
               having an issue login in with your p1 credentials, please check manually...!"  -ForegroundColor Yellow
       
    }
