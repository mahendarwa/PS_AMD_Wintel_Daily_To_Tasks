﻿
    $Vcenter = Add-PSSnapIn VMware.VimAutomation.Core
    $hostname = 'atlvcsvm01','cybvcsvm01'
    $Cred = Connect-viserver -server $hostname -user amd\p1_msirarap -password mar@12345 
    $Vcenter
    $Cred 
    write-host "                                                                           "
    write-host "                                                                           "
    $s = 'atladminv01'
    $memory =get-vm -name $s |select Memorygb
    $memory