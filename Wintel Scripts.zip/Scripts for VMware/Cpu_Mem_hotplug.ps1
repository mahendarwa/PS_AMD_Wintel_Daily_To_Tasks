﻿$server = Read-Host "Enter the name of the vCenter"
$filename = Read-Host "Enter the name of the .csv file with the VM list"
Connect-VIServer $server
$outputfile1 = ".\$($server)_CPUnMemoryHotPlug-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$vms= Import-Csv .\$filename
Get-VM $vms.vmname | select Name,@{N="Memory Hot Add";E={$_.ExtensionData.Config.MemoryHotAddEnabled}},@{N="CPU HotAdd";E={$_.ExtensionData.Config.CpuHotAddEnabled}} | Export-Csv -NoTypeInformation $outputfile1
Disconnect-VIServer -Server $server -Confirm:$false -Force
