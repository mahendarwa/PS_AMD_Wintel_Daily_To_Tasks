﻿$server = Read-Host "Enter the name of the vCenter"
Connect-VIServer $server
Get-VMHostNetworkAdapter | select VMhost, Name, IP, SubnetMask, Mac, PortGroupName, vMotionEnabled, mtu, FullDuplex, BitRatePerSec | Export-Csv "F:\Yns\$($server)_VMHostNetworkDetails.csv"