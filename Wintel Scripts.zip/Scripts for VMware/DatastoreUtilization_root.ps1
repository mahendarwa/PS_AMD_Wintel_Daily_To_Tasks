﻿$cred = Get-Credential
$vmhosts=get-content F:\Yns\newhosts.txt
connect-viserver $vmhosts -Credential $cred
Get-VMHost $vmhosts | get-datastore | select Name,CapacityGB,FreeSpaceGB|Export-Csv -NoTypeInformation -Path F:\Yns\Datastoreutilization.csv
Disconnect-VIServer -Server * -Confirm:$false -Force:$true