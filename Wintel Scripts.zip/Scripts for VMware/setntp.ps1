﻿$viserver = Read-Host "Enter VI server"
Connect-VIServer $viserver
$hsts= get-content F:\Yns\hosts.txt
  Foreach ($hst in $hsts)  
{  
     
    Add-VmHostNtpServer -VMHost $hst -NtpServer atldns01  
    Add-VmHostNtpServer -VMHost $hst -NtpServer atldns02 
    Get-VmHostService -VMHost $hst | Where-Object {$_.key -eq "ntpd"} | ?{$_.Running -like "False"} | Start-VMHostService  
    Get-VmHostService -VMHost $hst | Where-Object {$_.key -eq "ntpd"} | Set-VMHostService -policy "on"  
} 

Disconnect-VIServer -Server $viserver -Confirm:$false -Force:$true