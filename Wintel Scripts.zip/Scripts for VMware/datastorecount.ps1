﻿Connect-VIServer atlvcsvm01
$hsts=Get-Content F:\Yns\hosts.txt
foreach($hst in $hsts)
{
$info=Get-VMHost $hst | Get-Datastore | ?{$_.type -eq "VMFS"} | select Name | Measure-Object
$info1=Get-VMHost $hst | Get-Datastore | ?{$_.type -eq "NFS"} | select Name | Measure-Object
$hst
$info.Count
$info1.Count
}