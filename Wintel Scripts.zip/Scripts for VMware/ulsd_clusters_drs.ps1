﻿Connect-VIServer cybvcsvm01
$dcs=Get-Datacenter
$AllInfo = @()
foreach ( $dc in $dcs)
{
$folders= get-datacenter $dc | Get-Folder ULSD*
$AllInfo1=@()
foreach($folder in $folders)
{
$cls=Get-Cluster -Location $folder | select *
$info="" | select Name,HAEnabled,DrsEnabled,Datacenter
$info.Name= $cls.Name
$info.HAEnabled= $cls.HAEnabled
$info.DrsEnabled= $cls.DrsEnabled
$info.Datacenter=$dc.Name
$AllInfo1+=$info
}
$AllInfo+=$AllInfo1

}

$AllInfo | Export-Csv F:\Yns\ULSD2.csv