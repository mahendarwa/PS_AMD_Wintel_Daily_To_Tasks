 Connect-VIServer atlesxi65-vm001.amd.com
#$esxHosts = Get-VMHost | Where { $_.PowerState -eq "PoweredOn" -and $_.ConnectionState -eq "Connected" } | Sort Name
 $esxHosts=Get-VMHost atlesxi65-vm001.amd.com
foreach($esx in $esxHosts) {
	 Add-VmHostNtpServer -VMHost $esx -NtpServer atldns01 
     Add-VmHostNtpServer -VMHost $esx -NtpServer atldns02
     Get-VmHostService -VMHost $esx | Where-Object {$_.key -eq "ntpd"} | ?{$_.Running -like "False"} | Start-VMHostService  
     Get-VmHostService -VMHost $esx | Where-Object {$_.key -eq "ntpd"} | Set-VMHostService -policy "on" 
	 Get-VmHostService -VMHost $esx | Where-Object {$_.key -eq "TSM"} | ?{$_.Running -like "True"} | Stop-VMHostService  
     Get-VmHostService -VMHost $esx | Where-Object {$_.key -eq "TSM"} | Set-VMHostService -policy "off" 
  	 #get-vmhost $esx | Set-VMHostSysLogServer -SysLogServer 'x.x.x.x' # Provide syslog server IP
	 (get-vmhost $esx | get-view).EnterLockdownMode()
	 Get-AdvancedSetting -Entity $esx -Name Config.HostAgent.plugins.solo.enableMob | Set-AdvancedSetting -Value 'false' -Confirm:$false  #disable Mob
     Get-AdvancedSetting -Entity $esx -Name Net.TcpipHeapSize | Set-AdvancedSetting -Value '32' -Confirm:$false   #Set TCPIP HeapSize
     Get-AdvancedSetting -Entity $esx -Name Net.TcpipHeapMax | Set-AdvancedSetting -Value '128' -Confirm:$false
     Get-AdvancedSetting -Entity $esx -Name NFS.MaxQueueDepth | Set-AdvancedSetting -Value '32' -Confirm:$false
     Get-AdvancedSetting -Entity $esx -Name NFS.MaxVolumes | Set-AdvancedSetting -Value '256' -Confirm:$false
	 Get-AdvancedSetting -Entity $esx -Name UserVars.ESXiShellInteractiveTimeOut | Set-AdvancedSetting -Value '900' -Confirm:$false
	 Get-AdvancedSetting -Entity $esx -Name UserVars.ESXiShellTimeOut | Set-AdvancedSetting -Value '900' -Confirm:$false
	 Get-AdvancedSetting -Entity $esx -Name Mem.ShareForceSalting | Set-AdvancedSetting -Value '2' -Confirm:$false
	 Get-AdvancedSetting -Entity $esx -Name UserVars.DcuiTimeOut | Set-AdvancedSetting -Value '600' -Confirm:$false
	 Get-AdvancedSetting -Entity $esx -Name Security.AccountLockFailures | Set-AdvancedSetting -Value '3' -Confirm:$false
	 Get-AdvancedSetting -Entity $esx -Name Security.AccountUnlockTime | Set-AdvancedSetting -Value '900' -Confirm:$false
	 Get-AdvancedSetting -Entity $esx -Name Security.PasswordQualityControl | Set-AdvancedSetting -Value "retry=3 min=disabled,disabled,disabled,7,7"
	 Get-AdvancedSetting -Entity $esx -Name UserVars.ESXiVPsDisabledProtocols | Set-AdvancedSetting -Value 'tlsv1,tlsv1.1' -Confirm:$false
	 
 }