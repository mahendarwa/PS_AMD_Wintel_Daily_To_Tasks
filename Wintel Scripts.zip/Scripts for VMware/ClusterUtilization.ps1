﻿$vcServer = Read-Host "Please enter the name of the vCenter server"
Connect-VIServer -Server $vcServer 
$clstr = Read-Host "Please enter the name of the cluster"
$outputfile = ".\$vcenter-clusters_stats-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$vmhosts=Get-Cluster $clstr | Get-VMHost
$info=foreach($vmhst in $vmhosts)
{
Get-VMHost $vmhst | select Parent,Name,@{N="CPU Utilization";E={[int](($_.CpuUsageMhz/$_.CpuTotalMhz)*100)}},@{N="MemoryUtilization";E={[int](($_.MemoryUsageGB/$_.MemoryTotalGB)*100)}}
}

$info | Export-Csv -NoTypeInformation -Path $outputfile