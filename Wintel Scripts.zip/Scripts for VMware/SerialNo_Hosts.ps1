﻿# to get serial no of the hosts
Connect-VIServer atlvcs02
New-VIProperty -ObjectType VMHost -Name SerialNumber -Value { (Get-EsxCli -VMHost $Args[0]).hardware.platform.get().SerialNumber }
get-cluster ODC-05 | Get-VMHost  | Select Name,Manufacturer,Model,SerialNumber | Export-Csv -NoTypeInformation C:\Yns\ODC05.csv