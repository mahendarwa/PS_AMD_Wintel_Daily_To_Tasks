﻿"SET RR policy commands to switch path to 1 for Xtreme IO LUNS for all hosts in VC"
$viserver = Read-Host "Enter vCenter Name"
Connect-VIServer $viserver
$dt= get-date -Format yyyy-MM-dd-HHmm
#Get-VMHost | ?{$_.ConnectionState -like "Connected" -or "Maintenance"  } | Get-ScsiLun -LunType disk | ?{$_.Vendor -like "XtremIO" -and $_.MultipathPolicy -like "RoundRobin" -and $_.CommandsToSwitchPath -ne 1} | Export-Csv F:\Yns\XIO_RR_cmd_swtichpath_$($dt).csv
Get-VMHost | ?{$_.ConnectionState -like "Connected" -or "Maintenance"  } | Get-ScsiLun -LunType disk | ?{$_.Vendor -like "XtremIO" -and $_.MultipathPolicy -like "RoundRobin" -and $_.CommandsToSwitchPath -ne 1} | Set-ScsiLun -CommandsToSwitchPath 1 | Export-Csv F:\Yns\XIO_RR_cmd_swtichpath_$($dt).csv
Disconnect-VIServer -Server $viserver -Confirm:$false