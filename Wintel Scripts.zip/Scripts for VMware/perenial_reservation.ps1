﻿Connect-VIServer atlvcsvm01
$esxHosts= get-cluster dev-win-g10 | Get-VMHost 
foreach($esx in $esxHosts) 
{
$myesxcli= get-esxcli -VMHost $esx
$myesxcli.storage.core.device.setconfig($false, "naa.60002ac00000000001005cda00003d7c", $true)
$myesxcli.storage.core.device.list("naa.60002ac00000000001005cda00003d7c")
$myesxcli.storage.core.device.setconfig($false, "naa.60002ac00000000001005cdb00003d7c", $true)
$myesxcli.storage.core.device.list("naa.60002ac00000000001005cdb00003d7c")
$myesxcli.storage.core.device.setconfig($false, "naa.60002ac00000000001007efb00003d7c", $true)
$myesxcli.storage.core.device.list("naa.60002ac00000000001007efb00003d7c")
}

