﻿Connect-VIServer cybvcsvm01
$xy= Get-Content F:\Yns\vms.txt
$vms= get-vm $xy

$AllInfo = @()
foreach ($vm in $vms)
{
 $AllInfo1 =@()
 $hdds= Get-HardDisk -VM $vm
foreach ($hd in $hdds )
{
$Info = "" | Select Name,VMhost,Harddisk,Path,Datastore,NAAID,Vendor
$Info.Name= $vm.name
$Info.VMhost= $vm.vmhost
$Info.Harddisk = $hd.name
$Info.Path = $hd.filename
$string=$hd.filename
$ds = [system.String]($string.split("[")[1])
$Info.Datastore= [system.String]($ds.split("]")[0]).trim()
$na= get-datastore -name $Info.Datastore
$Info.NAAID= $na.ExtensionData.Info.Vmfs.Extent[0].DiskName
$ve= Get-ScsiLun -CanonicalName $Info.NAAID -VmHost $Info.VMhost | select Vendor
$Info.Vendor= $ve.Vendor

$AllInfo1 += $Info
}


$AllInfo += $AllInfo1

}


$AllInfo | Export-Csv -NoTypeInformation F:\Yns\CYB_disconsolidate_vms.csv

