﻿Connect-VIServer atlvcsvm01
#$vmis=Get-Content F:\Yns\vms.txt
$vms=Get-Cluster SQL-PRD | get-vm
$info=foreach($vm in $vms){

    foreach($nic in Get-NetworkAdapter -VM $vm){

        Get-VirtualPortGroup -Name $nic.NetworkName -VM $vm |

        Select @{N='VM';E={$vm.Name}},

            @{N='vNIC';E={$nic.Name}},
			 
			@{N='MacAddress';E={$nic.MacAddress}},

            @{N='IP';E={($vm.Guest.Nics | where{$_.NetworkName -eq $nic.NetworkName}).IPAddress -join ','}},

            @{N='Portgroup';E={$_.Name}},

            @{N='VLANId';E={

                if($_ -is [VMware.VimAutomation.ViCore.Types.V1.Host.Networking.DistributedPortGroup]){

                    if($_.ExtensionData.Config.DefaultPortConfig.Vlan -is [VMware.Vim.VmwareDistributedVirtualSwitchPvlanSpec]){

                        $_.ExtensionData.Config.DefaultPortConfig.Vlan.PvlanId

                    }

                    elseif($_.ExtensionData.Config.DefaultPortConfig.Vlan -is [VMware.Vim.VmwareDistributedVirtualSwitchVlanSpec]){

                        if($_.ExtensionData.Config.DefaultPortConfig.Vlan.VlanId -is [VMware.Vim.NumericRange[]]){

                            [string]::Join(',',($_.ExtensionData.Config.DefaultPortConfig.Vlan.VlanId | %{"$($_.Start)-$($_.End)"}))

                        }

                        else{

                            $_.ExtensionData.Config.DefaultPortConfig.Vlan.VlanId

                        }

                    }

                }

                else{$_.VlanId}}},

            @{N='VLAN Type';E={

                if($_ -is [VMware.VimAutomation.ViCore.Impl.V1.Host.Networking.DistributedPortGroupImpl]){

                    switch($_.ExtensionData.Config.DefaultPortConfig.Vlan.GetType().Name){

                        'VmwareDistributedVirtualSwitchPvlanSpec' {'PvLAN'}

                        'VmwareDistributedVirtualSwitchVlanIdSpec' {'VLAN'}

                        'VmwareDistributedVirtualSwitchTrunkVlanSpec' {'VLAN Trunking'}

                        Default {'None'}

                    }

                }

                else{          

                    $_.ExtensionData.GetType().Name

                }}},

            @{N='SwitchType';E={

                if($_ -is [VMware.VimAutomation.ViCore.Impl.V1.Host.Networking.DistributedPortGroupImpl]){

                    'VDS'

                }

                else{'VSS'}}}

    }

}
$info | Export-Csv F:\Yns\SQL_migration_network.csv -NoTypeInformation