﻿$viserver = Read-Host "Enter VI server"
Connect-VIServer $viserver
$dt= get-date -Format yyyy-MM-dd-HHmm
$output="F:\Yns\scripts\output\$($viserver)_PowerPolicy_$($dt).csv"
$hsts= Get-VMHost
$info=foreach($hst in $hsts)
{
Get-VMHost $hst | Sort | Select Name,@{ N="CurrentPolicy"; E={$_.ExtensionData.config.PowerSystemInfo.CurrentPolicy.ShortName}},@{ N="CurrentPolicyKey"; E={$_.ExtensionData.config.PowerSystemInfo.CurrentPolicy.Key}},@{ N="AvailablePolicies"; E={$_.ExtensionData.config.PowerSystemCapability.AvailablePolicy.ShortName}}
}
$info | Export-Csv -Path $output