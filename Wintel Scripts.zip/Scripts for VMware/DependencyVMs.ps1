﻿$server = Read-Host "Enter the name of the vCenter"
Connect-VIServer $server
$clstr = Read-Host "Enter the name of the Cluster to check RDM and scsi dependency"
$outputfile1 = ".\$($clstr)_SCSI_Dependency-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$outputfile2 = ".\$($clstr)-RDM_Dependency-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
#Check for scsi controller sharing
 Get-Cluster $clstr | Get-VM | Get-ScsiController | ?{$_.BussharingMode -notlike "NoSharing"} | select parent,@{N="VMhost";E={$_.parent.vmhost}},BusSharingMode | Export-Csv -NoTypeInformation -Path $outputfile1
#check for RDM VMs
Get-Cluster $clstr | Get-VM | Get-HardDisk -DiskType RawPhysical,RawVirtual | select Parent,Name,@{N="VMhost";E={$_.parent.vmhost}} | Export-Csv -NoTypeInformation -Path $outputfile2
Disconnect-VIServer -Server $server -Confirm:$false -Force:$true