﻿#$vcenter = "atlvcsvm01.amd.com,atlvcs02.amd.com,atlvcs04.amd.com,atlvcsgrid.amd.com,atlvcsleo01.amd.com"
$csvfile = "F:\Yns\penaangesxrk.csv"
#========================================================================
# Load the VMware Snapin (for PowerShell only)
# Test to make sure plink.exe is present in the same directory as the script. If not, throw an error.
if (!(Test-Path ".\plink.exe")) {Throw "Plink.exe is not available in the script folder. Please download from http://www.chiark.greenend.org.uk/~sgtatham/putty/download.html"}

# Create the array that will be used to display information. This makes it easier to assemble each line of the CSV.
$output = New-Object System.Collections.ArrayList

# Check to see if the CSV file exists, if it does then overwrite it.
if (Test-Path $csvfile) {
Write-Host "Overwriting $csvfile"
del $csvfile
}

# Create the CSV title header
Add-Content $csvfile "Host Name,Host Model,Product ID"

# Connect to vCenter
Write-Host "Connecting to vCenter..."
#Connect-VIServer atlvcs04.amd.com, cybvcsvm01.amd.com, cybvcs02.amd.com, cybvcsview01.amd.com, mkdcvcsvm01.amd.com, mkdcvcs02.amd.com, atlvcsvm01.amd.com,atlvcs02.amd.com, atlvcs04.amd.com, atlvcsleo01.amd.com
Write-Host "Connected"
Write-Host " "

# Collect login information to SSH to each host. The last two lines just convert the string from secure to plain text for plink.exe to use
$user = Read-Host "ESXi Host SSH User"
$rootpword = Read-Host "ESXi Host SSH Password" -AsSecureString
$rootbstr = [System.Runtime.InteropServices.marshal]::SecureStringToBSTR($rootpword)
$rootpword = [System.Runtime.InteropServices.marshal]::PtrToStringAuto($rootbstr)
#$pwd1="E$Xr0ck5"
#$pwd2="P/\55w0rd"
#$pwd3="Nas1Lemak"
#$pwd4="P@55w0rd"
#$pwd5="Ev3R6rE3n"
#$pwd6="amd@123"
# Get the host inventory from vCenter
$vhosts = get-content F:\Yns\hosts.txt
$vmhosts = Get-VMHost $vhosts

foreach ($vmhost in $vmhosts){

# Check to see if the SSH service is running on the host, if it isn't, start it
$sshservice = Get-VMHost $vmhost | Get-VMHostService | Where-Object {$_.Key -eq "TSM-SSH"}
if (!$sshservice.Running) {Start-VMHostService -HostService $sshservice -Confirm:$false | Out-Null}

# Often times plink will throw a message that the server's key is not cached in the registry when connecting to a host for the first time. The echo y command automatically accepts the key.
echo y | .\plink.exe -ssh $vmhost -l $user -pw $rootpword exit | Out-Null
#echo y | .\plink.exe -ssh $vmhost -l $user -pw $pwd2 exit | Out-Null
#echo y | .\plink.exe -ssh $vmhost -l $user -pw $pwd3 exit | Out-Null
#echo y | .\plink.exe -ssh $vmhost -l $user -pw $pwd4 exit | Out-Null
#echo y | .\plink.exe -ssh $vmhost -l $user -pw $pwd5 exit | Out-Null
#echo y | .\plink.exe -ssh $vmhost -l $user -pw $pwd6 exit | Out-Null

# smbiosDump is full of great information, here we're using it to collect model and bios information
$hostmodel = .\plink.exe -ssh $vmhost -l $user -pw $rootpword -batch "smbiosDump | grep -i Product:"
#if(!$hostmodel){$hostmodel = .\plink.exe -ssh $vmhost -l $user -pw $pwd5 -batch "smbiosDump | grep -i Product:"}
$hostProductID= .\plink.exe -ssh $vmhost -l $user -pw $rootpword -batch "smbiosDump | grep -i 'Product ID:'"
#if(!$hostProductID){$hostProductID=.\plink.exe -ssh $vmhost -l $user -pw $pwd5 -batch "smbiosDump | grep -i 'Product ID:'"}
#if(!$hostProductID){$hostProductID=.\plink.exe -ssh $vmhost -l $user -pw $pwd3 -batch "smbiosDump | grep -i 'Product ID:'"}
#if(!$hostProductID){$hostProductID=.\plink.exe -ssh $vmhost -l $user -pw $pwd4 -batch "smbiosDump | grep -i 'Product ID:'"}
#if(!$hostProductID){$hostProductID=.\plink.exe -ssh $vmhost -l $user -pw $pwd5 -batch "smbiosDump | grep -i 'Product ID:'"}
#if(!$hostProductID){$hostProductID=.\plink.exe -ssh $vmhost -l $user -pw $pwd6 -batch "smbiosDump | grep -i 'Product ID:'"}
# Build the array with all the information we collected
$output.Add($vmhost.Name) | Out-Null
$output.Add($hostmodel.split(":", 2)[1].split('"',3)[1].trim()) | Out-Null
$output.Add($hostProductID.split(":")[1].trim()) | Out-Null


# Assemble the information into CSV format and append it to the CSV file. There's probably an easier way to do this, but it works!
$csvline = $output[0] + "," + $output[1] + "," + $output[2] 
Add-Content $csvfile $csvline

# Display all the information we collected in a readable format
Write-Host ""
Write-Host "Hostname:" $output[0] -ForegroundColor "Green"
Write-Host "Host Model:" $output[1]
Write-Host "Product ID:" $output[2] 
Write-Host "----------------------------------"

# Clean up the array for the next host
$output.Clear()
}