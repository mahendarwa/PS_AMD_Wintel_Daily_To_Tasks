﻿Connect-VIServer atlvcsleo01
$vmhs = Get-Cluster Leostream_NX4_02,Leostream_NX4_06 |Get-VMHost
$info=foreach ($vmh in $vmhs)
{
Get-VMHost $vmh | Where-Object {$_.ConnectionState -eq "Connected"} |
%{Get-View $_.ID} |
%{$esxname = $_.Name; Get-View $_.ConfigManager.NetworkSystem} |
%{ foreach($physnic in $_.NetworkInfo.Pnic){
    $pnicInfo = $_.QueryNetworkHint($physnic.Device)
    foreach($hint in $pnicInfo){
      Write-Host $esxname $physnic.Device
      if( $hint.ConnectedSwitchPort ) {
        $hint.ConnectedSwitchPort
      }
      else {
        Write-Host "No CDP information available."; Write-Host
      }
    }
  }
} 
}
$info | Export-Csv -NoTypeInformation F:\Yns\Leostream_NX4_02.csv