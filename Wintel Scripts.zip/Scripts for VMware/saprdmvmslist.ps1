﻿#List RDMS in Cluster

Connect-VIServer atlvcsvm01
$hosts = get-cluster SAP-PRD_CI01 | get-vmhost

$info=foreach($hst in $hosts)
{
 $vms= Get-VMHost $hst | Get-VM
  foreach ($vm in $vms)
     {
         $harddisks = get-harddisk -vm $vm -DiskType RawPhysical,RawVirtual

           foreach($harddisk in $harddisks)
             {
			 
		    get-scsilun -VMhost $hst -canonicalName $harddisk.ScsiCanonicalName | select VMHost, CanonicalName, CapacityGB, MultipathPolicy, LunType, @{N="VMName"; E={$vm}}
			}
	}
	
}
$info | Export-Csv F:\Yns\sqptest.csv