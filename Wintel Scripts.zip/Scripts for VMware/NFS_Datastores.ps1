﻿$viserver = Read-Host "Enter VI server"
Connect-VIServer $viserver
get-datacenter Cyberjaya |Get-Datastore | ?{$_.type -eq "NFS"} | select Name, @{N="NFSFiler"; E={[String]$_.RemoteHost}}, RemotePath, CapacityGB, FreespaceGB | Export-Csv "F:\Yns\$($viserver)_nfs.csv"
Disconnect-VIServer -Server $viserver -Confirm:$false