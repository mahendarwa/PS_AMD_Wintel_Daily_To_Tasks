﻿$vmhosts = Get-VMHost | ?{$_.ConnectionState -like "Connected" -or "Maintenance" } |Sort Name
$dt=get-date -Format yyyy-MM-dd-HHmm
$AllInfo = @()
foreach ($vmhost in $vmhosts)
{
$device = Get-VMHost $vmhost | get-VMHostPciDevice | where { $_.DeviceClass -eq "NetworkController"} | Select-Object -First 1

  # Ignore USB Controller
  if ($device.DeviceName -like "*USB*" -or $device.DeviceName -like "*iLO*" -or $device.DeviceName -like "*iDRAC*") {
    continue
  }
  $Info = "" | Select VMHost,Manufacturer,Model,BiosVersion,BiosReleaseDate,OSversion, Device, DeviceName, VendorName,  Driver, DriverVersion, FirmwareVersion, lpfcVersion,  Cluster
  $Info.VMHost = $device.VMHost.Name
  $Info.Manufacturer = $device.VMHost.Manufacturer
  $Info.Model = $device.VMHost.Model
  $Info.Cluster = $device.VMHost.parent
   $Info.DeviceName = $device.DeviceName
  $Info.VendorName = $device.VendorName
  $view= Get-View -ViewType HostSystem -Filter @{Name=$device.VMHost.Name} 
  $info.BiosVersion = $view.Hardware.BiosInfo.BiosVersion
  $info.BiosReleaseDate = $view.Hardware.BiosInfo.releaseDate
  $info.OSVersion = $view.Summary.Config.Product.FullName
  
       # Get NIC list to identify vmnicX from PCI slot Id
      $esxcli = $device.VMHost | Get-EsxCli -V2
      $niclist = $esxcli.network.nic.list.Invoke();
      $vmnicId = $niclist | where { $_.PCIDevice -like '*'+$device.Id} | select -First 1
      $Info.Device = $vmnicId.Name
      
      # Get NIC driver and firmware information
      Write-Debug "Processing $($Info.VMHost.Name) $($Info.Device) $($Info.DeviceName)"
      if ($vmnicId.Name){      
        $vmnicDetail = $esxcli.network.nic.get.Invoke(@{nicname = $vmnicId.Name})
        $Info.Driver = $vmnicDetail.DriverInfo.Driver
        $Info.DriverVersion = $vmnicDetail.DriverInfo.Version
        $Info.FirmwareVersion = $vmnicDetail.DriverInfo.FirmwareVersion
		# get lpfc version
		 Try{
        $lpfVib = $esxcli.software.vib.get.Invoke(@{vibname = "lpfc"})
      }Catch{
        $lpfVib = $esxcli.software.vib.get.Invoke(@{vibname = "lpfc"})
      }
      $Info.lpfcVersion = $lpfVib.Version
	  # get smx version
	        }
    
     
      	 Write-Host $info
    
    $AllInfo += $Info
  
}


# Export to CSV
$AllInfo |Export-Csv -NoTypeInformation "F:\Yns\driverinfo_$($dt).csv"
