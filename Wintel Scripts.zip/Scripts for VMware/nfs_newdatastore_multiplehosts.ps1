﻿$viserver = Read-Host "Enter VI server"
Connect-VIServer $viserver
$filename = Read-Host "Enter the name of the .csv file with the with nfs server details"
$nfsvols = Import-Csv .\$filename
$hostnames = Get-Content F:\Yns\scripts\hostlist.txt
$hsts=get-vmhost $hostnames
foreach($hst in $hsts)
{
foreach($nfsvol in $nfsvols)
{
New-Datastore -Nfs -VMHost $hst -Name $nfsvol.DSName -Path $nfsvol.nfsvolume -NfsHost $nfsvol.nfsserver

}
}
Disconnect-VIServer -Server $viserver -Confirm:$false