﻿Connect-VIServer atlvcsvm01
$nfsds=Get-Datastore | ?{$_.Type -eq "VMFS"}
$AllInfo = @()
foreach($ds in $nfsds)
{
$Info = Get-Datastore $ds | Get-VM | select Name,@{N="Datastore";E={$ds}}
$Info
$AllInfo+=$Info
}
$AllInfo | Export-Csv F:\Yns\VMFSvmlist.csv -NoTypeInformation
Disconnect-VIServer -Server atlvcsvm01 -Confirm:$false