﻿Connect-VIServer atlvcsleo01
#$vmhs = Get-Cluster Leostream_NX4_02,Leostream_NX4_06 |Get-VMHost
$cluster = Get-Cluster -Name Leostream_NX4_02,Leostream_NX4_06

foreach($esx in Get-VMHost -State Connected -Location $cluster){

  $netSys =  Get-View -Id $esx.ExtensionData.ConfigManager.NetworkSystem

  $esxcli = Get-EsxCli -VMHost $esx

  foreach($vds in Get-VDSwitch -VMHost $esx){

    foreach($pnic in ($esxcli.network.vswitch.dvs.vmware.list($vds.Name) | Select -ExpandProperty Uplinks)){

      $netSys.QueryNetworkHint($pnic) |

      Select @{N='Cluster';E={$cluster.Name}},

        @{N='VMHost';E={$esx.Name}},

        @{N='VDS';E={$vds.Name}},

        @{n='pNIC';E={$pnic}},

        @{N='MgmtIP';E={$_.LLDPInfo.Parameter | where{$_.Key -eq 'Management Address'} | Select -ExpandProperty Value}},

        @{N='PortDesc';E={$_.LLDPInfo.Parameter | where{$_.Key -eq 'Port Description' } | Select -ExpandProperty Value}},

        @{N='SysDesc';E={$_.LLDPInfo.Parameter | where{$_.Key -eq 'System Description' } | Select -ExpandProperty Value}},

        @{N='SysName';E={$_.LLDPInfo.Parameter | where{$_.Key -eq 'System Name' } | Select -ExpandProperty Value}}

    }

  }

}