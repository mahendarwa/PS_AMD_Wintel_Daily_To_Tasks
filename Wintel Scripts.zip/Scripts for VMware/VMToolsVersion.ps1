﻿Connect-VIServer atlvcsvm01
#$vms=Get-Content F:\Yns\vms.txt
$vms=Get-Cluster DEV-WIN-G10 | get-vm
Get-VM $vms | select Name,Version,@{N="ToolsVersion";E={$_.ExtensionData.Guest.ToolsVersion}},@{N="ToolsStatus";E={$_.ExtensionData.Guest.ToolsStatus}},@{N="ToolsRunningStatus";E={$_.ExtensionData.Guest.ToolsRunningStatus}} | Export-Csv F:\Yns\dev-win-g10_new.csv




