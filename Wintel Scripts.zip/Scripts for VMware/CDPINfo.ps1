﻿Connect-VIServer atlvcsleo01
$vmhs = Get-Cluster Leostream_NX4_02,Leostream_NX4_06 |Get-VMHost
$info=foreach ($vmh in $vmhs)
{
If ($vmh.State -ne "Connected") {
  Write-Output "Host $($vmh) state is not connected, skipping."
  }
Else {
  Get-View $vmh.ID | `
  % { $esxname = $_.Name; Get-View $_.ConfigManager.NetworkSystem} |
  % { foreach ($physnic in $_.NetworkInfo.Pnic) {
    $pnicInfo = $_.QueryNetworkHint($physnic.Device)
    foreach( $hint in $pnicInfo ){
      # Write-Host $esxname $physnic.Device
             if($hint.lldpinfo){ $hint.LldpInfo | select @{n="VMHost";e={$esxname}},@{n="VMNic";e={$physnic.Device}},ChassisID,PortId,@{N='MgmtIP';E={$hint.lldpinfo.Parameter | where{$_.Key -eq 'Management Address'} | Select -ExpandProperty Value}}}
             #if( $hint.LldpInfo){$hint.lldpinfo | select * }
      }
    }
  }
}
}
$info | Export-Csv -NoTypeInformation F:\Yns\Leostream_NX4_02.csv