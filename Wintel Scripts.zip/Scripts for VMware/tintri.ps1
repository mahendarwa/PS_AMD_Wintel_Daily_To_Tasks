﻿	Connect-VIServer cybvcsvm01 -User vrc_sa
	$hsts=Get-Content F:\Yns\ulsdhosts.txt
	$vhosts= Get-VMHost -Name $hsts
		$AllInfo = @()
		foreach($vhost in $vhosts)
		{
		$tintrivib=$null
		$Info = "" | Select VMHost,TintriVersion,TintriVibName
	 $esxcli = get-esxcli -v2 -VMhost $vhost.Name
	 Try{
        $tintrivib = $esxcli.software.vib.get.Invoke(@{vibname = "vmware-esx-TintriVaaiNasPlugin"})
      }Catch{
        $tintrivib = $esxcli.software.vib.get.Invoke(@{vibname = "vmware-esx-TintriVaaiNasPlugin"})
      }
      $Info.VMhost=$vhost.Name
	  $Info.TintriVersion=$tintrivib.Version
	  $Info.TintriVibName=$tintrivib.Name
	  $Info
	  $AllInfo += $Info
	 	 	  
	  }
	  $AllInfo | Export-Csv F:\Yns\tintri.csv -NoTypeInformation