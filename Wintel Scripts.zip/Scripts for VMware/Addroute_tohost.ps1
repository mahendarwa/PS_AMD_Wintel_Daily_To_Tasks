﻿Connect-VIServer atlvcsvm01
$hsts=Get-Cluster SQL-PRD-G10 | get-vmhost
foreach($hst in $hsts)
{
$vmhostroute1=New-VMHostRoute -VMHost $hst -Destination 10.180.144.0 -Gateway 10.180.167.254 -PrefixLength 22
Set-VMHostRoute -VMHostRoute $vmhostroute1
}