$HostinCluster = $true
$viserver = Read-Host "Enter VI server"
$refhost = Read-Host "Enter Reference host server"

Connect-VIServer $viserver
$REFHOST = Get-VMHost $refhost
If ($HostinCluster) {
	$cluster = Read-Host "Enter Cluster that has new host servers"
	$NEWHosts = Get-Cluster $cluster | Get-VMHost | sort name
	foreach($nfs in (Get-VMhost $REFHOST | Get-Datastore | Where {$_.type -eq "NFS"} )){
	    [string]$remotePath = $nfs.extensiondata.info.nas.remotepath
	    [string]$remoteHost = $nfs.extensiondata.info.nas.remotehost
	    [string]$shareName = $nfs.Name
		
		Foreach ($NEWHost in $NEWHosts) {
		    If ((Get-VMHost $NEWHOST | Get-Datastore | Where {$_.Name -eq $shareName -and $_.type -eq "NFS"} -ErrorAction SilentlyContinue )-eq $null){
		        Write-Host "NFS mount $shareName doesn't exist on $($NEWHOST.name)" -fore Red
		        New-Datastore -Nfs -VMHost $NEWHost.name -Name $Sharename -Path $remotePath -NfsHost $remoteHost    | Out-Null
		    }
		}	
	}
}

Else {
	$NEWHOST = Read-Host "Enter new host name"
	$Newhost = Get-VMHost $NEWHost
	foreach($nfs in ($REFHOST | Get-Datastore | Where {$_.type -eq "NFS"} )){
	    [string]$remotePath = $nfs.extensiondata.info.nas.remotepath
	    [string]$remoteHost = $nfs.extensiondata.info.nas.remotehost
	    [string]$shareName = $nfs.Name
		
		If (($NEWHOST | Get-Datastore | Where {$_.Name -eq $shareName -and $_.type -eq "NFS"} -ErrorAction SilentlyContinue )-eq $null){
		    Write-Host "NFS mount $shareName doesn't exist on $($NEWHOST.name)" -fore Red
		    New-Datastore -Nfs -VMHost $NEWHost.name -Name $Sharename -Path $remotePath -NfsHost $remoteHost    | Out-Null
		}
	}
}
