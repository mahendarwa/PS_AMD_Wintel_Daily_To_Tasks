﻿#get-rdm VMs in VC
Connect-VIServer atlvcsvm01
Get-VM | Get-HardDisk -DiskType "RawPhysical","RawVirtual" | Select Parent,Name,DiskType,@{N="VMhost";E={$_.parent.VMhost}} | Export-Csv F:\Yns\sqlprd-rdvms.csv