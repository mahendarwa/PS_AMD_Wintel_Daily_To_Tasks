﻿Connect-VIServer atlvcsvm01
$nfsds=Get-Datastore | ?{$_.Type -eq "NFS"}
$AllInfo = @()
foreach($ds in $nfsds)
{
$Info = Get-Datastore $ds | Get-VM | select Name,Powerstate,@{N="Datastore";E={$ds}}
$Info
$AllInfo+=$Info
}
$AllInfo | Export-Csv F:\Yns\nfsvmlist.csv -NoTypeInformation
Disconnect-VIServer -Server atlvcsvm01 -Confirm:$false