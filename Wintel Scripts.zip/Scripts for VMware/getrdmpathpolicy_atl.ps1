﻿Import-Module -Name "C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Modules\VMware.VimAutomation.Core"
Add-PSSnapin -Name "C:\Program Files (x86)\VMware\Infrastructure\PowerCLI\Modules\VMware.VimAutomation.Core"
#List RDMS in Cluster
Connect-VIServer atlvcsvm01
$dt= get-date -Format yyyy-MM-dd-HHmm
$output="F:\Yns\$($viserver)_RDMList_$($dt).csv"
$hosts =  get-vmhost |?{$_.connectionstate -eq "connected" -or $_.connectionstate -eq "Maintenance" }
#$hosts = Get-VMHost atlesxi262.amd.com,atlesxi260.amd.com
$info=foreach($hst in $hosts)
{
 $vms= Get-VMHost $hst | Get-VM
  foreach ($vm in $vms)
     {
         $harddisks = get-harddisk -vm $vm -DiskType RawPhysical,RawVirtual

           foreach($harddisk in $harddisks)
             {
			 
		    get-scsilun -VMhost $hst -canonicalName $harddisk.ScsiCanonicalName | select VMHost, CanonicalName, CapacityGB, MultipathPolicy, LunType, @{N="VMName"; E={$vm}},@{N="Cluster";E={$_.VMhost.parent}}
			}
	}
	
}
$info | Export-Csv $output
Send-MailMessage -To "younus.mohammad@amd.com" -From "younus.mohammad@amd.com" -SMTPServer "atlsmtp10.amd.com" -Subject "RDM Path Policy" -Body "Attached RDM path policy report" -Attachments $output
Disconnect-VIServer -Server atlvcsvm01 -Confirm:$false -Force:$true