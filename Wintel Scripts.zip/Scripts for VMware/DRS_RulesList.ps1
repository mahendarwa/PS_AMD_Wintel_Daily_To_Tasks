﻿$server = Read-Host "Enter the name of the vCenter"
Connect-VIServer $server
#$clstr = Read-Host "Enter the name of the Cluster to check RDM and scsi dependency"
#$DRSRules = Get-Cluster PRD-WIN_SAN-00_G8 | Get-DrsRule 
$outputfile1 = ".\$($server)_DRSRules-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$DRSRules = Get-Cluster | Get-DrsRule -Type VMHostAffinity,VMAffinity,VMAntiAffinity
 
$Results = ForEach ($DRSRule in $DRSRules)
     {
    "" | Select-Object -Property @{N="Cluster";E={(Get-View -Id $DRSRule.Cluster.Id).Name}},
    @{N="Name";E={$DRSRule.Name}},
    @{N="Enabled";E={$DRSRule.Enabled}},
    @{N="DRS Type";E={$DRSRule.Type}}, 
    @{N="VMs";E={$VMIds=$DRSRule.VMIds -split "," 
      $VMs = ForEach ($VMId in $VMIds) 
        { 
        (get-View -Id $VMId).Name
        } 
      $VMs -join ","}}
     }
	 
$Results | Export-Csv -NoTypeInformation -Path $outputfile1
Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true