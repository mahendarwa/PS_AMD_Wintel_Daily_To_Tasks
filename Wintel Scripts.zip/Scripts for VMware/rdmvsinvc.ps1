﻿#get-rdm VMs in VC
Connect-VIServer atlvcsvm01
Get-VM | Get-HardDisk -DiskType "RawPhysical","RawVirtual" | Select Parent,Name,@{N="NAA ID";E={$_.ScsiCanonicalName}},DiskType,@{N="VMhost";E={$_.parent.VMhost}}, @{N="Cluster";E={$_.parent.VMhost.Parent}} | Export-Csv -NoTypeInformation F:\Yns\atlvcsvm01rdmvms.csv