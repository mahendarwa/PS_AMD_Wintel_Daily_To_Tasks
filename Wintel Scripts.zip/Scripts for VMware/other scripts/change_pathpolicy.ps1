Get-VMhost -location SAP-PRD_DB |Get-ScsiLun -LunType "disk" |where {$_.CanonicalName -like "naa.514*"}


