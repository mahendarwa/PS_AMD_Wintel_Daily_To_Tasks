$destinationServers = "mkdcvcsvm01"
# server list "atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"

$new_ntpservers = "","","","",""

$dstServers = $destinationServers.split(",");

$outputFile = ".\output\ntp_setting-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()

foreach ($vcenter in $dstServers) {
	("Connecting vCenter server ..." + $vcenter)
	Connect-viserver -server $vcenter
	$clusters = get-cluster
	if ($clusters){
		foreach ($cluster in $clusters){
			$confirmation = Read-Host "Enter Yes if you want to reconfigure NTP in cluster " +  $cluster
			if ($confirmation -eq "Yes"){
				$vmhosts = $cluster | get-vmhost
				if ($vmhosts){
					foreach ($vmhost in $vmhosts) {
						$row = "" | select vCenter, Cluster, Host, NTP_Policy, NTP_Running, Required
						$ntp =  get-vmhost $vmhost | Get-VMHostService |where {$_.Key -eq "ntpd"}
						$ntpserver = $vmhost |Get-VMHostNtpServer
						# removing servers
						if ($ntpserver){
							for ($index = 0; $index -lt 8; $index++){
								if ($ntpserver[$index]){
									$row | Add-Member -Name "NTPServer$($index)" -Value $ntpserver[$index] -MemberType NoteProperty
									Remove-VmHostNtpServer -NtpServer "$ntpserver[$index]" -VMHost $vmhost | Out-Null 
								}
								else{
									$row | Add-Member -Name "NTPServer$($index)" -Value "none" -MemberType NoteProperty
								}
							}
						}
						#adding new ntp servers
						("Setting host " + $vmhost)
						for ($index = 0; $index -lt 5; $index++){
							Add-VmHostNtpServer -NtpServer "new_ntpservers[$index]" -VMHost $vmhost | Out-Null
							$row | Add-Member -Name "NewNTPServer$($index)" -Value $ntpserver[$index] -MemberType NoteProperty
						}
						$row.vCenter = $vcenter
						$row.Cluster = $cluster
						$row.Host = $vmhost.Name
						$row.NTP_Policy = $ntp.Policy
						$row.NTP_Running = $ntp.Running
						$row.Required = $ntp.Required
						$report += $row
						$ntp | Stop-VMHostService
						$ntp | Start-VMHostService
						$ntp | Set-VMHostService -policy "on"
					}
				}
				else {
					$row = "" | select vCenter, Cluster, Host, NTP_Policy, NTP_Running, Required
					$row.vCenter = $vcenter
					$row.Cluster = $cluster
					$row.Host = "No hosts"
					$report += $row
				}
			}
			else {
				("Skipping Cluster " + $cluster)
			}
		}
	}
	else{
		$row = "" | select vCenter, Cluster, Host, NTP_Policy, NTP_Running, Required
		$row.vCenter = $vcenter
		$row.Cluster = "No Clusters"
		
		$report += $row
	}
}

$report | Export-Csv -Path $outputFile -NoTypeInformation
