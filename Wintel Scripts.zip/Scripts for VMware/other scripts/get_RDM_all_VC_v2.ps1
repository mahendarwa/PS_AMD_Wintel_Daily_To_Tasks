
$destinationServers = "atlvcs01,cybvcs01,cybvcsvm01"
$dstServers = $destinationServers.split(",");


$date = get-date -Format yyyy-MM-dd
$report = @()

foreach ($Server in $dstServers) {
	Connect-VIServer $Server
	$outputFile = ".\output\RDM list $Server" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
	$rdm_vms = Get-VM | where {$_.guest -like "*Windows*"} | Get-HardDisk -DiskType "RawPhysical","RawVirtual" | Select Parent,Name,DiskType,ScsiCanonicalName,DeviceName 
	$rdm_vms | Export-Csv -Path $outputFile -NoTypeInformation
	
#now we colled path policies:
	$outputFile = ".\output\path policies list $Server" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
	$naa_ids = $rdm_vms | Select ScsiCanonicalName
	$report = @()
	$hosts = get-vmhost
	$scsiluns = $hosts | get-scsilun 
	foreach ($naa_id in $naa_ids){
		$row = @()
		$row = $hosts | Where {$_.ScsiCanonicalName -eq $naa_id} 
		$report += $row
	}
	$report | Export-Csv -Path $outputFile -NoTypeInformation
	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
}