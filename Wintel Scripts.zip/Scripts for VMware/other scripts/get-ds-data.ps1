Param ($vcenter=$FALSE,  $esxName=$FALSE)
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter vCenter" }
if ($esxName -eq $FALSE) { $esxName = Read-Host "Please enter host" }



Connect-VIServer $vcenter

Get-VMHost -Name $esxName | Get-Datastore |

Where-Object {$_.ExtensionData.Info.GetType().Name -eq "VmfsDatastoreInfo"} |

ForEach-Object {

if ($_)

{

$Datastore = $_

$Datastore.ExtensionData.Info.Vmfs.Extent |

Select-Object -Property @{Name="Name";Expression={$Datastore.Name}},

DiskName

}

}
