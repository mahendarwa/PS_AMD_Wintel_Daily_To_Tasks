param(
	[Parameter(Mandatory=$true)][string]		$TargetCluster,
	[PSCredential]	$RootCredentials = (Get-Credential)
)

# Create a connection object to all hosts in the Target Cluster
Get-Cluster $TargetCluster | Get-VMHost | % { Connect-VIServer $_ -Credential $RootCredentials | Out-Null }

# Find the ScsiCanonicalName for all RDM Disks attached to VMs in the Target Cluster
$RDMDisks = Get-VM -Location $TargetCluster | Get-HardDisk -DiskType "RawPhysical","RawVirtual" | Select ScsiCanonicalName

# Retrieve and EsxCli instance for each connection
foreach($esxcli in Get-EsxCli) {
	# And for each RDM Disk
	foreach($RDMDisk in $RDMDisks) {
		$RDMDisk | ft
		# Set the configuration to "PereniallyReserved".
		# setconfig method: void setconfig(boolean detached, string device, boolean perenniallyreserved)
		$esxcli.storage.core.device.setconfig($false, ($RDMDisk.ScsiCanonicalName), $true)
	}
}

# Disconnect the connection objects created for the Target Cluster
Disconnect-VIServer * -Confirm:$false | Out-Null