<#
	
	.SYNOPSIS
    Script can be used to copy NFS datastores from one host to others
	
	.DESCRIPTION
    Script takes vCenter Server name, source host name, and destination cluster.
    The script will read all the NFS datastores from the source host, and try to map them to all the servers in the destination cluster.
    The destination cluster can be the same where the source host is, or a different one, but needs to be in the same vCenter.

	.PARAMETER vCenterServer
    Mandatory parameter indicating vCenter server to connect to (FQDN or IP address)
	
	.PARAMETER SRC_HOST
    Mandatory parameter indicating the host from which to read the NFS mounts
	
	.PARAMETER DST_Cluster
    Mandatory parameter with the cluster on which hosts the NFS mounts will be configured
	
	.EXAMPLE
    To configure two NTP servers provide all parameters.
	
    copy_NFS_mounts.ps1 -vcenter atlvcsvm01 -src_host atlesxi010.amd.com -dst_cluster PRD-WIN_NFS-00
	
	
    copy_NFS_mounts.ps1
#>


Param ($vcenter=$FALSE, $SRC_HOST=$FALSE, $DST_Cluster=$FALSE)
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter the name of the vCenter server" }
if ($SRC_HOST -eq $FALSE) { $SRC_HOST = Read-Host "Please enter the FQDN of source Host. i.e atlesxi101.amd.com" }
if ($DST_Cluster -eq $FALSE) { $DST_Cluster = Read-Host "Please enter the name of destination cluster" }
Connect-VIServer $vcenter 


$VMHosts = get-cluster $DST_Cluster -server $vcenter | Get-VMHost |where {$_.name -ne $SRC_HOST}
$src_datastores = Get-vmhost $SRC_HOST | Get-Datastore | where {$_.Type -eq "nfs" -and $_.Accessible -eq "true"}


foreach ($vmhost in $VMHosts){
	("Working on host ..." + $vmhost.Name)
	$dst_datastores = @()
	$diff = @()
	$dst_datastores = Get-vmhost $vmhost | Get-Datastore | where {$_.Type -eq "nfs" -and $_.Accessible -eq "true"}
	$diff = Compare-Object $src_datastores $dst_datastores -property Name, RemotePath, RemoteHost | Where-Object { $_.SideIndicator -eq "<="}| ForEach {$_.InputObject}
	if ($diff -ne $null) {
		foreach ($datastore in $diff){
			$datastore.Name
			New-Datastore -vmhost $vmhost -Nfs -Name $datastore.Name -Path $datastore.RemotePath -NfsHost $datastore.RemoteHost
		}
	}
}

Disconnect-VIServer -Confirm:$False