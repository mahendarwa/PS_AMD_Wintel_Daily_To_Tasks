$destinationServers = "atlvcs01, cybvcs01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
# "atlvcs01,atlvcs02,atlvcs03,atlvcs04,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
$vcenters = $destinationServers.split(",");

$outputFile = ".\output\NFS_VMFS_usage-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()
#Disconnect-VIServer -Server * -force -confirm:$false
foreach ($vcenter in $vcenters)
{
	("Connecting vCenter server ..." + $vcenter)
	Connect-viserver -server $vcenter
	$clusters = get-cluster -server $vcenter
	foreach ($cluster in $clusters){
		$cluster.Name
		$nfs_vms = @()
		$vmfs_vms = @()
		
		$total_nfs = 0
		$total_vmfs = 0
		
		$vms = $cluster | Get-VM
		foreach ($eachvm in $vms){
			$VmView = $eachvm | Get-View
			foreach($VirtualSCSIController in ($VmView.Config.Hardware.Device | where {$_.DeviceInfo.Label -match "SCSI Controller"})) {
				foreach ($VirtualDiskDevice in ($VMView.Config.Hardware.Device | where {$_.ControllerKey -eq $VirtualSCSIController.Key})) {
					$type = Get-Datastore -Id $VirtualDiskDevice.Backing.Datastore | Select -ExpandProperty Type
					if ($type -eq "NFS"){
						$total_nfs += $VirtualDiskDevice.CapacityInKB
					}
					if ($type -eq "VMFS"){
						$total_vmfs += $VirtualDiskDevice.CapacityInKB
					}
				}
			}
		
		}
		
		
		$vms = $cluster | Get-VM | Select Name, @{N="Datastore Type";E={[string]::Join(',',(Get-Datastore -Id $_.DatastoreIdList | Select -ExpandProperty Type -unique))}}
		
		
		$nfs_vms = $vms |where {$_."Datastore Type"-eq "NFS"}
		$vmfs_vms = $vms |where {$_."Datastore Type" -eq "VMFS"}
		
		$row = "" | select VCenter, Cluster, NFS_VM_Count, NFS_GB, VMFS_VM_Count, VMFS_GB
		$row.VCenter = $vcenter
		$row.Cluster = $cluster.Name
		if ($nfs_vms.count -eq $null) {$row.NFS_VM_Count = 0}
		else {$row.NFS_VM_Count = $nfs_vms.count}
		if ($vmfs_vms.count -eq $null) {$row.VMFS_VM_Count = 0}
		else {$row.VMFS_VM_Count = $vmfs_vms.count}
		$row.NFS_GB = [math]::Round($total_nfs/ 1MB)
		$row.VMFS_GB = [math]::Round($total_vmfs/ 1MB)
		$report += $row
	}
	$row = @()
	$report += $row
#	Disconnect-VIServer -server $vcenter
}

$report | Export-Csv -Path $outputFile -NoTypeInformation