
$destinationServers = "atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");



$date = get-date -Format yyyy-MM-dd

foreach ($Server in $dstServers) {
	Connect-VIServer $Server
	("Connecting vCenter server ..." + $vcenter)
	New-CustomAttribute -Name "Incident #" -TargetType VMHost
	New-CustomAttribute -Name "Worked By" -TargetType VMHost
	New-CustomAttribute -Name "Date" -TargetType VMHost
}


