$destinationServers = "mkdcvcsvm01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
# "atlvcs01,atlvcs02,atlvcs03,atlvcs04,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
$vcenters = $destinationServers.split(",");

$outputFile = ".\output\NFS_VMFS_count-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()
#Disconnect-VIServer -Server * -force -confirm:$false
foreach ($vcenter in $vcenters)
{
	("Connecting vCenter server ..." + $vcenter)
	Connect-viserver -server $vcenter
	$clusters = get-cluster -server $vcenter
	foreach ($cluster in $clusters){
		$cluster.Name
		$nfs_vms = @()
		$vmfs_vms = @()
		$vms = $cluster | Get-VM | Select Name, @{N="Datastore";E={[string]::Join(',',(Get-Datastore -Id $_.DatastoreIdList | Select -ExpandProperty Type -unique))}}
		$nfs_vms = $vms |where {$_.Datastore -eq "NFS"}
		$vmfs_vms = $vms |where {$_.Datastore -eq "VMFS"}
		
		$row = "" | select VCenter, Cluster, NFS_VM_Count, VMFS_VM_Count
		$row.VCenter = $vcenter
		$row.Cluster = $cluster.Name
		if ($nfs_vms.count -eq $null) {$row.NFS_VM_Count = 0}
		else {$row.NFS_VM_Count = $nfs_vms.count}
		if ($vmfs_vms.count -eq $null) {$row.VMFS_VM_Count = 0}
		else {$row.VMFS_VM_Count = $vmfs_vms.count}
		$report += $row
	}
	$row = @()
	$report += $row
#	Disconnect-VIServer -server $vcenter
}

$report | Export-Csv -Path $outputFile -NoTypeInformation