Param ($VIServer=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($VIServer -eq $FALSE) { $VIServer = Read-Host "Please enter a Virtual Center or ESXi host name to get VMs with RDMs" }
$csvfile = ".\$VIServer-shared_controllers-$timestamp.csv"
Connect-VIServer $VIServer
$report = @()
$clusters = Get-Cluster
foreach ($cluster in $clusters){
	$vms = $cluster | Get-VM
		foreach($vm in $vms) { 
			$disks = $vm | Get-ScsiController | Where-Object {$_.BusSharingMode -eq "Physical" -or $_.BusSharingMode -eq "Virtual"}
			foreach ($disk in $disks){
				$row  = New-Object -TypeName PSObject
				$row | Add-Member -type NoteProperty -name Cluster -Value $cluster.Name
				$row | Add-Member -type NoteProperty -name Name -Value $vm.Name
				$row | Add-Member -type NoteProperty -name VMHost -Value $vm.VMHost
				$row | Add-Member -type NoteProperty -name Mode -Value $disk.BusSharingMode
				$row | Add-Member -type NoteProperty -name Type -Value “BusSharing”
				$report += $row
			}
		}
}
$report | export-csv -NoTypeInformation $csvfile