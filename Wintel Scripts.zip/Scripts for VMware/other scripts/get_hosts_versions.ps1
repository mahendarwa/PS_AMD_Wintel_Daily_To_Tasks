
$destinationServers = Read-Host "Please enter one or more  Virtual Centers separated by commas"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");



foreach ($Server in $dstServers) {
	Connect-VIServer $Server

	$outfile = ".\output\Hosts_list-$Server-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"


	Get-View -ViewType HostSystem -Property Name, Parent, config.Product.Version, Runtime.HealthSystemRuntime.SystemHealthInfo.NumericSensorInfo, Hardware.SystemInfo.Model | %{ 

		$arrNumericSensorInfo = @($_.Runtime.HealthSystemRuntime.SystemHealthInfo.NumericSensorInfo) 
		$nsiBIOS = $arrNumericSensorInfo | ? {$_.Name -like "*System BIOS*"}     
		$nsiArrayCtrlr = $arrNumericSensorInfo | ? {$_.Name -like "HP Smart Array Controller*"}     
		$nsiILO = $arrNumericSensorInfo | ? {$_.Name -like "Hewlett-Packard BMC Firmware*"}     
		New-Object PSObject -Property @{     
			"Folder/Cluster" = (Get-View -Id $_.Parent -Property Name).Name
			VMHost = $_.Name
			Version = $_.config.Product.Version
			Model = $_.Hardware.SystemInfo.Model
			"SystemBIOS" = $nsiBIOS.name         
			"HPSmartArray" = $nsiArrayCtrlr.Name         
			"iLOFirmware" = $nsiILO.Name    	
		} ## end new-object 
	} | Export-Csv $outfile -NoTypeInformation
	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
}
