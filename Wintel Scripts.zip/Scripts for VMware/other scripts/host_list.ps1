$destinationServers = "atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"
# server list "atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"

$dstServers = $destinationServers.split(",");

$outputFile = ".\output\host_list-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()

foreach ($vcenter in $dstServers)
{
	("Connecting vCenter server ..." + $vcenter)
	Connect-viserver -server $vcenter
	$datacenters = get-datacenter
	foreach ($datacenter in $datacenters){
		$vmhosts = $datacenter | get-vmhost
		foreach ($vmhost in $vmhosts) {
			$row = "" | select vCenter, Datacenter, Host, Model
			$Model = $vmhost |Sort Name |Get-View |Select Name, @{N="Vendor";E={$_.Hardware.SystemInfo.Model}}
			$row.vCenter = $vcenter
			$row.Datacenter = $datacenter
			$row.Host = $vmhost.Name
			$row.Model = $Model.Vendor
			$report += $row
		}
		$row = "" | select vCenter, Datacenter, Host, Model
		$row.vCenter = "Total for"
		$row.Datacenter = $datacenter
		$row.Host = $vmhosts.Count
		$report += $row
		$row = @()
		$report += $row	
	}
}

$report | Export-Csv -Path $outputFile -NoTypeInformation
