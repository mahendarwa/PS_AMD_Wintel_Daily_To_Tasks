Param ($vcenter=$FALSE)
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter a Virtual Center name" }

$timestamp = Get-Date -format "yyyyMMdd-HH.mm"

$outfile = ".\output\$vcenter-SRM_VMs-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$ofs = ", "

Connect-viserver -server $vcenter
$report = @()

$srm = Connect-SrmServer
$srmApi = $srm.ExtensionData

$srmapi = $defaultsrmservers.ExtensionData
$srmpgs = $srmapi.protection.listprotectiongroups()
for ($i=0; $i -lt $srmpgs.Count; $i++)
{
    $vms = $srmpgs[$i].ListProtectedVMs()
	
	$pgvms = @()
#    $pgvms = [array] "Virtual Machine list:"
    for ($a=0; $a -lt $vms.Count; $a++)
    {
        $pgvm ="" | Select Name, Host, Cluster, Datastore
        $vm = get-vm -ID $vms[$a].VM.MoRef
		#$vmhost = $vm.Host
		$vm.Name
		$vmcluster = get-vmhost $vm.Host |select Parent
		$vmcluster
        $pgvm.Name += $vm.Name
		$pgvm.Host += $vm.Host
		$pgvm.Cluster += $vmcluster.Parent
		$pgvm.Datastore += [string] ($vm |select datastoreidlist | %{get-datastore -id $_.datastoreidlist})
		$pgvms +=$pgvm
    }
	$pgvms | Add-Member -MemberType NoteProperty -Name "Group" -Value $srmapi.protection.listprotectiongroups()[$i].GetInfo().Name
#    $pgname = $srmapi.protection.listprotectiongroups()[$i].GetInfo().Name
	$report += $pgvms
	$pgvms
	
}
$report | Export-Csv $outfile -NoTypeInformation

Disconnect-VIServer -server $vcenter -Confirm:$false -Force:$true
