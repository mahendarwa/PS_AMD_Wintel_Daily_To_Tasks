$vcenter = Read-Host "Please enter the name of the vCenter server"
$cluster = Read-Host "Please enter the name of the Host cluster"
Connect-viserver -server $vcenter

$outputFile = ".\output\VMs_with_shared_RDMs_in_$vcenter_" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

$report = @()
$clusters = get-cluster $cluster -Server $vcenter
foreach ($cluster in $clusters){
	$vms = $cluster | Get-VM
		foreach($vm in $vms) { 
			$row = "" | select Cluster, VMName, Host, Shared_controller
			$row.VMName = $vm.Name
			$row.Cluster = $cluster.Name
			$row.Host = $vm.VMhost
			$disks = ""
			$disks = $vm | Get-ScsiController | Where {($_.BusSharingMode -eq "Physical") -or ($_.BusSharingMode -eq "Virtual")}
			if ($disks -ne $null) {$row.Shared_controller = "Yes"}
			else {$row.Shared_controller = "No"}
			$report += $row
		}
}

$report | Export-Csv -Path $outputFile -NoTypeInformation