# Get RDM vMS in a Cluster
Connect-VIServer mkdcvcsvm01
Get-VM | Get-HardDisk -DiskType "RawPhysical","RawVirtual" | Select Parent,Name,DiskType,@{N="VMhost";E={$_.parent.VMhost}}