$vcenter = Read-Host "Please enter the name of the vCenter server"
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"

$outfile = ".\output\$vcenter-HP_FW_Report-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
Connect-viserver -server $vcenter

#$strHostsClusterName = "ZMaintenance"
#Get-View -ViewType HostSystem -Property Name, Runtime.HealthSystemRuntime.SystemHealthInfo.NumericSensorInfo -SearchRoot (Get-View -ViewType ClusterComputeResource -Property Name -Filter @{"Name" = "^$([RegEx]::escape($strHostsClusterName))$"}).MoRef | %{ 

	Get-View  -ViewType HostSystem -Property Name, Parent, Config.Product.fullname, Runtime.HealthSystemRuntime.SystemHealthInfo.NumericSensorInfo, Hardware.SystemInfo.Model | %{ 

		$arrNumericSensorInfo = @($_.Runtime.HealthSystemRuntime.SystemHealthInfo.NumericSensorInfo) 
		# HostNumericSensorInfo for BIOS, iLO, array controller 
		$nsiBIOS = $arrNumericSensorInfo | ? {$_.Name -like "*System BIOS*"}     
		$nsiArrayCtrlr = $arrNumericSensorInfo | ? {$_.Name -like "HP Smart Array Controller*"}     
		$nsiILO = $arrNumericSensorInfo | ? {$_.Name -like "Hewlett-Packard BMC Firmware*"}     
		New-Object PSObject -Property @{     
			"Datacenter" = {
					$parentObj = Get-View $_.Parent
					while($parentObj -isnot [VMware.Vim.Datacenter]){
						$parentObj = Get-View $parentObj.Parent
					}
					$parentObj.Name
				}
				"Folder/Cluster" = (Get-View -Id $_.Parent -Property Name).Name
				VMHost = $_.Name
				Version = $_.Config.Product.fullname		
				Model = $_.Hardware.SystemInfo.Model
				"SystemBIOS" = $nsiBIOS.name         
				"HPSmartArray" = $nsiArrayCtrlr.Name         
				"iLOFirmware" = $nsiILO.Name     
			} ## end new-object 
		} | Export-Csv $outfile -NoTypeInformation
