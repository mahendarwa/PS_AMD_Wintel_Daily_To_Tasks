(" ")
("This Script will detach a lun from all the servers in a cluster.")
("You will need to enter the lun ID as naa.1234xxxxxxx")
(" ")
$server = Read-Host "Enter the name of the vCenter"
$cluster = Read-Host "Enter the name of the Cluster"
$luns_file = Read-Host "Enter the name of the .csv file with the list of luns to Detach"

Connect-VIServer $Server

function Attach-Disk{
	param(
	[VMware.VimAutomation.ViCore.Impl.V1.Inventory.VMHostImpl]$VMHost,
	[string]$CanonicalName
	)
	
	$storSys = Get-View $VMHost.Extensiondata.ConfigManager.StorageSystem
	$lunUuid = (Get-ScsiLun -VmHost $VMHost | 
	where {$_.CanonicalName -eq $CanonicalName}).ExtensionData.Uuid
	
	$storSys.AttachScsiLun($lunUuid)
}

function Detach-Disk{
	param(
	[VMware.VimAutomation.ViCore.Impl.V1.Inventory.VMHostImpl]$VMHost,
	[string]$CanonicalName
	)
	
	$storSys = Get-View $VMHost.Extensiondata.ConfigManager.StorageSystem
	$lunUuid = (Get-ScsiLun -VmHost $VMHost | 
	where {$_.CanonicalName -eq $CanonicalName}).ExtensionData.Uuid
	
	$storSys.DetachScsiLun($lunUuid)
}

$hosts = Get-Cluster -Name $cluster | Get-VMHost



do {
	$canonicalname = (Read-Host "Please enter canonical name of a lun (such as naa.123456789) or press Enter to finish")
	if ($canonicalname -ne '') {
		$hosts | %{
			Detach-Disk -VMHost $_ -CanonicalName $canonicalname
		}
	}
}
until ($canonicalname -eq '')

Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true


