
$destinationServers = "atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
$dstServers = $destinationServers.split(",");


$date = get-date -Format yyyy-MM-dd
$report = @()

foreach ($Server in $dstServers) {
	Connect-VIServer $Server
	$outputFile = ".\output\RDM list $Server" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
	$rdm_vms = Get-VM | Get-HardDisk -DiskType "RawPhysical","RawVirtual" | Select Parent,Name,DiskType,ScsiCanonicalName,DeviceName 
	$rdm_vms | Export-Csv -Path $outputFile -NoTypeInformation
	

	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
}