param(
	[Parameter(Mandatory=$true)][string]		$TargetCluster
)
$TargetCluster = $TargetCluster.trim()

$outfile = ".\output\Reserve-RDM-$TargetCluster" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
#$vmName = "VMwithRDM"

$rdms = Get-Cluster $TargetCluster | Get-VM |Get-HardDisk -DiskType "RawPhysical","RawVirtual"
#$vm = Get-VM -Name $vmName
#$rdm = Get-HardDisk -DiskType rawPhysical -Vm $vm
$vmhosts = Get-Cluster $TargetCluster | Get-VMHost

$report = @()
$report_before = @()
$report_after = @()

foreach($esx in $vmhosts){
  $esxcli = Get-EsxCli -VMHost $esx
  foreach ($rdm in $rdms){
  #Get-HardDisk -DiskType rawPhysical -Vm $vm | %{
    $report_before += $esxcli.storage.core.device.list($rdm.ScsiCanonicalName) | Select @{N="Time";E={"{0:g}" -f (Get-Date).TimeOfDay}},Device,IsPerenniallyReserved

    $esxcli.storage.core.device.setconfig($false,$rdm.ScsiCanonicalName,$true)


    $report_after += $esxcli.storage.core.device.list($rdm.ScsiCanonicalName) | Select @{N="Time";E={"{0:g}" -f (Get-Date).TimeOfDay}},Device,IsPerenniallyReserved
  }
}
$report += $report_before
	$breakline = ""|select Time, Device, IsPerenniallyReserved
	$breakline.Time = "{0:g}" -f (Get-Date).TimeOfDay
	$breakline.Device = "Reconfiguring"
	$report += $breakline 
$report += $report_after

$report | Export-Csv $outfile -NoTypeInformation

# Disconnect the connection objects created for the Target Cluster
#Disconnect-VIServer * -Confirm:$false | Out-Null