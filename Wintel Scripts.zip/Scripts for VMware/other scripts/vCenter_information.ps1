
$destinationServers = "atlvcs02,cybvcs02,mkdcvcs02,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,cybvcsview01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");

$outputFile = ".\output\vCenters_information" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

$date = get-date -Format yyyy-MM-dd
$report = @()

foreach ($Server in $dstServers) {
	Connect-VIServer $Server
	("Connecting vCenter server ..." + $vcenter)
	$vm_hosts = @()
	$vcenter_info = $global:DefaultVIServer.ExtensionData.Content.About |select version,build
	$clusters = get-cluster
	$vm_hosts = get-vmhost
	$row = "" | Select vCenter, Version, Build, Clusters, "50_hosts", "55_hosts","Other version", "VM Count"
	$vms = get-vm
	
	$row.vCenter = $Server
	$row.Version = $vcenter_info.version
	$row.build = $vcenter_info.build
	$row.Clusters = $clusters.count
	$row."50_hosts" = ($vm_hosts| where {$_.version -eq "5.0.0"}).count
	$row."55_hosts" = ($vm_hosts| where {$_.version -eq "5.5.0"}).count
	$row."Other version" = ($vm_hosts| where {($_.version -ne "5.5.0") -and ($_.version -ne "5.0.0")}).count
	$row."VM Count" = $vms.count
	$report += $row
	
	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
	
#	Write-Host "Copying '" $baseline.Name "' to the server $Server" 
#	Invoke-Expression $command
}

$report | Export-Csv -Path $outputFile -NoTypeInformation
