$destinationServers = "atlvcs02,cybvcs02,cybvcs03,mkdcvcs02,islvcs01,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"

$dstServers = $destinationServers.split(",");

$timestamp = Get-Date -format "yyyyMMdd-HH.mm"

$outfile = ".\output\all_vcenters-HP_FW_Report-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"


#$strHostsClusterName = "ZMaintenance"
#Get-View -ViewType HostSystem -Property Name, Runtime.HealthSystemRuntime.SystemHealthInfo.NumericSensorInfo -SearchRoot (Get-View -ViewType ClusterComputeResource -Property Name -Filter @{"Name" = "^$([RegEx]::escape($strHostsClusterName))$"}).MoRef | %{ 
	$report = @()
	foreach ($Server in $dstServers) {
		Connect-VIServer $Server
		("Connecting vCenter server ..." + $vcenter)
		foreach ($datacenter in get-Datacenter){
			$report  +=  Get-View  -ViewType HostSystem -searchroot $datacenter.id -Property Name, Parent, Config.Product.fullname, Runtime.HealthSystemRuntime.SystemHealthInfo.NumericSensorInfo, Hardware.SystemInfo.Model | %{ 
				$arrNumericSensorInfo = @($_.Runtime.HealthSystemRuntime.SystemHealthInfo.NumericSensorInfo) 
				# HostNumericSensorInfo for BIOS, iLO, array controller 
				$nsiBIOS = $arrNumericSensorInfo | ? {$_.Name -like "*System BIOS*"}     
				$nsiArrayCtrlr = $arrNumericSensorInfo | ? {$_.Name -like "HP Smart Array Controller*"}     
				$nsiILO = $arrNumericSensorInfo | ? {$_.Name -like "Hewlett-Packard BMC Firmware*"}     
				New-Object PSObject -Property @{     
					"vCenter" = $Server
					"Datacenter" = $Datacenter.Name
					"Folder/Cluster" = (Get-View -Id $_.Parent -Property Name).Name
					VMHost = $_.Name
					Version = $_.Config.Product.fullname		
					Model = $_.Hardware.SystemInfo.Model
					"SystemBIOS" = $nsiBIOS.name         
					"HPSmartArray" = $nsiArrayCtrlr.Name         
					"iLOFirmware" = $nsiILO.Name     
				} ## end new-object 
			}
		}
		Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
	}

	$report	| Export-Csv $outfile -NoTypeInformation

