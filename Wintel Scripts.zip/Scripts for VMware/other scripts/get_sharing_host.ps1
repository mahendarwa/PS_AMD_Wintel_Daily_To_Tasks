# This script requires PowerCLI 4.0 U1
#
# Create Disk Mapping Table
# Created by Arnim van Lieshout
# Http://www.van-lieshout.com

# Initialize variables
# $VCServerList is a comma-separated list of vCenter servers
$VCServerList = Read-Host "Enter vCenter server"
$DiskInfo= @()
$Vm = Read-Host "Enter VMName to check what host is running on and what VMs are in the same"
Connect-VIServer $VCServerList 

$outputFile = ".\output\$Vm-$VCServerList-vms_sharing_host" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
    get-vmhost (Get-VM $Vm).host | get-vm | Select PowerState, Guest, NumCpu, MemoryGB, Host| Export-Csv -Path $outputFile -NoTypeInformation

