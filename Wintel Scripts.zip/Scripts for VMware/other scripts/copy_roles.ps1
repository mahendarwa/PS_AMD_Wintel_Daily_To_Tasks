Param ($vcenter1=$FALSE, $vcenter2=$FALSE, $rolename=$FALSE)
$outputFile='.\roles'
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vcenter1 -eq $FALSE) { $vcenter1 = Read-Host "Please enter a Source Virtual Center to copy role from" }
if ($vcenter2 -eq $FALSE) { $vcenter2 = Read-Host "Please enter a Destination Virtual Center to copy role to" }
if ($rolename -eq $FALSE) { $rolename = Read-Host "Please the name of the role to copy" }

$outputFile = ".\output\$vcenter1-$vcenter2" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"


$report = @()

"Connecting vCenter servers ..."
Connect-viserver -server $vcenter1,$vcenter2 
"Getting role count"
#Get-VIrole -Name "$rolename" -Server $vcenter1 | fl *
"Creating new role"
New-VIRole -name "$rolename" -Server $vcenter2

[string[]]$privsforRoleAfromVC1=Get-VIPrivilege -Role (Get-VIRole -Name "$rolename" -server $vcenter1) |%{$_.id}

"Copying privileges"
Set-VIRole -role (get-virole -Name "$rolename" -Server $vcenter2) -AddPrivilege (get-viprivilege -id $privsforRoleAfromVC1 -server $vcenter2)
$SrcPrivilegeCount = (Get-VIRole -Name "$rolename" -Server $vcenter1).PrivilegeList.Count
$DstPrivilegeCount = (Get-VIRole -Name "$rolename" -Server $vcenter2).PrivilegeList.Count

("Got " + $SrcPrivilegeCount + " privileges in vCenter " + $vcenter1)
("Got " + $DstPrivilegeCount + " privileges in vCenter " + $vcenter2)
$row = "" | select Source, Destination, Role, SrcPrivilegeCount, DstPrivilegeCount
$row.Source = $vcenter1
$row.destination = $vcenter2
$row.Role = $rolename
$row.SrcPrivilegeCount = $SrcPrivilegeCount
$row.DstPrivilegeCount = $DstPrivilegeCount
$report += $row

$report | Export-CSV -Path $outputFile
