Param ($vcentersfile=$FALSE, $rolename=$FALSE, $principal=$FALSE)

$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vcentersfile -eq $FALSE) { $vcentersfile = Read-Host "Please enter the name of a file with the vcenters names" }
if ($rolename -eq $FALSE) { $rolename = Read-Host "Please enter the name of the role to assign" }
if ($principal -eq $FALSE) { $principal = Read-Host "Please enter the name of the security principal" }

$outputFile = ".\output\roles-members-$rolename" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

$vcenters = Get-Content .\$vcentersfile

$report = @()

foreach ($dstvcenter in $vcenters)
{
	("Connecting vCenter servers ..." + $dstvcenter)
	Connect-viserver -server $dstvcenter
	
	# Locate Inventory Item rootFolder
	$folder = Get-Folder -NoRecursion
	$entity = Get-View $folder
	# Create permissions for root folder
	$entityMoRef = new-object VMware.Vim.ManagedObjectReference
	$entityMoRef.type = $entity.MoRef.type
	$entityMoRef.value = $entity.MoRef.value
	$permission = New-Object VMware.Vim.Permission[](23)
	$permission[0] = New-Object VMware.Vim.Permission
	$permission[0].principal = "$principal"
	$permission[0].group = $false
	$permission[0].propagate = $true
	$newRoleId = (get-virole | where-object {$_.Name -match "$rolename"} | select-object Id)
	$permission[0].roleId = $newRoleId.Id
	# Get Authorization Manager
	$_this = Get-View -Id AuthorizationManager-AuthorizationManager
	# Set permissions
	"Setting permissions ..."
	$_this.SetEntityPermissions($entityMoRef,$permission)
	
	$row = "" | select vCenter, Role, principal
	$row.vCenter = $dstvcenter
	$row.Role = $rolename
	$row.principal = $principal
	$report += $row
}
$report | Export-CSV -Path $outputFile