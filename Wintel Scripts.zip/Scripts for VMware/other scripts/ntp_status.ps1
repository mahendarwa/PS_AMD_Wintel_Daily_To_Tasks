$destinationServers = "atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"
# server list "atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"

$dstServers = $destinationServers.split(",");

$outputFile = ".\output\ntp_status-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()

foreach ($vcenter in $dstServers)
{
	("Connecting vCenter server ..." + $vcenter)
	Connect-viserver -server $vcenter
	$clusters = get-cluster
	if ($clusters){
		foreach ($cluster in $clusters){
			$vmhosts = $cluster | get-vmhost
			if ($vmhosts){
				foreach ($vmhost in $vmhosts) {
					$row = "" | select vCenter, Cluster, Host, NTP_Policy, NTP_Running, Required
					$ntp =  get-vmhost $vmhost | Get-VMHostService |where {$_.Key -eq "ntpd"}
					$ntpserver = $vmhost |Get-VMHostNtpServer
					if ($ntpserver){
						for ($index = 0; $index -lt 5; $index++){
							if ($ntpserver[$index]){
								$row | Add-Member -Name "NTPServer$($index)" -Value $ntpserver[$index] -MemberType NoteProperty
							}
							else{
								$row | Add-Member -Name "NTPServer$($index)" -Value "none" -MemberType NoteProperty
							}
						}
					}
					$row.vCenter = $vcenter
					$row.Cluster = $cluster
					$row.Host = $vmhost.Name
					$row.NTP_Policy = $ntp.Policy
					$row.NTP_Running = $ntp.Running
					$row.Required = $ntp.Required
					$report += $row
				}
			}
			else {
				$row = "" | select vCenter, Cluster, Host, NTP_Policy, NTP_Running, Required
				$row.vCenter = $vcenter
				$row.Cluster = $cluster
				$row.Host = "No hosts"
				$report += $row
			}
		}
		
	}
	else{
		$row = "" | select vCenter, Cluster, Host, NTP_Policy, NTP_Running, Required
		$row.vCenter = $vcenter
		$row.Cluster = "No Clusters"

		$report += $row
	}
}

$report | Export-Csv -Path $outputFile -NoTypeInformation
