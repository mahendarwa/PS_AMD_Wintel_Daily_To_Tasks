$vcenter = Read-Host "Please enter the name of the vCenter server"
$cluster = Read-Host "Please enter the name of the Datastore cluster"
Connect-viserver -server $vcenter

$outputFile = ".\output\VMs_with_shared_RDMs_in_$vcenter_$cluster" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

$report = @()
$datastores = get-datastorecluster $cluster -Server $vcenter | get-datastore
foreach ($datastore in $datastores){
	$vms = $datastore | Get-VM
		foreach($vm in $vms) { 
			$row = "" | select Datastore, VMName, Host, Shared_controller
			$row.VMName = $vm.Name
			$row.Datastore = $datastore.Name
			$row.Host = $vm.VMhost
			$disks = ""
			$disks = $vm | Get-ScsiController | Where {($_.BusSharingMode -eq "Physical") -or ($_.BusSharingMode -eq "Virtual")}
			if ($disks -ne $null) {$row.Shared_controller = "Yes"}
			else {$row.Shared_controller = "No"}
			$report += $row
		}
}

$report | Export-Csv -Path $outputFile -NoTypeInformation