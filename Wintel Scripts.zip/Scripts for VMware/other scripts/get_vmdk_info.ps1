# Get data about vmdk and format
# 
# Niklas �kerlund / RTS

Param ($vcenter=$FALSE, $vm_name=$FALSE)
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter the name of the vCenter server" }
if ($vm_name -eq $FALSE) { $vm_name = Read-Host "Please enter the name of the VM" }
Connect-VIServer $vcenter 

$outputFile = ".\output\$vm_name-$vcenter-vmdk_mapping" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

$VMs = Get-VM $vm_name
$Data = @()

 foreach ($VM in $VMs){
	$VMDKs = $VM | get-HardDisk
	foreach ($VMDK in $VMDKs) {
		if ($VMDK -ne $null){
			$CapacityGB = $VMDK.CapacityKB/1024/1024
			$CapacityGB = [int]$CapacityGB
			$into = New-Object PSObject
			Add-Member -InputObject $into -MemberType NoteProperty -Name VMname $VM.Name
			Add-Member -InputObject $into -MemberType NoteProperty -Name Diskname $VMDK.Name
			Add-Member -InputObject $into -MemberType NoteProperty -Name Datastore $VMDK.FileName.Split(']')[0].TrimStart('[')
			Add-Member -InputObject $into -MemberType NoteProperty -Name VMDK $VMDK.FileName.Split(']')[1].TrimStart('[')
			Add-Member -InputObject $into -MemberType NoteProperty -Name StorageFormat $VMDK.StorageFormat
			Add-Member -InputObject $into -MemberType NoteProperty -Name CapacityGB $CapacityGB
			$Data += $into
		}
	}

}
$Data | Sort-Object VMname,Datastore,VMDK | Export-Csv -Path $outputFile -NoTypeInformation