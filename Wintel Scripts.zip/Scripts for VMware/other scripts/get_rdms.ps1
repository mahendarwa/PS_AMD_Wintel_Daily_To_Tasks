Param ($VIServer=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($VIServer -eq $FALSE) { $VIServer = Read-Host "Please enter a Virtual Center or ESXi host name to get VMs with RDMs" }
$csvfile = ".\$VIServer-rdmvms-$timestamp.csv"
Connect-VIServer $VIServer
$report = @()
$vms = Get-VM | Get-View
foreach($vm in $vms){ 
	foreach($dev in $vm.Config.Hardware.Device){   
		if(($dev.gettype()).Name -eq "VirtualDisk"){     
			if(($dev.Backing.CompatibilityMode -eq "physicalMode") -or ($dev.Backing.CompatibilityMode -eq "virtualMode")){
				$row = "" | select VMName, HDDeviceName, HDFileName
				$row.VMName = $vm.Name
				$row.HDDeviceName = $dev.Backing.DeviceName
				$row.HDFileName = $dev.Backing.FileName
				$report += $row
			}
		}
	}
}
$report | export-csv -NoTypeInformation $csvfile