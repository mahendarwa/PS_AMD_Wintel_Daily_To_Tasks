$destinationServers = "AUSI-ESX01,AUSI-ESX02,AUSI-ESX03,AUSI-ESX04,AUSI-ESX05"
# server list "atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"

$dstServers = $destinationServers.split(",");

$outputFile = ".\ppe_vms-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()

foreach ($server in $dstServers)
{

	("Connecting server ..." + $vcenter)
	Connect-viserver -server $server -User root -Password passw0rd
	$row = get-vm |select Name, PowerState, Guest
	$row | Add-Member -Name "Server" -Value $server -MemberType NoteProperty
	$report += $row

}

$report | Export-Csv -Path $outputFile -NoTypeInformation
