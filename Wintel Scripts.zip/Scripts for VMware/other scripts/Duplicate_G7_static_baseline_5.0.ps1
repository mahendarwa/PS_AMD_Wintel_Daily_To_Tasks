
$destinationServers = "atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");



$date = get-date -Format yyyy-MM-dd

foreach ($Server in $dstServers) {
	Connect-VIServer $Server
	("Connecting vCenter server ..." + $vcenter)

	$baseline = Get-PatchBaseline "Non-Critical Host Patches (2015-11-23)"
	$good = $baseline.CurrentPatches | where {$_.IdByVendor -notmatch "be2net-10"}

	$command = 'New-PatchBaseline -Name "Non-Critical Host Patches (2015-11-23 - G7 - No be2net)" -Description $baseline.Description -Static -TargetType $baseline.TargetType -IncludePatch $good'
	Write-Host "Copying '" $baseline.Name "' to the server $Server" 
	Invoke-Expression $command
}


