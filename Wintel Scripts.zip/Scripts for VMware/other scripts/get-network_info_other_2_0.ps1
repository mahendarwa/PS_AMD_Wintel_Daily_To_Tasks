$vcenter = Read-Host "Please enter the name of the vCenter server"
Connect-VIServer $vcenter 
$outputFile = ".\output\"+$vcenter+ "network_details"+ (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$vmhosts = get-vmhost
$report = @()
foreach ($vmhost in $vmhosts){
	$row = @()
	$row = $vmhost | Get-VMHostNetworkAdapter | select VMhost, Name, ManagementTrafficEnabled, IP, SubnetMask, Mac, PortGroupName, vMotionEnabled, mtu, FullDuplex, BitRatePerSec| Sort-Object  -Property {$_.Name-replace '[\d]'},{$_.Name-replace '[a-zA-Z\p{P}]'-as [int]}
	$report +=$row
}
$report | Export-Csv -Path $outputFile -NoTypeInformation -UseCulture

Disconnect-VIServer -server $vcenter -Confirm:$false -Force:$true