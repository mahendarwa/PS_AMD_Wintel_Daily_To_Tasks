Param ($vmlistfile=$FALSE,$vcenter=$FALSE)

$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vmlistfile -eq $FALSE) { $vmlistfile = Read-Host "Please enter the name of a file with the list of VMs" }
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter the name of the vCenter with those VMs" }
$ErrorActionPreference="SilentlyContinue"
Stop-Transcript | out-null
Disconnect-VIServer -Server * -force -confirm:$false
$ErrorActionPreference = "Continue"
Start-Transcript -path output\delete_log.txt -append


("Connecting vCenter server ..." + $vcenter)
Connect-viserver -server $vcenter

$vmslist = Get-Content .\$vmlistfile

foreach ($vm in $vmslist)
{
	remove-VM -DeletePermanently -RunAsync -VM $vm -Server $vcenter
}

Stop-Transcript





