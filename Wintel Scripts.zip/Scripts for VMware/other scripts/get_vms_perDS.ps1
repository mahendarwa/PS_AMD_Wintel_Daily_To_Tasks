Param ($vcenter=$FALSE, $cluster=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter a Virtual Center or ESXi host name to get VMs with RDMs" }
if ($cluster -eq $FALSE) { $cluster = Read-Host "Please enter a Cluster Name to get VMs with RDMs" }

$outputFile = ".\output\All-VMS-PerDS-$cluster-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

"Connecting vCenter servers ..."
Connect-VIServer $vcenter


$report = Get-Cluster $cluster| Get-VMHost | Get-Datastore | Foreach-Object {
    $ds = $_.Name
    $_ | Get-VM | Select-Object Name,Type,@{n='DataStore';e={$ds}}
}

"Exporting report data to $outputFile ..."
$report | Export-CSV -Path $outputFile
"All done."