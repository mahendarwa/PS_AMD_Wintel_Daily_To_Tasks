Param ($vcenter1=$FALSE, $vcentersfile=$FALSE, $rolename=$FALSE)

$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vcenter1 -eq $FALSE) { $vcenter1 = Read-Host "Please enter a Source Virtual Center to copy role from" }
if ($vcentersfile -eq $FALSE) { $vcentersfile = Read-Host "Please enter a name of vCenters list" }
if ($rolename -eq $FALSE) { $rolename = Read-Host "Please the name of the role to copy" }

$vcenters = Get-Content .\$vcentersfile

$outputFile = ".\output\roles-$vcenter1-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()
	
foreach ($dstvcenter in $vcenters)
{
	
	"Connecting vCenter servers ..."
	Connect-viserver -server $vcenter1,$dstvcenter 
	"Getting role count"
	#Get-VIrole -Name "$rolename" -Server $vcenter1 | fl *
	("Creating new role in " + $dstvcenter)
	New-VIRole -name "$rolename" -Server $dstvcenter
	
	[string[]]$privsforRoleAfromVC1=Get-VIPrivilege -Role (Get-VIRole -Name "$rolename" -server $vcenter1) |%{$_.id}
	
	"Copying privileges"
	Set-VIRole -role (get-virole -Name "$rolename" -Server $dstvcenter) -AddPrivilege (get-viprivilege -id $privsforRoleAfromVC1 -server $dstvcenter)
	$SrcPrivilegeCount = (Get-VIRole -Name "$rolename" -Server $vcenter1).PrivilegeList.Count
	$DstPrivilegeCount = (Get-VIRole -Name "$rolename" -Server $dstvcenter).PrivilegeList.Count
	
	("Got " + $SrcPrivilegeCount + " privileges in vCenter " + $vcenter1)
	("Got " + $DstPrivilegeCount + " privileges in vCenter " + $dstvcenter)
	$row = "" | select Source, Destination, Role, SrcPrivilegeCount, DstPrivilegeCount
	$row.Source = $vcenter1
	$row.destination = $dstvcenter
	$row.Role = $rolename
	$row.SrcPrivilegeCount = $SrcPrivilegeCount
	$row.DstPrivilegeCount = $DstPrivilegeCount
	$report += $row
}

$report | Export-CSV -Path $outputFile
