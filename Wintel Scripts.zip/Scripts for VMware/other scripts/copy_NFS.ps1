<#
	
	.SYNOPSIS
    Script can be used to copy NFS datastores from one host to others
	
	.DESCRIPTION
    Script takes vCenter Server name, source host and target host or hosts as mandatory parameters.
    If only mandatory parameters are provided script generates report aobut NTP settings for all vSphere hosts that are
    connected to cluster. Report include ntp service status, policy, up to 5 ntp servers configured and calculated time difference
    between host and system where the script is invoked. For consistent results script should be run from vCenter Server.
    Optional parameter NTPSources is a comma-separated list of ntp servers that will be configured in cluster.
    If NTPSources paramter is provided the script will configure ntp service to start together with host ("on" policy),
    configure ntp servers provided, set the time manually (to avoid drift problems) and restart ntpd.
	
	If ClusterName parameter is not provided, it will pull the list of Clusters from the vCenter, as ask confirmation one by one if the changes should be applied.
	
	.PARAMETER vCenterServer
    Mandatory parameter indicating vCenter server to connect to (FQDN or IP address)
	
	.PARAMETER ClusterName
    Optional parameter indicating host cluster name where vms need to be reconfigured
	
	.PARAMETER NTPSources
    Optional parameter indicating NTP servers that will be used
	
	.EXAMPLE
    To configure two NTP servers provide all parameters.
	
    ntp_setting_v2.1.ps1 -vCenterServer vcenter.seba.local -ClusterName Production-Cluster -NTPSources "time01.seba.local,time02.seba.local,10.0.0.1"
	
	.EXAMPLE
    To configure two NTP servers on multiple clusters in same vCenter.
	
    ntp_setting_v2.1.ps1 -vCenterServer vcenter.seba.local  -NTPSources "time01.seba.local,time02.seba.local,10.0.0.1"
	
	.EXAMPLE
    If you provide -NTPSources only the script will ask for mandatory parameters
	
    ntp_setting_v2.1.ps1 -NTPSources "time01.seba.local,time02.seba.local,10.0.0.1"
	
	.EXAMPLE
    To generate report about NTP service status provide only mandatory parameters.
	
    ntp_setting_v2.1.ps1 -vcenter 10.0.0.1 -cluster tdq-cluster
	
	.EXAMPLE
    Script will interactively ask for two mandatory parameters, no changes will be made, only report will be created.
	
    ntp_setting_v2.1.ps1
#>


Param ($vcenter=$FALSE, $SRC_HOST=$FALSE, $DST_HOSTS=$FALSE)
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter the name of the vCenter server" }
if ($SRC_HOST -eq $FALSE) { $SRC_HOST = Read-Host "Please enter the name of source Host" }
if ($DST_HOSTS -eq $FALSE) { $DST_HOSTS = Read-Host "Please enter the name of destination Host or Hosts (separated by commas)" }
Connect-VIServer $vcenter 


$VMHosts = Get-VMHost $DST_HOSTS.split(",")

foreach ($vmhost in $VMHosts){
	("Working on host ..." + $vmhost.Name)
	foreach ($datastore in (Get-vmhost $SRC_HOST | Get-Datastore | where {$_.Type -eq "nfs" -and $_.Accessible -eq "true"})){
		New-Datastore -vmhost $vmhost -Nfs -Name $datastore.Name -Path $datastore.RemotePath -NfsHost $datastore.RemoteHost
		$datastore.Name}
}