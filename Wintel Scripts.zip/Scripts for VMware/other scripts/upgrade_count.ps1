$destinationServers = "atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"
# server list "atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01,atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"

$dstServers = $destinationServers.split(",");

$outputFile = ".\output\upgrade_progress-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()

foreach ($vcenter in $dstServers)
{
	("Connecting vCenter server ..." + $vcenter)
	Connect-viserver -server $vcenter
	$vmhosts = get-vmhost
	$Hosts55 = $vmhosts | where  {$_.Version -eq "5.5.0"}
	$row = "" | select VCenter, Hosts55, Total
	$row.VCenter = $vcenter
	$row.Hosts55 = $Hosts55.Count
	$row.Total = $vmhosts.Count
	$report += $row
}

$report | Export-Csv -Path $outputFile -NoTypeInformation
