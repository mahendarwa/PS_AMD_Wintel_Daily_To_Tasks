##################################################################
# Script for collecting performance report of multiple VMs       #
##################################################################

$vCenter = Read-Host "Enter the vCenter name wherein the target cluster resides"
$cluster = Read-Host "Enter name of the cluster with VMs to which performance report need to be grabbed"
$sdate = Get-Date (Read-Host "Enter start date of the report(mm/dd/yyyy)")  
$fdate = Get-Date (Read-Host "Enter finish date of the report(mm/dd/yyyy)")
$interval = Read-Host "Enter the interval between samples in Minutes"
#$nsamples = Read-Host "How many samples you want to be retrieved in specified interval"

Connect-VIServer $vCenter

$VMs = Get-Cluster $cluster | Get-VM
$stats = @()

$outputFile = ".\output\stats\$VCServer-$cluster-VM_Stats"+ (get-date -Format yyyy-MM-dd-HHmm) + ".csv"



foreach($VM in $VMs)
    {
     Write-Host "Collecting data for" $VM "..."
#     $stats += Get-Stat -Entity $VM -Common -MaxSamples $nsamples -Start $sdate -Finish $fdate 
	 $stats += Get-Stat -Entity $VM -Cpu -Memory -Start $sdate -Finish $fdate 
    }

$stats | Export-Csv -Path $outputFile -Force -NoTypeInformation
Invoke-Item $outputFile

Disconnect-VIServer $vCenter -Confirm:$false