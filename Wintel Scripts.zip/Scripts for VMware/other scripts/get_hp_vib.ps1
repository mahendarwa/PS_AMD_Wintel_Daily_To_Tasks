Param ($vcenter=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter a Virtual Center or ESXi host name to get Hosts with vib hp-ams" }


$outputFile = ".\output\All-HP-VIB-$vcenter-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

"Connecting vCenter servers ..."
Connect-VIServer $vcenter 

$report = @()


"Getting VM Hosts. Be patient, this can take up a few minutes ..."

$hosts = Get-VMHost
("Got " + $hosts.Count + " Hosts ...")

foreach($esx in $hosts) {
    ("Processing Host " + $esx.Name + " ...")
	$esxcli = Get-EsxCli -VMhost $esx
	$vibs  = $esxcli.software.vib.list() | Select AcceptanceLevel,ID,InstallDate,Name,ReleaseDate,Status,Vendor,Version  | Where {$_.Name -match "hp-ams" -AND ($_.Version -match "500.9.6.0-12" -OR $_.Version -match "550.9.6.0-12" -OR $_.Version -match "500.10.0.0-18" -OR $_.Version -match "550.10.0.0-18" )}
	if ($vibs -ne $null){
	foreach ($vib in $vibs) {
		$row = "" | select Hostname, Name, Version, ReleaseDate, Status, Vendor
			$row.Hostname = $esx.Name
			$row.Name = $vib.Name
			$row.Version = $vib.Version
			$row.ReleaseDate = $vib.ReleaseDate
			$row.Status = $vib.Status
			$row.Vendor = $vib.Vendor
			$report += $row
	}
	}
}

"Exporting report data to $outputFile ..."
$report | Export-CSV -Path $outputFile
"All done."