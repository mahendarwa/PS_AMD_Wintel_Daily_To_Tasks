"i.e: atlvcs02,cybvcs02,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
$destinationServers = Read-Host "Please enter a list of vCenters to pull SDRS settings from (separated by commas with no space)" 
#"atlvcsvm01"
#"atlvcs02,cybvcs02,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"

$dstServers = $destinationServers.split(",");
$report = @()

$date = get-date -Format yyyy-MM-dd-HHmm

foreach ($Server in $dstServers) {
	Connect-VIServer $Server 


	foreach ($dsc in get-datastorecluster){
		$rules = @()
		$rules = $dsc.ExtensionData.PodStorageDrsEntry.StorageDrsConfig.VmConfig |
		Select Enabled,IntraVmAffinity,IntraVmAntiAffinity,
		@{N="VM";E={[string]::Join('/',(Get-View -Id $_.VM -Property Name | Select -ExpandProperty Name))}}, @{N="ProvisionedGB";E={get-vm -Id $_.VM |select -ExpandProperty ProvisionedSpaceGB}}
		$rules| Add-Member -Name "Datastore Cluster" -Value $dsc.Name -MemberType NoteProperty
		$rules| Add-Member -Name "vCenter" -Value $Server -MemberType NoteProperty
		$report += $rules
	}
	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
}
$report | Export-Csv ".\output\SDRS_rules-$date.csv" -NoTypeInformation -UseCulture
