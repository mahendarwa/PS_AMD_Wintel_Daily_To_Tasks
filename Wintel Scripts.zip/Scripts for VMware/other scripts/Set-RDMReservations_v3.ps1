param(
[Parameter(Mandatory=$true)][string]		$TargetCluster
)
$TargetCluster = $TargetCluster.trim()

$outfile = ".\output\Reserve-RDM-$TargetCluster-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
#$vmName = "VMwithRDM"

$all_rdms = Get-VM |Get-HardDisk -DiskType "RawPhysical","RawVirtual"
#$rdms = Get-Cluster $TargetCluster | Get-VM |Get-HardDisk -DiskType "RawPhysical","RawVirtual"
#$vm = Get-VM -Name $vmName
#$rdm = Get-HardDisk -DiskType rawPhysical -Vm $vm
if ($TargetCluster -eq "all"){
	$vmhosts = Get-VMHost
}
else {
	$vmhosts = Get-Cluster $TargetCluster | Get-VMHost
}

$report = @()
$report_before = @()
$report_after = @()


foreach($esx in $vmhosts){
	$breakline = ""|select Time, Device, IsPerenniallyReserved
	$breakline.Time = "{0:g}" -f (Get-Date).TimeOfDay
	$breakline.Device = $esx.Name
	$report += $breakline

	$esxcli = Get-EsxCli -VMHost $esx
	$hostluns  = ($esxcli.storage.core.device.list()).Device
	foreach ($hostlun in $hostluns){
		if ($all_rdms.scsicanonicalname -contains $hostlun) {
			$report += $esxcli.storage.core.device.list($hostlun) | Select @{N="Time";E={"{0:g}" -f (Get-Date).TimeOfDay}},Device,IsPerenniallyReserved
			$esxcli.storage.core.device.setconfig($false,$hostlun,$true)
			$report += $esxcli.storage.core.device.list($hostlun) | Select @{N="Time";E={"{0:g}" -f (Get-Date).TimeOfDay}},Device,IsPerenniallyReserved
		}
	}
}

$report | Export-Csv $outfile -NoTypeInformation

# Disconnect the connection objects created for the Target Cluster
#Disconnect-VIServer * -Confirm:$false | Out-Null