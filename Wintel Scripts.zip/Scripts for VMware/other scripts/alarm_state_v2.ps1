

function Set-AlarmActionState {
	<#  
		.SYNOPSIS  Enables or disables Alarm actions   
		.DESCRIPTION The function will enable or disable
		alarm actions on a vSphere entity itself or recursively
		on the entity and all its children.
		.NOTES  Author:  Luc Dekens  
		.PARAMETER Entity
		The vSphere entity.
		.PARAMETER Enabled
		Switch that indicates if the alarm actions should be
		enabled ($true) or disabled ($false)
		.PARAMETER Recurse
		Switch that indicates if the action shall be taken on the
		entity alone or on the entity and all its children.
		.EXAMPLE
		PS> Set-AlarmActionState -Entity $cluster -Enabled:$true
	#>
	
	param(
    [CmdletBinding()]
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)]
    [VMware.VimAutomation.ViCore.Impl.V1.Inventory.InventoryItemImpl]$Entity,
    [switch]$Enabled,
    [switch]$Recurse
	)
	
	begin{
		$alarmMgr = Get-View AlarmManager 
	}
	
	process{
		if($Recurse){
			$objects = @($Entity)
			$objects += Get-Inventory -Location $Entity
		}
		else{
			$objects = $Entity
		}
		$objects | %{
			$alarmMgr.EnableAlarmActions($_.Extensiondata.MoRef,$Enabled)
		}
	}
}

function Get-AlarmActionState {
	<#  
		.SYNOPSIS  Returns the state of Alarm actions.    
		.DESCRIPTION The function will return the state of the
		alarm actions on a vSphere entity or on the the entity
		and all its children
		.NOTES  Author:  Luc Dekens  
		.PARAMETER Entity
		The vSphere entity.
		.PARAMETER Recurse
		Switch that indicates if the state shall be reported for
		the entity alone or for the entity and all its children.
		.EXAMPLE
		PS> Get-AlarmActionState -Entity $cluster -Recurse:$true
	#>
	
	param(
    [CmdletBinding()]
    [Parameter(Mandatory=$true,ValueFromPipeline=$true)]
    [VMware.VimAutomation.ViCore.Impl.V1.Inventory.InventoryItemImpl]$Entity,
    [switch]$Recurse = $false
	)
	
	process {
		$Entity = Get-Inventory -Id $Entity.Id
		if($Recurse){
			$objects = @($Entity)
			$objects += Get-Inventory -Location $Entity
		}
		else{
			$objects = $Entity
		}
		
		$objects |
		Select Name,
		@{N="Type";E={$_.GetType().Name.Replace("Impl","").Replace("Wrapper","")}},
		@{N="Alarm actions enabled";E={$_.ExtensionData.alarmActionsEnabled}}
	}
}

$destinationServers = "atlvcs02,cybvcs02,mkdcvcs02,cybvcsvm01"
#"atlvcs01,atlvcs02,atlvcs03,atlvcs04,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$vcenters = $destinationServers.split(",");

$timestamp = Get-Date -format "yyyyMMdd-HH.mm"

$objects_output = ".\output\alarms\alarms_status-Objects-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

$ds_output = ".\output\alarms\alarms_status-Datastores-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

foreach ($vcenter in $vcenters)
{
	("Connecting vCenter server ..." + $vcenter)
	Connect-viserver -server $vcenter

	
	$objects_alarms = Get-Cluster -server $vcenter| Get-AlarmActionState -Recurse:$true |where {$_."Alarm actions enabled" -eq $false} 
	$objects_alarms | Add-Member -Name "vCenter" -Value $vcenter -MemberType NoteProperty
	$objects_alarms_report += $objects_alarms
	

	$ds_alarms = Get-View -server $vcenter -ViewType Datastore -Property Name,OverallStatus,alarmActionsEnabled |where {$_.AlarmActionsEnabled -eq $false} |select name, AlarmActionsEnabled
	$ds_alarms | Add-Member -Name "vCenter" -Value $vcenter -MemberType NoteProperty
	$ds_alarms_report += $ds_alarms
	Disconnect-VIServer -server $vcenter -Confirm:$false -Force:$true
}

$objects_alarms_report | Export-Csv $objects_output -NoTypeInformation
$ds_alarms_report | Export-Csv $ds_output -NoTypeInformation





