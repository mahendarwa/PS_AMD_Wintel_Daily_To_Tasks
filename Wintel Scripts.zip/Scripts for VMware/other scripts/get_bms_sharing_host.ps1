# This script requires PowerCLI 4.0 U1
#
# Create Disk Mapping Table
# Created by Arnim van Lieshout
# Http://www.van-lieshout.com

# Initialize variables
# $vms is a command separated list of VMs
$VCServer = "atlvcs01"
$DiskInfo= @()

$bms_vms = "ATLBDEDBD00,ATLBDEDBP00,ATLBDEWEBP00,ATLBMSDBD00,ATLBMSSSASPP00,ATLBMSSSASQP00,ATLBMSSSASQP01,SAM10"
#"SAM10,ATLBMSDEV00,ATLBMSDEV01,ATLBMSDEV02,ATLBDEDBP00,ATLBDEWEBP00,ATLBMSDBP00,ATLBMSSSASQP00,ATLBMSSSASQP01,ATLBMSSSASPP00"
$vms = $bms_vms.split(",");

foreach ($Vm in $vms){ 
Connect-VIServer $VCServer 
("Pulling information for " + $Vm)
$outputFile = ".\BMS\$Vm-$VCServer-vms_sharing_host" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
    get-vmhost (Get-VM $Vm).host | get-vm | Select PowerState, Guest, NumCpu, MemoryGB, Host| Export-Csv -Path $outputFile -NoTypeInformation
}

