$vcenter = Read-Host "Please enter the name of the vCenter server"
$match_address = Read-Host "Please enter the IP you are looking for"


Connect-VIServer -Server $vcenter

Get-VM | %{
      $vmIPs = $_.Guest.IPAddress
      foreach($ip in $vmIPs) {
          if ($ip -eq $match_address) {
              "Found VM with matching address: {0}" -f $_.Name
          }
      }
  }
  
Disconnect-VIServer -server $vcenter -Confirm:$false -Force:$true