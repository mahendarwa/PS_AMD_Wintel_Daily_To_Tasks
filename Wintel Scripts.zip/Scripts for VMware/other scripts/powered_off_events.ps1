

@"
===============================================================================
Title:         vminventory.ps1
Description:   Exports VM Information from vCenter into a .CSV file for importing into anything
Usage:         .\vminventory.ps1
Date:          10/15/2012
===============================================================================
"@
#### Get Virtual Center To Connect to:

$destinationServers = "atlvcsvm01"
#"atlvcs02,cybvcs02,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
#"atlvcsvm01"
#"atlvcs02,cybvcs02,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");


$outfile = ".\output\Powered-Off_VM_Report-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

foreach ($Server in $dstServers) {

	$VC = Connect-VIServer $Server

	$Report = @()
	$VMs = get-vm |Where-object {$_.powerstate -eq "poweredoff"}
	$Datastores = Get-Datastore | select Name, Id
	$VMHosts = Get-VMHost | select Name, Parent
### Get powered off event time:
	Get-VIEvent -Entity $VMs -MaxSamples ([int]::MaxValue) | 
	where {$_ -is [VMware.Vim.VmPoweredOffEvent]} |
	Group-Object -Property {$_.Vm.Name} | %{
		$lastPO = $_.Group | Sort-Object -Property CreatedTime -Descending | Select -First 1
		$vm = Get-VIObjectByVIView -MORef $lastPO.VM.VM
		$report += New-Object PSObject -Property @{
			vCenter = $Server
			VMName = $vm.Name
			Powerstate = $vm.Powerstate
			OS = $vm.Guest.OSFullName
			IPAddress = $vm.Guest.IPAddress[0]
			ToolsStatus = $VMView.Guest.ToolsStatus
			Host = $vm.host.name
			Cluster = $vm.host.Parent.Name
			Datastore = ($Datastores | where {$_.ID -match (($vmview.Datastore | Select -First 1) | Select Value).Value} | Select Name).Name
			NumCPU = $vm.NumCPU
			MemMb = [Math]::Round(($vm.MemoryMB),2)
			DiskGb = [Math]::Round((($vm.HardDisks | Measure-Object -Property CapacityKB -Sum).Sum * 1KB / 1GB),2)
			PowerOFF = $lastPO.CreatedTime
			Note = $vm.Notes  }
	}
	$VMs 
	
	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
}

#$Report = $Report | Sort-Object VMName

if ($Report) {
	$report | Export-Csv $outfile -NoTypeInformation}
else{
	"No PoweredOff events found"
}
