$hosts = import-csv ATL_3PAR-Host_list.csv



$outputFile = ".\All-luns-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

"Connecting vCenter servers ..."
Connect-VIServer $vcenter 


$report = @()
$luns = @{}


Foreach ($esx in $hosts.host_name) {


	("   Getting SCSI LUNs of host " + $esx + " ...")
	$lun = Get-ScsiLun -VmHost $esx -luntype disk
	
	("       Looping through luns")
	foreach ($lunid in $lun){
		$esxcli = Get-EsxCli -VMhost $esx
		$runtimepaths = $esxcli.storage.nmp.path.list() |where {$_.Device -eq $lunid.CanonicalName} |Select RuntimeName, GroupState, Path, PathSelectionPolicyPathConfig
		ForEach ($runtimepath in $runtimepaths) {					
			$row = "" | select VMName, GuestDevName, GuestDevID, VMHost, HDFileName, HDMode, HDsize, CanonicalName, RuntimeName, SanID, LunPath, State, Policy
			$row.VMName = $vm.Name
			$row.VMHost = $esx
			$row.CanonicalName = $lun.CanonicalName
			$row.RuntimeName = $runtimepath.RuntimeName
			$row.State = $runtimepath.GroupState
			$row.Policy = $runtimepath.PathSelectionPolicyPathConfig
			$row.LunPath = $runtimepath.Path
			
			$scsipath = $lunid | Get-Scsilunpath
			$row.SanID = $scsipath.SanID
			
			$report += $row
		}
	}

}

"Exporting report data to $outputFile ..."
$report | Export-CSV -Path $outputFile
"All done."