Param ($vcenter=$FALSE, $cluster=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter a Virtual Center or ESXi host name to get VMs with RDMs" }
if ($cluster -eq $FALSE) { $cluster = Read-Host "Please enter a Cluster Name to get VMs with RDMs" }

$outputFile = ".\output\All-VMS-PerDS-$cluster-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

"Connecting vCenter servers ..."
Connect-VIServer $vcenter
$report = @()

$datastores = Get-Cluster $cluster| Get-VMHost | Get-Datastore
foreach ($datastore in $datastores) {
    $ds = $datastore.Name
	
    $vms  = $datastore | Get-VM
		foreach ($vm in $vms) { 
			$row = "" | select VMName, DSName, DSType
			$row.VMName = $vm.Name
			$row.DSName = $ds
			$row.DSType = $datastore.Type
			$report += $row
		}
}

"Exporting report data to $outputFile ..."
$report | Sort DSName |Export-CSV -Path $outputFile
"All done."