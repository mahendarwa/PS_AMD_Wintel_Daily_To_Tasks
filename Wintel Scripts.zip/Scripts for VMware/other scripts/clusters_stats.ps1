$vcenter = Read-Host "Please enter the name of the vCenter server"
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"

$outputfile = ".\output\$vcenter-clusters_stats-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
Connect-viserver -server $vcenter

$report = @()

$dcs = get-datacenter  -server $vcenter
foreach ($dc in $dcs){
	$parents = (get-vmhost -location $dc).parent |sort name -unique
 
	foreach ($parent in $parents){
		$row = "" | select DataCenter, "Cluster/Folder Name", "Number of hosts", "Number of VMs"
		$vms = $parent | get-vm 
		$hosts = $parent | get-vmhost
		$row.DataCenter = $dc.Name
		$row."Cluster/Folder Name" = $parent.name
		$row."Number of hosts" = $hosts.count
		$row."Number of VMs" = $vms.count
		$parent.name
		$report += $row
	}
}

$report | Export-Csv -Path $outputFile -NoTypeInformation