Param ($vcenter=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter a Virtual Center or ESXi host name to get VMs with RDMs" }
$outputFile = ".\output\DS-Utilization-cluster-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

"Connecting vCenter servers ..."
Connect-VIServer $vcenter 

$report = @()
$dsclusters = Get-DatastoreCluster
foreach ($dscluster in $dsclusters){

	$datastores = $dscluster | Get-Datastore
	foreach ($ds in $datastores) {
		$row = "" | select DSCluster, DSName, Size, Provisioned, Difference, FreeSpace
		$dsusage = $ds |Get-VIew | Select -ExpandProperty Summary | Select Name, @{N="Provisioned"; E={[math]::round( ($_.Capacity - $_.FreeSpace + $_.Uncommitted)/1TB,2) }},@{N="Capacity"; E={[math]::round($_.Capacity/1TB,2)}},@{N="Difference"; E={[math]::round( ($_.FreeSpace - $_.Uncommitted)/1TB,2) }}, @{N="FreeSpace"; E={[math]::round( ($_.FreeSpace /1TB,2)) }}
		$row.DSCluster = $dscluster.Name
		$row.DSName = $dsusage.Name
		$row.Size = $dsusage.Capacity
		$row.Provisioned = $dsusage.Provisioned
		$row.Difference = $dsusage.Difference
		$row.FreeSpace = $dsusage.FreeSpace
		$report += $row

	}
	$row = "" |Select DSCluster
	$row.DSCluster = $dscluster.Name
	$report += $row
	#$row = ""
	#$report += $row
}

"Exporting report data to $outputFile ..."
$report | Export-CSV -Path $outputFile
"All done."