$vcenter = Read-Host "Please enter the name of the vCenter server"
Connect-VIServer $vcenter 
$outputFile = ".\output\"+$vcenter+ "network_report"+ (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$HOSTS = Get-VMHost
&{foreach ($vmhost in $hosts){
Get-VMHost $vmhost | % {
        $esx = $_
        $vNicTab = @{}
        $esx.ExtensionData.Config.Network.Vnic | %{
            $vNicTab.Add($_.Portgroup,$_)
        }
        foreach($vsw in (Get-VirtualSwitch -VMHost $esx)){
            foreach($pg in (Get-VirtualPortGroup -VirtualSwitch $vsw)){
                Select -InputObject $pg -Property @{N="Host";E={$vmhost.Name}},
					@{N="vSwitch";E={$vsw.Name}},
                    @{N="Portgroup";E={$pg.Name}},
                    @{N="VLAN";E={$pg.VLanId}},
                    @{N="Active NIC";E={
                                    If ($pg.extensiondata.spec.policy.Nicteaming.NicOrder.ActiveNic) {
                                    [string]::Join(',',$pg.extensiondata.spec.policy.Nicteaming.NicOrder.ActiveNic)
                                    } Else {
                                        [string]::Join(',',$vsw.ExtensionData.Spec.Policy.NicTeaming.NicOrder.ActiveNic) 
                                        }}},
                    @{N="Standby NIC";E={
                                    If ($pg.extensiondata.spec.policy.Nicteaming.NicOrder.StandbyNic) {
                                    [string]::Join(',',$pg.extensiondata.spec.policy.Nicteaming.NicOrder.StandbyNic)
                                    } Else {
                                        [string]::Join(',',$vsw.ExtensionData.Spec.Policy.NicTeaming.NicOrder.StandbyNic) 
                                        }}},
                    @{N="Device";E={if($vNicTab.ContainsKey($pg.Name)){$vNicTab[$pg.Name].Device}}},
                    @{N="IP";E={if($vNicTab.ContainsKey($pg.Name)){$vNicTab[$pg.Name].Spec.Ip.IpAddress}}},
					@{N="Subnet";E={if($vNicTab.ContainsKey($pg.Name)){$vNicTab[$pg.Name].Spec.Ip.SubnetMask}}},
					@{N="Mac";E={if($vNicTab.ContainsKey($pg.Name)){$pg.extensiondata.port.Mac}}}
            }
        }
    }
}} | Export-Csv -Path $outputFile -NoTypeInformation -UseCulture