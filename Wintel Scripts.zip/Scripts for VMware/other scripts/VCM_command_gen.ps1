
VNet_ODC_SMARTPLAY_C_929

Get-VMHost 

Get-VMHost -name esx1 | Get-VirtualPortGroup -Name "Inside-VLAN" | Set-VirtualPortGroup -Name "VNet_ODC_SMARTPLAY_C_929"

Get-VirtualPortGroup -Name "VNet_ODC_FTR_929" | Set-VirtualPortGroup -Name "VNet_ODC_SMARTPLAY_C_929"


Write-Host "This script with generate the commands to configure VLANS and Host profiles in a VCM"
Write-Host ""

Write-Host "The ESX console VLAN should be called ESX_Console..."
Write-Host "The ESX vMotion VLAN should be called ESX_VMotion..."
Write-Host "If using NFS, the NFS VLAN should be called NFS_Storage..."
Write-Host "The uplink set should be called SUS1"
Write-Host "If using SAN, the SAN fabrics must be called SAN_A and SAN_B"
Write-Host "*** If you don't use those names for those VLANs this script will not work"
Write-Host ""
Write-Host "Also, the CSV file fist line table header should be like this Network_Name,VLAN "

$vlans_files = Read-Host "Please enter the name of a command separated file with the names of the VLANs"
$vCenter = Read-Host "Please enter the name of the vCenter"
$blade_size = "Is this a Half Height blade or Full Height blade? (enter HH or FH)"
if (($blade_size -ne "HH") -and ($blade_size -ne "HH")) {exit}
$nfs_san = Read-Host "Will this profile use SAN, NFS or BOTH (enter SAN NFS or BOTH)"
if (($nfs_san -ne "SAN") -and ($nfs_san -ne "NFS") -and ($nfs_san -ne "BOTH")) {exit}
if (($nfs_san -eq "BOTH") -and ($blade_size -ne "FH")) {Write-Host "You are selecting NFS and SAN in a half height blade. That means vMotion and Management will share the first NIC"}


$vlans = Import-CSV $vlans_files -ErrorAction Stop

