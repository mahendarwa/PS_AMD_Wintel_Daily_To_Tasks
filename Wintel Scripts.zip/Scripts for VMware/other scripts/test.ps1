Get-Cluster "SQL-PRD"| Get-VMHost | Get-Datastore | Foreach-Object {
    $ds = $_.Name
    $_ | Get-VM | Select-Object Name,@{n='DataStore';e={$ds}}
}