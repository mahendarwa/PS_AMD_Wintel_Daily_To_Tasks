$destinationServers = "atlvcs02,atlvcs04,cybvcs02,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
# all vcenters: atlvcs01,atlvcs02,atlvcs03,atlvcs04,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$vcenters = $destinationServers.split(",");

$outputFile = ".\output\Hosts_in_MaintenanceMode-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()
#Disconnect-VIServer -Server * -force -confirm:$false
foreach ($vcenter in $vcenters)
{
	("Connecting vCenter server ..." + $vcenter)
	Connect-viserver -server $vcenter
#	$clusters = get-cluster -server $vcenter
#	foreach ($cluster in $clusters){
		$vmhosts = Get-VMHost |where {($_.State -ne "Connected")}
		if ($vmhosts -ne $null){
			foreach ($vmhost in $vmhosts){
				$row = "" | select VCenter, Host, Cluster, State, Reason, Ticket, Date, Name, "Additional Comments"
				$row.VCenter = $vcenter
				$row.Host = $vmhost.Name
				$row.Cluster = $vmhost.Parent
				$row.State = $vmhost.State
				$row.Ticket = $vmhost.CustomFields.Item("Incident #")
				$row.Date = $vmhost.CustomFields.Item("Date")
				$row.Name = $vmhost.CustomFields.Item("Worked By")
				$report += $row
				$vmhost.Name
			}
		}
#	}
	$row = @()
	$report += $row
	Disconnect-VIServer -server $vcenter -Confirm:$false -Force:$true
}

$report | Export-Csv -Path $outputFile -NoTypeInformation