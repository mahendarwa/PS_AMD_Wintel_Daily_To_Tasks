$destinationServers = "atlvcs01,atlvcs02,atlvcs03,atlvcs04,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$vcenters = $destinationServers.split(",");

$outputFile = ".\output\Hosts_in_MaintenanceMode-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
$report = @()

foreach ($vcenter in $vcenters)
{
	("Connecting vCenter server ..." + $vcenter)
	Connect-viserver -server $vcenter
	$clusters = get-cluster
	foreach ($cluster in $clusters){
		$vmhosts = get-cluster $cluster | Get-VMHost -State maintenance 
		if ($vmhosts -ne $null){
			foreach ($vmhost in $vmhosts){
				$row = "" | select VCenter, Host, Cluster, Reason, Ticket, Date, Name, "Additional Comments"
				$row.VCenter = $vcenter
				$row.Host = $vmhost.Name
				$row.Cluster = $cluster.Name
				if ($vmhosts.CustomFields.Item("Incident #") -ne $null) {$row.Ticket = $vmhosts.CustomFields.Item("Incident #")}
				if ($vmhosts.CustomFields.Item("Date") -ne $null) {$row.Date = $vmhosts.CustomFields.Item("Date")}
				if ($vmhosts.CustomFields.Item("Worked By") -ne $null) {$row.Name = $vmhosts.CustomFields.Item("Worked By")}
				$report += $row
				$vmhost.Name
			}
		}
	}
	$row = @()
	$report += $row
}

$report | Export-Csv -Path $outputFile -NoTypeInformation