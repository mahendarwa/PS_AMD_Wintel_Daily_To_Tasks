
$destinationServers = Read-Host "Please enter one or more  Virtual Centers separated by commas"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");

$outputFile = ".\output\Hosts_clusters_list" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

$date = get-date -Format yyyy-MM-dd
$report = @()

foreach ($Server in $dstServers) {
	Connect-VIServer $Server
	("Connecting vCenter server ..." + $vcenter)
	$vm_hosts = @()
	$vcenter_info = $global:DefaultVIServer.ExtensionData.Content.About |select version,build
	$clusters = get-cluster
	$vm_hosts = get-vmhost
	$row = "" | Select vCenter, Cluster, Host, Version, Model
	
	$row.vCenter = $Server
	$row.Version = $vcenter_info.version
	$row.build = $vcenter_info.build
	$row.Clusters = $clusters.count
	$row."50_hosts" = ($vm_hosts| where {$_.version -eq "5.0.0"}).count
	$row."55_hosts" = ($vm_hosts| where {$_.version -eq "5.5.0"}).count
	$row."VM Count" = $vms.count
	$row.Model = $_.Hardware.SystemInfo.Model
	$report += $row
	
	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
	
#	Write-Host "Copying '" $baseline.Name "' to the server $Server" 
#	Invoke-Expression $command
}

$report | Export-Csv -Path $outputFile -NoTypeInformation
