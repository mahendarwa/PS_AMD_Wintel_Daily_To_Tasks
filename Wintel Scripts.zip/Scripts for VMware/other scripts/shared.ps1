Param ($VIServer=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($VIServer -eq $FALSE) { $VIServer = Read-Host "Please enter a Virtual Center or ESXi host name to get VMs with RDMs" }
$csvfile = ".\$VIServer-rdmvms-$timestamp.csv"
Connect-VIServer $VIServer

#Create the array
$array = @()
$vms = get-cluster "PRD-WIN_SAN-00_G8" | get-vm
#Loop for BusSharingMode
foreach ($vm in $vms)
{
	$disks = $vm | Get-ScsiController | Where-Object {$_.BusSharingMode -eq "Physical" -or $_.BusSharingMode -eq "Virtual"}
	foreach ($disk in $disks){
		$REPORT = New-Object -TypeName PSObject
		$REPORT | Add-Member -type NoteProperty -name Name -Value $vm.Name
		$REPORT | Add-Member -type NoteProperty -name VMHost -Value $vm.VMHost
		$REPORT | Add-Member -type NoteProperty -name Mode -Value $disk.BusSharingMode
		#$REPORT | Add-Member -type NoteProperty -name Type -Value “BusSharing”
		$array += $REPORT
	}
}
$array | out-gridview