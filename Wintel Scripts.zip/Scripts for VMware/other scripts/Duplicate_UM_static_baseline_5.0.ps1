
$destinationServers = "atlvcs01,atlvcs02,cybvcs01,cybvcs02,cybvcs03,mkdcvcs01,mkdcvcs02,pngvcs01,suzvcs02,islvcs01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");



$date = get-date -Format yyyy-MM-dd

foreach ($Server in $dstServers) {
	Connect-VIServer $Server
	("Connecting vCenter server ..." + $vcenter)
	$baseline = Get-PatchBaseline "Critical Host Patches (Predefined)"
	
	$command = 'New-PatchBaseline -Name "Critical Host Patches ($date)" -Description $baseline.Description -Static -TargetType $baseline.TargetType  -IncludePatch $baseline.CurrentPatches'

	Write-Host "Copying '" $baseline.Name "' to the server $Server" 
	Invoke-Expression $command
	
	$baseline = Get-PatchBaseline "Non-Critical Host Patches (Predefined)"

	$command = 'New-PatchBaseline -Name "Non-Critical Host Patches ($date)" -Description $baseline.Description -Static -TargetType $baseline.TargetType -IncludePatch $baseline.CurrentPatches'
	Write-Host "Copying '" $baseline.Name "' to the server $Server" 
	Invoke-Expression $command
}


