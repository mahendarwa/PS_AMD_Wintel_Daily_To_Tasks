Connect-VIServer atlvcsvm01
Get-HardDisk -vm AUSEDWDBP00  |where {$_.Name -eq "Hard disk 16"} | Move-HardDisk -Datastore "SQL-PRD_EDW_DATA_XIO03" -RunAsync -confirm:$false

Disconnect-VIServer -Server atlvcsvm01 -Confirm:$false -Force:$true