
$destinationServers = "atlvcs02,cybvcs02,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
#"atlvcsvm01"
#"atlvcs02,cybvcs02,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");

foreach ($Server in $dstServers) {
	("Connecting vCenter server ..." + $Server)
	Connect-VIServer $Server

# Locate Inventory Item rootFolder
$folder = Get-Folder -NoRecursion
$entity = Get-View $folder
# Create permissions for root folder
$entityMoRef = new-object VMware.Vim.ManagedObjectReference
$entityMoRef.type = $entity.MoRef.type
$entityMoRef.value = $entity.MoRef.value
$permission = New-Object VMware.Vim.Permission[](2)
$permission[0] = New-Object VMware.Vim.Permission
$permission[0].principal = "AMD\dl.virtual-compute-Team"
$permission[0].group = $true
$permission[0].propagate = $true
$newRoleId = (get-virole | where-object {$_.Name -match "^L1_VMware$"} | select-object Id)
$permission[0].roleId = $newRoleId.Id
$permission[1] = New-Object VMware.Vim.Permission
$permission[1].principal = "AMD\dl.virtual-compute-l3"
$permission[1].group = $true
$permission[1].propagate = $true
$newRoleId = (get-virole | where-object {$_.Name -match "^Admin$"} | select-object Id)
$permission[1].roleId = $newRoleId.Id

# Get Authorization Manager
$_this = Get-View -Id AuthorizationManager-AuthorizationManager
# Set permissions
$_this.SetEntityPermissions($entityMoRef,$permission)

	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
}