$vcenter = Read-Host "Please enter the name of the vCenter server"
Connect-VIServer $vcenter 
$outputFile = ".\output\"+$vcenter+ "network_details"+ (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

Get-VMHostNetworkAdapter | select VMhost, Name, ManagementTrafficEnabled, IP, SubnetMask, Mac, PortGroupName, vMotionEnabled, mtu, FullDuplex, BitRatePerSec| Export-Csv -Path $outputFile -NoTypeInformation -UseCulture

Disconnect-VIServer -server $vcenter -Confirm:$false -Force:$true