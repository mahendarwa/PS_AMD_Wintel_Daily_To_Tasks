$vcenter = Read-Host "Please enter the name of the vCenter server"

Connect-viserver -server $vcenter

$outputFile = ".\output\DS_utilization_per_cluster_$vcenter" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

$report = @()

foreach ($cluster in get-cluster){

("Getting VM list for $cluster")
		$vms = $cluster | get-vm | Select Name, UsedSpaceGB, ProvisionedSpaceGB
		foreach ($vm in $vms){
			$row = "" | select Cluster, VMName, Space_Used, Space_provisioned, Space_Not_provisioned
			$row.cluster = $cluster.Name
			$row.VMName = $vm.Name
			$row.Space_Used = [math]::Round($vm.UsedSpaceGB,2)
			$row.Space_provisioned = [math]::Round($vm.ProvisionedSpaceGB,2)
			$row.Space_Not_provisioned = [math]::Round(($vm.ProvisionedSpaceGB - $vm.UsedSpaceGB),2)
			$report += $row
			}
		$row = "" | select Cluster, VMName, Space_Used, Space_provisioned, Space_Not_provisioned
		$row.cluster = $cluster.Name
		$row.Space_Used = ($vms | Measure-Object -Property UsedSpaceGB -sum).sum
		$row.Space_provisioned = ($vms | Measure-Object -Property ProvisionedSpaceGB -sum).sum
		$row.Space_Thin_provisioned = [math]::Round(($row.Space_provisioned - $row.Space_Used),2)
		$report += $row
		$row = "" | select Cluster, VMName, Space_Used, Space_provisioned, Space_Not_provisioned
		$report += $row
}


$report | Export-Csv -Path $outputFile -NoTypeInformation
