# This script requires PowerCLI 4.0 U1
#
# Create Disk Mapping Table
# Created by Arnim van Lieshout
# Http://www.van-lieshout.com

# Initialize variables
# $VCServerList is a comma-separated list of vCenter servers
$VCServerList = Read-Host "Enter vCenter server"
$DiskInfo= @()
$Vm = Read-Host "Enter VMName to create disk mapping for"

$outputFile = ".\output\$Vm-$VCServerList-vmdk_mapping" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

# Set Default Server Mode to Multiple
Set-PowerCLIConfiguration -DefaultVIServerMode Multiple -Confirm:$false | Out-Null
# Connect to vCenter Server(s)
foreach ($VCServer in $VCServerList) {Connect-VIServer -Server "$VCServer" | Out-Null}

if (($VmView = Get-View -ViewType VirtualMachine -Filter @{"Name" = $Vm})) {
    $WinDisks = Get-WmiObject -Class Win32_DiskDrive -ComputerName $VmView.Name
    foreach ($VirtualSCSIController in ($VMView.Config.Hardware.Device | where {$_.DeviceInfo.Label -match "SCSI Controller"})) {
        foreach ($VirtualDiskDevice in ($VMView.Config.Hardware.Device | where {$_.ControllerKey -eq $VirtualSCSIController.Key})) {
            $VirtualDisk = "" | Select SCSIController, DiskName, SCSI_Id, DiskFile, DiskSize, WindowsDisk, DataStore, VMs
            $VirtualDisk.SCSIController = $VirtualSCSIController.DeviceInfo.Label
            $VirtualDisk.DiskName = $VirtualDiskDevice.DeviceInfo.Label
            $VirtualDisk.SCSI_Id = "$($VirtualSCSIController.BusNumber) : $($VirtualDiskDevice.UnitNumber)"
            $VirtualDisk.DiskFile = $VirtualDiskDevice.Backing.FileName
			$VirtualDisk.DataStore = $VirtualDiskDevice.Backing.FileName.Split(']')[0].TrimStart('[')
			$vm_names = (Get-Datastore -Name $VirtualDisk.DataStore).Extensiondata.Vm|%{(Get-View -Id $_.toString()).name}
			$vms = ""
			$counter = $($vm_names | measure).Count
			if ($counter -gt "1"){
			foreach ($vm in $vm_names){
				$vms = $vms + $vm +", "
				}
			}
			else {$vms = $vm_names}
			$VirtualDisk.VMs = $vms
            $VirtualDisk.DiskSize = $VirtualDiskDevice.CapacityInKB * 1KB / 1GB
            # Match disks based on SCSI ID
            $DiskMatch = $WinDisks | ?{($_.SCSIPort � 1) -eq $VirtualSCSIController.BusNumber -and $_.SCSITargetID -eq $VirtualDiskDevice.UnitNumber}
            if ($DiskMatch){
                $VirtualDisk.WindowsDisk = "Disk $($DiskMatch.Index)"
            }
            else {Write-Host "No matching Windows disk found for SCSI id $($VirtualDisk.SCSI_Id)"}
            $DiskInfo += $VirtualDisk
        }
    }
    $DiskInfo | Export-Csv -Path $outputFile -NoTypeInformation
}
else {Write-Host "VM $Vm Not Found"}

Disconnect-VIServer * -Confirm:$false