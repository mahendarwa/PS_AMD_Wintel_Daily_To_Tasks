
$destinationServers = "atlvcs01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");



$date = get-date -Format yyyy-MM-dd

foreach ($Server in $dstServers) {
	Connect-VIServer $Server
	("Connecting vCenter server ..." + $vcenter)
	$baseline = Get-PatchBaseline "HP Offline_Bundle_Jun-2015"
	
	$command = 'New-PatchBaseline -Name "HP Offline_Bundle_Oct-2015" -Description $baseline.Description -Static -TargetType $baseline.TargetType  -IncludePatch $baseline.CurrentPatches -Extension'

	Write-Host "Copying '" $baseline.Name "' to the server $Server" 
	Invoke-Expression $command
}


