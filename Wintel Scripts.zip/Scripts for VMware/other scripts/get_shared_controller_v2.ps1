#Param ($VIServer=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
#if ($VIServer -eq $FALSE) { $VIServer = Read-Host "Please enter a Virtual Center or ESXi host name to get VMs with RDMs" }
$csvfile = ".\output\$VIServer-shared_controllers-$timestamp.csv"
#Connect-VIServer $VIServer
$report = @()
$clusters = Get-Cluster
foreach ($cluster in $clusters){
	$vms = $cluster | Get-VM
		foreach($vm in $vms) { 
			$disks = $vm | Get-ScsiController | Where {$_.BusSharingMode -eq "Physical"}
			foreach ($disk in $disks){
				$row = "" | select ClusterName, VMName, VMHost, BusSharingMode
				$row.ClusterName = $cluster.Name
				$row.VMName = $vm.Name
				$row.VMHost = $vm.VMHost
				$row.BusSharingMode = $disk.BusSharingMode
				$report += $row
			}
			$disks = $vm | Get-ScsiController | Where {$_.BusSharingMode -eq "Virtual"}
			foreach ($disk in $disks){
				$row = "" | select ClusterName, VMName, VMHost, BusSharingMode
				$row.ClusterName = $cluster.Name
				$row.VMName = $vm.Name
				$row.VMHost = $vm.VMHost
				$row.BusSharingMode = $disk.BusSharingMode
				$report += $row
			}
		}
}
$report | export-csv -NoTypeInformation $csvfile