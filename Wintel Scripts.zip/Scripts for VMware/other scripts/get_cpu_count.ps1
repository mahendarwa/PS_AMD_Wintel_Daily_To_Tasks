$destinationServers = "mkdcvcs02"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01

$dstServers = $destinationServers.split(",");

$date = get-date -Format yyyy-MM-dd
$report = @()

foreach ($Server in $dstServers) {
	$outputFile = ".\output\sockets_count-$Server-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"

	Connect-VIServer $Server
	$myCol = @()

		ForEach ($vmhost in Get-VMHost)
		{
			$VMView = $VMhost | Get-View
			$VMSummary = "" | Select HostName, ClusterName, MemorySizeGB, CPUSockets, CPUCores
			$VMSummary.HostName = $VMhost.Name
			$VMSummary.ClusterName = $VMhost.parent
			$VMSummary.MemorySizeGB = $VMview.hardware.memorysize / 1024Mb
			$VMSummary.CPUSockets = $VMview.hardware.cpuinfo.numCpuPackages
			$VMSummary.CPUCores = $VMview.hardware.cpuinfo.numCpuCores
			$myCol += $VMSummary
		}

	$myCol | export-csv -path $outputFile -NoTypeInformation
	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
}