﻿connect-viserver atlvcsvm01
$VMs = Get-Content F:\Yns\vmlist.txt
#enter the name of the VM that you wish to change

ForEach ($Item in $VMs)
    {
    $vm = get-vm $Item

    #loop through the hard disks in the VM
    foreach($hd in get-harddisk -DiskType RawPhysical,RawVirtual -vm $vm | select *)
        {
            #if a physical RDM
            if($hd.Persistence -eq 'IndependentPersistent')
            {
                #look up the lun
                $lun = Get-ScsiLun -CanonicalName $hd.ScsiCanonicalName -VmHost $vm.VMHost

                
                if($lun.MultipathPolicy -ne 'MostRecentlyUsed')
                {
                    set-scsilun -ScsiLun $lun -MultipathPolicy MostRecentlyUsed 
					
                }
            }
        }
    } 