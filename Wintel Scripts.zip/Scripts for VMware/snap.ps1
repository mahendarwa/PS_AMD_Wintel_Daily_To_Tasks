﻿$vm = Read-Host 'Please provide VM name'

$Seconds = Read-Host 'Please provide fsr.maxSwitchoverSeconds value in seconds'

$snapname = 'Temp'

get-vm $vm | New-AdvancedSetting -Name fsr.maxSwitchoverSeconds -Value $Seconds -Confirm:$false

get-vm $vm | New-Snapshot -Name $snapname

get-vm $vm | Get-Snapshot -Name $snapname | Remove-Snapshot -Confirm:$false