﻿# restart VMS


$vmNames = Get-Content -Path C:\Users\sgopalun\Desktop\VMstart\list.txt
foreach ($vm in $vmNames)
{
Get-VM -Name $vm | Restart-VM

} 