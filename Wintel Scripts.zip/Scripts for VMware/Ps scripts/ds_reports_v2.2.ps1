
$destinationServers = "atlvcs02,cybvcs02,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
#"atlvcsvm01"
#"atlvcs02,cybvcs02,mkdcvcs02,pngvcs01,suzvcs02,islvcs01,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01"
# 5.5 ,atlvcs03,atlvcs04,atlvcsleo01,atlvcsview01,mkdcvcsvm01,atlvcsvm01,atlvcsgrid,cybvcsvm01
$dstServers = $destinationServers.split(",");

$date = get-date -Format yyyy-MM-dd-HHmm

foreach ($Server in $dstServers) {
	("Connecting vCenter server ..." + $vcenter)
	Connect-VIServer $Server
	$Datastores = Get-Datastore | Select @{N='Datacenter';E={$_.Datacenter.Name}},
	@{N='DSCluster';E={Get-DatastoreCluster -Datastore $_ | Select -ExpandProperty Name}},
	Name,
	CapacityGB,
	@{N='FreespaceGB';E={[math]::Round($_.FreespaceGB,2)}},
	@{N='ProvisionedSpaceGB';E={
			[math]::Round(($_.ExtensionData.Summary.Capacity - $_.Extensiondata.Summary.FreeSpace + $_.ExtensionData.Summary.Uncommitted)/1GB,2)}},
	@{N='UnCommittedGB';E={[math]::Round($_.ExtensionData.Summary.Uncommitted/1GB,2)}},
	@{N='Free_%';E={
			[math]::Round(($_.Extensiondata.Summary.FreeSpace / $_.ExtensionData.Summary.Capacity ) * 100,2)}},
	@{N='Provisioned_%';E={
			[math]::Round((($_.ExtensionData.Summary.Capacity - $_.Extensiondata.Summary.FreeSpace + $_.ExtensionData.Summary.Uncommitted) / $_.ExtensionData.Summary.Capacity ) * 100,2)}},
	@{N='VM';E={$_.ExtensionData.VM.Count}},
	@{N='Shared';E={$_.extensiondata.summary.MultipleHostAccess}} | Sort Datacenter, DSC, Name
	
#add warnings for low space
	$datastores | Add-Member -Name "ANALYSIS" -Value {""} -MemberType NoteProperty
	$datastores | %{
			if ($_.'Provisioned_%' -gt "100") {
				$_."ANALYSIS" = @{$true="Overprovisioned AND <25% free space";$false=""}[$_."Free_%" -le '25']
				$_."ANALYSIS" = @{$true="Overprovisioned AND <10% FREE SPACE!!";$false=$_."ANALYSIS"}[$_."Free_%" -le '10']
				}
			else {
				$_."ANALYSIS" = @{$true="Underprovisioned AND <2% FREE SPACE!!";$false=""}[$_."Free_%" -le '2']
				}
			}
#generate report with non-clustered Datastores
	$datastores | where {!$_.DSCluster} | Export-Csv ".\output\$Server-StandAlone_Datastores-$date.csv" -NoTypeInformation -UseCulture
	$ClusteredDs = $datastores | where {$_.DSCluster -ne $null}
	$DsClusters = $ClusteredDs |select DSCluster -unique

#process Datastore clusters, and add a warning to the cluster is free < 25%	
	$report = @()	
	foreach ($DsCluster in $DsClusters) {
		$row = "" | Select Datacenter,'DSCluster',Name,CapacityGB,'FreespaceGB','ProvisionedSpaceGB','UnCommittedGB','Free_%','Provisioned_%','VM','Shared','ANALYSIS'
		$ThisClusterDatastores = $ClusteredDs | where {$_.DSCluster -eq $DsCluster.DSCluster}
			foreach ($ThisClusterDatastore in $ThisClusterDatastores){
				$report += $ThisClusterDatastore
			}
			$row.DSCluster = $DsCluster.DSCluster
			$row.CapacityGB =  ($ThisClusterDatastores | Measure-Object -Property CapacityGB -sum).sum
			$row.FreespaceGB =  ($ThisClusterDatastores | Measure-Object -Property FreespaceGB -sum).sum
			$row.ProvisionedSpaceGB =  ($ThisClusterDatastores | Measure-Object -Property ProvisionedSpaceGB -sum).sum
			$row.'Free_%' = [math]::Round(($row.FreespaceGB / $row.CapacityGB) * 100,2)
			$row.'ANALYSIS' = @{$true="< 25% free";$false=""}[$row."Free_%" -le '25']
			#$row.CapacityGB =  [math]::Round(($ThisClusterDatastores | Measure-Object -Property CapacityGB -sum).sum/1GB,2)
			$report += $row
			$row = "" | Select Datacenter,'DSCluster',Name,CapacityGB,'FreespaceGB','ProvisionedSpaceGB','UnCommittedGB','Free_%','Provisioned_%','VM','Shared'
			$report += $row
	}

	$report | Export-Csv ".\output\$Server-Clustered_Datastores-$date.csv" -NoTypeInformation -UseCulture
	Disconnect-VIServer -Server $Server -Confirm:$false -Force:$true
}

