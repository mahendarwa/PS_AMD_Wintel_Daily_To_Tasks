## satp rule creation for XtremeIO
# Usage: Run the script, and provide a vCenter name, and the location of the servers to the get the rule.
# The location can be a folder, cluster, Datacenter, or even a vCenter to apply the rule to every host.

Param ($vcenter=$FALSE, $location=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter a Virtual Center name" }
if ($location -eq $FALSE) { $location = Read-Host "Please enter the location of the server or servers to get the rule" }

$outputFile = ".\XIO-Rules-$vcenter-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
"Connecting vCenter servers ..."
Connect-VIServer $vcenter 

$report = @()


foreach($esx in Get-VMhost -Location $location){
	$esxcli = Get-EsxCli -VMHost $esx
	# List XIO rules
	$esxcli.storage.nmp.satp.rule.list() | where {$_.description -like "*XtremIO*"}
	#Create a new satp rule for XtremeIO
	$result = $esxcli.storage.nmp.satp.rule.add($null,"tpgs_off","XtremIO Active/Active",$null,$null,$null,"XtremApp",$null,"VMW_PSP_RR","iops=1","VMW_SATP_DEFAULT_AA",$null,"vendor","XtremIO")
	# List XIO Rules
	$esxcli.storage.nmp.satp.rule.list() | where {$_.description -like "*XtremIO*"}
	Write-Host "Host:", $esx.Name, "Result", $result
	$row = "" | select HostName, Result
	$row.HostName = $esx.Name
	$row.Result = $result
	$report += $row
}
Disconnect-VIServer -Server $vCenter -Confirm:$false -Force:$true
$report | Export-CSV -Path $outputFile -NoTypeInformation