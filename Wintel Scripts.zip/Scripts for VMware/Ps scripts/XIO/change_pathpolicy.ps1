Get-VMhost -location SAP-PRD_DB01 |Get-ScsiLun -LunType "disk" |where {$_.CanonicalName -like "naa.514*"} | Set-ScsiLun -MultipathPolicy “RoundRobin”



esxcli storage nmp device set –device <naa_id> –psp VMW_PSP_RR