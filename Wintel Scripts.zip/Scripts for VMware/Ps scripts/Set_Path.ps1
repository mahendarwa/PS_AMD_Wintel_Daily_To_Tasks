connect-viserver atlvcsvm01
$esxhost=get-content F:\hosts4.txt
$diskID = "naa.6*" # for HP 3PAR LUNS
Get-VMHost $esxhost |Get-ScsiLun -LunType "disk"|where {$_.ConsoleDeviceName -like "/vmfs/devices/disks/$diskID*"} |where {$_.MultipathPolicy -ne "RoundRobin"}|Set-ScsiLun -MultipathPolicy "RoundRobin"
