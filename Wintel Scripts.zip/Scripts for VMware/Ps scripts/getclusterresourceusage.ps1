﻿#####READ BELOW#####
#UPDATE YOUR OUTPUT FILE LOCATION
#UPDATE THE FILE CONTAINS A LIST OF VCENTER
#AUTHOR: GEORGE LIM
###########################
#Add-PSSnapin VMware.VimAutomation.Core

#Disconnect-VIServer -Confirm:$false

#vCenter List
$allvcenters = "C:\scripts\capacity\all_vcenters.txt"
#$allvcenters = "C:\scripts\capacity\cybvcs03.txt"

#Output CVS file
$outfile = "C:\scripts\capacity\clusterusage_final.csv"

#Clear up the output file
Clear-Content $outfile

#Create a stream write which is faster than out-file or export-cvs
$stream = [System.IO.StreamWriter] "$outfile"
$stream.Flush();

#Start writing to the output file
$header = "Description`n"
$header += "S=SMALL (2CPU/4GB)`n"
$header += "M=MEDIUM (4CPU/8GB)`n"
$header += "L=LARGE (4CPU/16GB)`n"
$header += "XL=XLARGE (8CPU/32GB)`n"
$header += "X = 2:1 CPU RATIO`n"
$header += "Y = 4:1 CPU RATIO`n"
$header += "`n"
$header += "vCenter, ClusterName, ESX, VMs, PCPU, PMEM, vCPU, vMEM, CPURATIO, AVAILMEM"
$header += ", SX-2CPU, MLX-4CPU,XLX-8CPU, SY-2CPU, MLY-4CPU, XLY-8CPU, S-4GB, M-8GB, L-16GB, XL-32GB"
echo $header
$stream.WriteLine($header)


Get-Content $allvcenters | %{ 

#$vc_host = "atlvcs02.amd.com"
$vc_host = $_ 
$vc_conn = 0
$vc_conn = Connect-VIServer -Server $vc_host


$vc_clusters = get-cluster 
#$vc_cluster = get-cluster atl_leostream01


Foreach ($vc_cluster in $vc_clusters){

#Get Cluster Summary
$vc_cluster_pcpu = $vc_cluster.ExtensionData.Summary.NumCpuCores
$vc_cluster_hosts = $vc_cluster.ExtensionData.Summary.NumHosts
$vc_cluster_pmem = [math]::round($vc_cluster.ExtensionData.Summary.EffectiveMemory / 1KB,0)

#Use Get-View and Filters for faster search results
#API REFERENCE: https://www.vmware.com/support/developer/vc-sdk/visdk25pubs/ReferenceGuide/vim.VirtualMachine.html#field_detail
#Exact search for cluster name ^ClusterName$. We don't want it to find more than one
 #Put whatever we find in objects so we can sort and sum it up later
$vms_view = get-view -ViewType "VirtualMachine" `
 -Property Name,runtime.powerstate,Config.Hardware.NumCPU,Config.Hardware.memorymb `
 -Filter @{"Runtime.powerstate"="PoweredOn"} `
 -SearchRoot $(get-view -ViewType "ClusterComputeResource" `
 -Filter @{"Name"="^$vc_cluster$"} -Property Name).MoRef | `
 Select-Object @{N="VCPU";E={$_.Config.Hardware.NumCPU}},`
 @{N="VMEM";E={[math]::round($_.Config.Hardware.MemoryMB/1024,0)}}


 $vcp_total,$vmem_total,$vmx = 0
 
 $vcpu_total = ($vms_view | Measure-Object -Property vcpu -Sum).Sum
 $vmem_total = ($vms_view | Measure-Object -Property vmem -Sum).Sum
 $vmx = ($vms_view | Measure-Object).Count
 
 if($vc_cluster_pcpu -ne 0){
 $cpu_ratio = [math]::round($vcpu_total / $vc_cluster_pcpu,2)
 $availmem = $vc_cluster_pmem - $vmem_total
 }
 #MATH
 $sx = [math]::Floor((($vc_cluster_pcpu*2)-$vcpu_total)/2)
 $mlx = [math]::Floor((($vc_cluster_pcpu*2)-$vcpu_total)/4)
 $xlx = [math]::Floor((($vc_cluster_pcpu*2)-$vcpu_total)/8)
 $sy = [math]::Floor((($vc_cluster_pcpu*4)-$vcpu_total)/2)
 $mly = [math]::Floor((($vc_cluster_pcpu*4)-$vcpu_total)/4)
 $xly = [math]::Floor((($vc_cluster_pcpu*4)-$vcpu_total)/8)
 $s4gb = [math]::Floor($availmem/4)
 $m8gb = [math]::Floor($availmem/8)
 $l16gb = [math]::Floor($availmem/16)
 $xl32gb = [math]::Floor($availmem/32)
 $body = "$vc_conn, $vc_cluster, $vc_cluster_hosts, $vmx, $vc_cluster_pcpu, $vc_cluster_pmem, $vcpu_total, $vmem_total, $cpu_ratio, $availmem"
 $body += ", $sx, $mlx, $xlx, $sy, $mly, $xly, $s4gb, $m8gb, $l16gb, $xl32gb"
 echo "$body"

 $stream.WriteLine("$body")
 }

 Disconnect-VIServer -Confirm:$false
}
 $stream.Close();


#OLD LINES --- SAVE BELOW

#Get-View -ViewType "VirtualMachine" -Property Name `
 #-Filter @{"Runtime.PowerState"="PoweredOn"} `
 #-SearchRoot $(get-view -ViewType "ClusterComputeResource" `
 #-Filter @{"Name"="atl_leostream01"} -Property Name).MoRef | Measure-Object
 #-SearchRoot $(Get-View -ViewType "HostSystem" `
 #-Filter @{"Name"="Hostname"} -Property Name).MoRef | Measure-Object

 
#Get-View -ViewType "VirtualMachine" -Property Name, `
 #-Filter @{"Runtime.PowerState"="PoweredOn"} `
 #-SearchRoot $(get-view -ViewType "ClusterComputeResource" `
 #-Filter @{"Name"="atl_leostream01"} -Property Name).MoRef | Measure-Object

#$vcpu,$vcputotal,$vmem,$vmemtotal,$vmx = 0 
#foreach ($vm in $vms){
#    if ($vm.PowerState -eq "PoweredOff"){
#        continue
#    }
#    $vmx++
#    $vcpu = $vm.NumCpu
#    echo $vcpu
#    $vcputotal = $vcputotal + $vcpu 
#    $vmem = $vm.MemoryGB
#    $vmemtotal = $vmemtotal + $vmem
#}

#echo "vCenter,ClusterName,PCPU,PMEM,VMs,vCPU,vMEM"
#echo $vc_conn.Name,$vc_cluster.Name, $vc_cluster_pcpu, $vc_cluster_pmem,$vmx,$vcputotal,$vmemtotal