## satp rule creation for 3PAR ALUA (host persona 11)
# Usage: Run the script, and provide a vCenter name, and the location of the servers to the get the rule.
# The location can be a folder, cluster, Datacenter, or even a vCenter to apply the rule to every host.

Param ($vcenter=$FALSE, $location=$FALSE)
$timestamp = Get-Date -format "yyyyMMdd-HH.mm"
if ($vcenter -eq $FALSE) { $vcenter = Read-Host "Please enter a Virtual Center name" }
if ($location -eq $FALSE) { $location = Read-Host "Please enter the location of the server or servers to change Q Full options." }

$outputFile = ".\3PAR-Rules-$vcenter-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
"Connecting vCenter servers ..."
Connect-VIServer $vcenter 

foreach($esx in Get-VMhost -Location $location){

$esx | Set-VMHostAdvancedConfiguration -Name Disk.QFullSampleSize -Value 32  -Confirm:$false
$esx | Set-VMHostAdvancedConfiguration -Name Disk.QFullThreshold -Value 4 -Confirm:$false
}
Disconnect-VIServer -Server $vCenter -Confirm:$false -Force:$true
