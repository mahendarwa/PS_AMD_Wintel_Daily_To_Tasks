﻿#####READ BELOW#####
#AUTHOR: GEORGE LIM
###########################
Add-PSSnapin VMware.VimAutomation.Core

#Leostream Provision

#Get hostname prefix
$hprefix = read-host "Enter Hostname prefix only. For example, atlgar-vdi0001, enter atlgar-vdi"
$hstart = read-host "Enter starting number. For ex, create 20 machines: atlgar-vdi2141 to atlgarvdi2160. Enter 2141"
$hend = Read-Host "Enter ending number. For ex,create 20 machines: atlgar-vdi2141 to atlgarvdi2160. Enter 2160"
$vc_server = Read-Host "Enter vCenter hostname"
$vc_cluster = Read-Host "Enter vCenter cluster name"
$vc_respo = Read-Host "Enter resource pool name"
$vc_pgrp = Read-Host "Enter network port group name"
$vc_dstore = Read-Host "Enter datastore name"
$nx_profile = read-host "Enter profile: Small, Medium. Small=2CPU/4GB, Medium=2CPU/8GB"
#$vc_respo = "4GB-GAR"
#$vc_folder = "RHEL5-2CPU4GB"
#$vc_dstore = "nfs-avere-nx"
$vc_dstore = "nfs_atltintri02"

#$vc_dstore = "nfs_avere_chlorine_106"
#$vc_pgrp = "VNet_NXVDI04"
#$vc_pgrp = "VNet_NXVDI06"
#$vc_pgrp = "dvNet_NXVDI05(dvSwitch_leo)"

switch ($nx_profile){

small {
#Profile
$profile = @{"numcpu" = 2 ; "memory" = 4 ; "HDD" = 30 ; "vidmem" = 128; "guestid" = "rhel5_64Guest" }
}
medium {
$profile = @{"numcpu" = 2 ; "memory" = 8 ; "HDD" = 30 ; "vidmem" = 128; "guestid" = "rhel5_64Guest" }
}
defaul {
$profile = @{"numcpu" = 2 ; "memory" = 4 ; "HDD" = 30 ; "vidmem" = 128; "guestid" = "rhel5_64Guest" }
}
}

echo $profile
#Connect to vCenter, using passthru authentication, no user/pass required
$vc_conn = Connect-VIServer -Server $vc_server

$macs = @{}
#Loop through and start the provisioning
foreach ($n in $hstart..$hend){
    $n = "{0:D4}" -f $n
    $vmname = "$hprefix$n"
    echo $vmname
    $vm = New-VM -Name $vmname -ResourcePool $vc_respo -Datastore $vc_dstore -Location $vc_folder -NetworkName $vc_pgrp `
    -NumCpu $profile.get_item("numcpu") -DiskGB $profile.get_item("HDD") -MemoryGB $profile.get_item("memory") `
    -guestid $profile.get_item("guestid")
    #VM RECONFIG STEP 1
    $nic = Get-NetworkAdapter -VM $vmname
    Remove-NetworkAdapter -NetworkAdapter $nic -Confirm:$false
    $nic = New-NetworkAdapter -NetworkName $vc_pgrp -VM $vmname -type e1000 -Confirm:$false -StartConnected:$true 
    $macs.add($vmname,$nic.MacAddress)

    $vmview = $vm | Get-View -Property Name, Config.Hardware.Device 
    $vmext = $vm.ExtensionData.Config.Hardware.Device 
    $vidcard = $vmext | where {$_.GetType().Name -eq "VirtualMachineVideoCard"}
    $vmspec = New-Object VMware.Vim.VirtualMachineConfigSpec
    $vmconfig = New-Object VMware.Vim.VirtualDeviceConfigSpec
    $vmconfig.Device = $vidcard
    $vmconfig.device.videoRamSizeInKB = $profile.get_item("vidmem") * 1KB
    $vmconfig.Operation = "edit"
    $vmspec.DeviceChange = $vmconfig
    #Reference (SAVE)
    #$nic = $vmext | where {$_.gettype().name -eq "VirtualE1000"}
    #$nickey = $nic.key
    $vmview.ReconfigVM_Task($vmspec)
   
    
    $nic = $vmview.Config.Hardware.Device | ?{$_.DeviceInfo.Label -eq "Network Adapter 1"}
    $nickey = $nic.key 
    echo $nickey
    $hdd1 = $vmview.Config.Hardware.Device | ?{$_.deviceInfo.label -eq "Hard Disk 1"}
    $hdd1key = $hdd1.key
    echo $hdd1
    $nicboot = New-Object -TypeName vmware.vim.virtualmachinebootoptionsbootableethernetdevice -Property @{"DeviceKey" = $nickey}
    $hdd1boot = New-Object -TypeName vmware.vim.virtualmachinebootoptionsbootablediskdevice -Property @{"DeviceKey" = $hdd1key}
    $cdromboot = New-Object -Type vmware.vim.virtualmachinebootoptionsbootablecdromdevice
    $vmspec = New-Object -TypeName vmware.vim.virtualmachineconfigspec -Property @{ bootoptions = New-Object vmware.vim.virtualmachinebootoptions `
    -Property @{ bootorder = $nicboot } }
    #$vmspec.BootOptions = New-Object vmware.vim.virtualmachinebootoptions
    #$vmspec.BootOptions.BootOrder = $nicboot

  #  $vmview = $vm | Get-View -Property Name,Config.Hardware.Device
    $vmview.reconfigvm_task($vmspec)


   #$vmspec = New-Object VMware.Vim.VirtualMachineConfigSpec 
   #$vmspec.extraConfig += New-Object VMware.Vim.OptionValue 
   #$vmspec.extraConfig[0].key = "bios.bootOrder" 
   #$vmspec.extraConfig[0].value = "ethernet0" 
   #(Get-View $vm.ID).ReconfigVM_Task($vmspec)
   
   
    $vm | Get-VMResourceConfiguration | Set-VMResourceConfiguration -MemReservationGB $profile.get_item("memory")



}
sleep 10
$macs