function Detach-Disk{
param(
[VMware.VimAutomation.ViCore.Impl.V1.Inventory.VMHostImpl]$VMHost,
[string]$CanonicalName
)

$storSys = Get-View $VMHost.Extensiondata.ConfigManager.StorageSystem
$lunUuid = (Get-ScsiLun -VmHost $VMHost | 
where {$_.CanonicalName -eq $CanonicalName}).ExtensionData.Uuid

$storSys.DetachScsiLun($lunUuid)
}
$hostslist = import-csv HostList.csv
$luns = import-csv LunList.csv

foreach ($vmhost in $hostslist){
$hostname=$vmhost.host
write-host �Starting $hostname�
$esx = get-vmhost $hostname
foreach ($lun in $luns){
$naa=$lun.naa
write-host �Detaching LUN $naa from $esx�
detach-disk -vmhost $esx -CanonicalName $naa
write-host �Detach Complete�
}
}