$VC = �atlvcsvm01�
Connect-VIServer $VC

$VLANInfo = foreach($cluster in Get-Cluster){

foreach($esx in (Get-VMHost -Location $cluster)){

foreach($pg in (Get-VirtualPortgroup -VMHost $esx -Standard | Where { $_.Name -NotMatch �-DVUplinks� })){
Select -InputObject $pg @{N=�Cluster�;E={$cluster.Name}},
@{N=�VMHost�;E={$esx.Name}},
@{N=�Portgroup�;E={$pg.Name}},
@{N=�VLAN�;E={$pg.VlanId}}
}

foreach($pg in (Get-VirtualPortgroup -VMHost $esx -Distributed | Where { $_.Name -NotMatch �-DVUplinks� })){
Select -InputObject $pg @{N=�Cluster�;E={$cluster.Name}},
@{N=�VMHost�;E={$esx.Name}},
@{N=�Portgroup�;E={$pg.Name}},
@{N=�VLAN�;E={$pg.ExtensionData.Config.DefaultPortConfig.Vlan.VlanId}}
}
}
}

$VLANInfo | Select VMHost, PortGroup, VLAN | Export-CSV C:\Users\svishwan\Desktop\Scripts\output\vSphere-VLANs.csv
Disconnect-VIServer -Force -Confirm:$False