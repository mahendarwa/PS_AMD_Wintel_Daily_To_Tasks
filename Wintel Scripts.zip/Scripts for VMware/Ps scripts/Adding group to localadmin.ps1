$servers = Get-Content D:\server.txt
"Name`tStatus" | Out-File -FilePath D:\results.txt
foreach ($server in $servers){
 try{
  $adminGroup = [ADSI]"WinNT://$server/Administrators"
  $adminGroup.add("WinNT://amd.com/tools_adm")
  "$server`tSuccess"
  "$server`tSuccess" | Out-File -FilePath D:\results.txt -Append
 }
 catch{
  "$server`t" + $_.Exception.Message.ToString().Split(":")[1].Replace("`n","")
  "$server`t" + $_.Exception.Message.ToString().Split(":")[1].Replace("`n","") | Out-File -FilePath D:\results.txt -Append
 }
}
