﻿    $vcServer = "cybvcsvm01.amd.com"
    $cluster = "SAP-DR_DB"
    $psp = "VMW_PSP_RR"
    #$satp = "VMW_SATP_DEFAULT_AA"
	$satp = "VMW_SATP_ALUA"
    
    #$diskID = "naa.*" # for HP XP Array LUNS
    $diskID = "naa.*" # for HP 3PAR LUNS

    #Prompt for Credentials
    $vcCred = $host.ui.PromptForCredential("VCENTER LOGIN", "Provide VCENTER credentials (administrator privileges)", "", "")
    $esxCred = $host.ui.PromptForCredential("ESX HOST LOGIN", "Provide ESX host credentials (probably root)", "root", "")
 
    #Connect to vCenter 
    Connect-VIServer -Server $vcServer -Credential $vcCred
 
    #Set Roundrobin Policy on specified LUNs and Connect to ESX hosts for IOPS setting 
    foreach ($esxhost in Get-Cluster $cluster | Get-VMHost) {
        write-output $esxhost.Name #host you are connecting to 
 
        #Change Multipathing policy to RoundRobin
        Get-VMHost $esxhost |Get-ScsiLun -LunType "disk"|where {$_.ConsoleDeviceName -like "/vmfs/devices/disks/$diskID*"} |where {$_.MultipathPolicy -ne "RoundRobin"}|Set-ScsiLun -MultipathPolicy "RoundRobin"
 
        #Connect to vCenter
        Connect-VIServer -Server $esxhost -Credential $esxCred
 
        #Connect to ESXcli
        $esxcli = Get-ESXcli
 
        #Go through each storage device where the ID begins with $Diskid
        $esxcli.storage.nmp.device.list() | where {$_.device -match $Diskid}| %{
 
            #Capture the current configuration of the focused storage device
            $configBefore = $esxcli.storage.nmp.psp.roundrobin.deviceconfig.get($_.device)
 
            #Set the IOoperations limit using the currently focused naa ID
            #$esxcli.storage.nmp.psp.roundrobin.deviceconfig.set(0,$configBefore.device,[long]1,"iops",$false)
 
            #Capture the configuration post the set
            $configAfter = $esxcli.storage.nmp.psp.roundrobin.deviceconfig.get($_.device)
 
            #Returns
            $configBefore
            $configAfter
        }
        #Change the default PSP for the specified SATP 
        #$esxcli.nmp.satp.setdefaultpsp($psp,$satp)
 
    } 
    #Disconnect from ESX hosts 
    foreach ($esxhost in Get-Cluster $cluster | Get-VMHost) { 
        Disconnect-VIServer -Server $esxhost.name -Confirm:$false
    } 
 
    #Disconnect from vCenter 
    Disconnect-VIServer $vcServer -Confirm:$false