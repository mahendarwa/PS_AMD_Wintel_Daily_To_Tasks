$vCenterServers = 'atlvcs03','atlvcs04','atlvcsvm01'

Connect-VIServer -Server $vCenterServers

Get-VM | Get-Snapshot |

Select-Object VM, Name, Created, SizeGB,

    @{N='vCenter';E={$_.Uid.Split('@')[1].Split(':')[0]}} |

Export-Csv C:\Desktop\snapshot.csv -NoTypeInformation -UseCulture

Disconnect-VIServer $vCenterServers -Confirm:$false
