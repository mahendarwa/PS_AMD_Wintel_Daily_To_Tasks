﻿$viserver = Read-Host "Enter VI server"
Connect-VIServer $viserver
$dt= get-date -Format yyyy-MM-dd-HHmm
$output="F:\Yns\scripts\output\$($viserver)_NTP_$($dt).csv"
$hosts =  get-vmhost |?{$_.connectionstate -eq "connected" -or $_.connectionstate -eq "Maintenance" }

$info=foreach($hst in $hosts)
{
    Get-VMHost $hst | Select Name,

        @{N='NTP Service Running';E={Get-VMHostService -VMHost $_ | where{$_.Key -eq 'ntpd'} | select -ExpandProperty Running}},
		@{N='NTP Service Policy';E={Get-VMHostService -VMHost $_ | where{$_.Key -eq 'ntpd'} | select -ExpandProperty Policy}},
        @{N='NTP Server(s)';E={(Get-View -Id $_.ExtensionData.ConfigManager.DatetimeSystem).DateTimeInfo.NtpConfig.Server -join ', '}},
		@{Name="Time";Expression={(get-view $_.ExtensionData.configManager.DateTimeSystem).QueryDateTime()}}
   }
 
$info | Export-Csv -NoTypeInformation $output
Disconnect-VIServer -Server $viserver -Confirm:$false -Force:$true