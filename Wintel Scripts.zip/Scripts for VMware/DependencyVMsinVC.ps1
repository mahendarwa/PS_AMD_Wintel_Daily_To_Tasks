﻿$server = Read-Host "Enter the name of the vCenter"
Connect-VIServer $server
#$clstr = Read-Host "Enter the name of the Cluster to check RDM and scsi dependency"
$outputfile1 = ".\$($server)_SCSI_Dependency-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
#$outputfile2 = ".\$($server)-RDM_Dependency-" + (get-date -Format yyyy-MM-dd-HHmm) + ".csv"
#Check for scsi controller sharing
$vmhosts= Get-VMHost | ?{$_.connectionstate -like "Connected" -or "Maintenance"}
$results=foreach($vmhost in $vmhosts)
{
 Get-VMhost $vmhost | Get-VM | Get-ScsiController | ?{$_.BussharingMode -notlike "NoSharing"} | select parent,@{N="VMHost";E={$vmhost}},BusSharingMode,@{N="Cluster";E={$vmhost.parent}}
#check for RDM VMs
#Get-Cluster $clstr | Get-VM | Get-HardDisk -DiskType RawPhysical,RawVirtual | select Parent,Name,@{N="VMhost";E={$_.parent.vmhost}},@{N="Cluster";E={$clstr}} | Export-Csv -NoTypeInformation -Path $outputfile2

}
$results | Export-Csv -NoTypeInformation F:\Yns\scripts\output\$($server)_SCSIDependency.csv



Disconnect-VIServer -Server $server -Confirm:$false -Force:$true