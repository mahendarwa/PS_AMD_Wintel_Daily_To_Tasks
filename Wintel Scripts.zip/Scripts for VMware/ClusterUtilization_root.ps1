﻿$cred = Get-Credential
$vmhosts=get-content F:\Yns\hosts.txt
connect-viserver $vmhosts -Credential $cred
Get-VMHost $vmhosts | select Name,ConnectionState,CpuUsageMhz,MemoryUsageGB,@{N="CPU Utilization";E={[int](($_.CpuUsageMhz/$_.CpuTotalMhz)*100)}},@{N="MemoryUtilization";E={[int](($_.MemoryUsageGB/$_.MemoryTotalGB)*100)}} |  Export-Csv -NoTypeInformation -Path F:\Yns\HostsUtilization.csv
Disconnect-VIServer -Server * -Confirm:$false -Force:$true