﻿ Connect-VIServer atlvcsvm01
 $cluster = Read-Host "Enter the name of the Cluster on which hardening script to be run"
 $esxHosts=get-cluster $cluster | get-vmhost
 $dt=get-date -Format yyyy-MM-dd-HHmm
 $output="F:\Yns\$($cluster)_hardeing_$($dt).csv"
 #$hsts=Get-Content F:\Yns\hosts.txt
 #$esxHosts=Get-VMHost $hsts
$info=foreach($esx in $esxHosts) {
$out = "" | Select VMHost,BiosVersion,BiosReleaseDate,OSversion,PowerPolicy,LockDown,vmk0MTU,vmk1MTU,vmk2MTU,VMFSDSCount,NFSDSCount,Domain,DomainMembershipStatus,NTPServer,NTPServicePolicy,NTPServiceSatus,SSHStaus,SSHPolicy,ShellStaus,ShellPolicy,Device,Driver,DriverVersion,FirmwareVersion,qlnativefcversion,HBAQDepth,MOB,TcpipHeapSize,TcpipHeapMax,MaxQueueDepth, NFSMaxVolumes, NFS41MaxVolumes, DiskQFullThreshold, DiskQFullSampleSize, NFSHeartbeatMaxFailures, NFSHeartbeatFrequency, NFSHeartbeatTimeout, ESXiShellInteractiveTimeOut, ESXiShellTimeOut, ShareForceSalting, DcuiTimeOut,AccountLockFailures, AccountUnlockTime, PasswordQualityControl, ESXiVPsDisabledProtocols,loghost, UseATSForHBOnVMFS5, DiskMaxIOSize
  	$device = Get-VMHost $esx | get-VMHostPciDevice | where { $_.DeviceClass -eq "NetworkController"} | Select-Object -First 1	 
	$view= Get-View -ViewType HostSystem -Filter @{Name=$device.VMHost.Name}
  $out.VMHost = $device.VMHost.Name
  $VMFSDScount=Get-VMHost $esx.Name | Get-Datastore |?{$_.Type -eq "VMFS"}| select Name | Measure-Object | select count
  $NFSDScount=Get-VMHost $esx.Name | Get-Datastore |?{$_.Type -eq "NFS"}| select Name | Measure-Object | select count
  $out.VMFSDScount=$VMFSDScount.count
  $out.NFSDScount=$NFSDScount.count
  $vmk0MTU=Get-VMHostNetworkAdapter -VMHost $esx.Name -Name vmk0 | select MTU
  $out.vmk0MTU=$vmk0MTU.MTU
  $vmk1MTU=Get-VMHostNetworkAdapter -VMHost $esx.Name -Name vmk1 | select MTU
  $out.vmk1MTU=$vmk1MTU.MTU
  $vmk2MTU=Get-VMHostNetworkAdapter -VMHost $esx.Name -Name vmk2 | select MTU
  $out.vmk2MTU=$vmk2MTU.MTU
  $out.LockDown=$esx.ExtensionData.Config.adminDisabled
  $out.BiosVersion = $view.Hardware.BiosInfo.BiosVersion
  $out.BiosReleaseDate = $view.Hardware.BiosInfo.releaseDate
  $out.OSVersion = $view.Summary.Config.Product.FullName
  $out.PowerPolicy=$esx.ExtensionData.Config.PowerSystemInfo.CurrentPolicy.Key
  $domain=Get-VMHostAuthentication -VMHost $esx.Name
  $out.Domain=$domain.Domain
  $out.DomainMembershipStatus=$domain.DomainMembershipStatus
	 $esxcli = $device.VMHost | Get-EsxCli -V2
      $niclist = $esxcli.network.nic.list.Invoke();
      $vmnicId = $niclist | where { $_.PCIDevice -like '*'+$device.Id} | select -First 1
      $out.Device = $vmnicId.Name
	  if ($vmnicId.Name){      
        $vmnicDetail = $esxcli.network.nic.get.Invoke(@{nicname = $vmnicId.Name})
        $out.Driver = $vmnicDetail.DriverInfo.Driver
        $out.DriverVersion = $vmnicDetail.DriverInfo.Version
        $out.FirmwareVersion = $vmnicDetail.DriverInfo.FirmwareVersion
	$esxcli1= Get-EsxCli -VMHost $esx.Name
	$qlnativefcversion=$esxcli1.system.module.get("qlnativefc") | select version
	$out.qlnativefcversion=$qlnativefcversion.version
	$qdhba= $esxcli1.system.module.parameters.list("qlnativefc") | where {$_.Name -eq "ql2xmaxqdepth"}}
	if ($qdhba.value -eq "") {$qdhba="No Data"} else {$qdhba=$qdhba.value}
	$out.HBAQDepth=$qdhba
	$Services=Get-VMHost $esx.Name | get-vmhostservice
      $ntpservices= $services | where {$_.key -eq "ntpd"}
      $SSHservices= $services | where {$_.key -eq "TSM"} 
      $SHELLservices= $services | where {$_.key -eq "TSM-SSH"}
      $ntp= Get-VMHostNtpServer -VMHost $device.VMHost
      $ntpserver= $ntp -join ", "
	$out.NTPServer=$ntpserver
	$out.NTPServicePolicy=$ntpservices.policy
	$out.NTPServiceSatus=$ntpservices.Running
	$out.SSHStaus=$SHELLservices.Running
	$out.SSHPolicy=$SHELLservices.policy
	$out.ShellStaus=$SSHservices.Running
	$out.ShellPolicy=$SSHservices.policy
	
	 $mob=Get-AdvancedSetting -Entity $esx -Name Config.HostAgent.plugins.solo.enableMob | Select Entity, Name, Value
     $TcpipHeapSize=Get-AdvancedSetting -Entity $esx -Name Net.TcpipHeapSize | Select Entity, Name, Value
     $TcpipHeapMax=Get-AdvancedSetting -Entity $esx -Name Net.TcpipHeapMax | Select Entity, Name, Value
     $MaxQueueDepth=Get-AdvancedSetting -Entity $esx -Name NFS.MaxQueueDepth | Select Entity, Name, Value
     $NFSMaxVolumes=Get-AdvancedSetting -Entity $esx -Name NFS.MaxVolumes | Select Entity, Name, Value
	 $NFS41MaxVolumes=Get-AdvancedSetting -Entity $esx -Name NFS41.MaxVolumes | Select Entity, Name, Value
	 $DiskQFullThreshold=Get-AdvancedSetting -Entity $esx -Name Disk.QFullThreshold | Select Entity, Name, Value
	 $DiskQFullSampleSize=Get-AdvancedSetting -Entity $esx -Name Disk.QFullSampleSize | Select Entity, Name, Value
	 $NFSHeartbeatMaxFailures=Get-AdvancedSetting -Entity $esx -Name NFS.HeartbeatMaxFailures | Select Entity, Name, Value
	 $NFSHeartbeatFrequency=Get-AdvancedSetting -Entity $esx -Name NFS.HeartbeatFrequency | Select Entity, Name, Value
	 $NFSHeartbeatTimeout=Get-AdvancedSetting -Entity $esx -Name NFS.HeartbeatTimeout | Select Entity, Name, Value
	 $ESXiShellInteractiveTimeOut=Get-AdvancedSetting -Entity $esx -Name UserVars.ESXiShellInteractiveTimeOut | Select Entity, Name, Value
	 $ESXiShellTimeOut=Get-AdvancedSetting -Entity $esx -Name UserVars.ESXiShellTimeOut | Select Entity, Name, Value
	 $ShareForceSalting=Get-AdvancedSetting -Entity $esx -Name Mem.ShareForceSalting | Select Entity, Name, Value
	 $DcuiTimeOut=Get-AdvancedSetting -Entity $esx -Name UserVars.DcuiTimeOut | Select Entity, Name, Value
	 $AccountLockFailures=Get-AdvancedSetting -Entity $esx -Name Security.AccountLockFailures | Select Entity, Name, Value
	 $AccountUnlockTime=Get-AdvancedSetting -Entity $esx -Name Security.AccountUnlockTime | Select Entity, Name, Value
	 $PasswordQualityControl=Get-AdvancedSetting -Entity $esx -Name Security.PasswordQualityControl | Select Entity, Name, Value
	 $ESXiVPsDisabledProtocols=Get-AdvancedSetting -Entity $esx -Name UserVars.ESXiVPsDisabledProtocols | Select Entity, Name, Value
	 $loghost=Get-AdvancedSetting -Entity $esx -Name Syslog.global.logHost | Select Entity, Name, Value
	 $UseATSForHBOnVMFS5=Get-AdvancedSetting -Entity $esx -Name VMFS3.UseATSForHBOnVMFS5 | Select Entity, Name, Value
	 $DiskMaxIOSize=Get-AdvancedSetting -Entity $esx -Name Disk.DiskMaxIOSize | Select Entity, Name, Value
	 
	 
	 $out.VMHost=$esx.Name
	 $out.MOB=$mob.value
	 $out.TcpipHeapSize=$TcpipHeapSize.value
$out.TcpipHeapMax=$TcpipHeapMax.value
$out.MaxQueueDepth=$MaxQueueDepth.value
$out.NFSMaxVolumes= $NFSMaxVolumes.value
$out.NFS41MaxVolumes= $NFS41MaxVolumes.value
$out.DiskQFullThreshold= $DiskQFullThreshold.value
$out.DiskQFullSampleSize= $DiskQFullSampleSize.value
$out.NFSHeartbeatMaxFailures= $NFSHeartbeatMaxFailures.value
$out.NFSHeartbeatFrequency= $NFSHeartbeatFrequency.value
$out.NFSHeartbeatTimeout= $NFSHeartbeatTimeout.value
$out.ESXiShellInteractiveTimeOut= $ESXiShellInteractiveTimeOut.value
$out.ESXiShellTimeOut= $ESXiShellTimeOut.value
$out.ShareForceSalting= $ShareForceSalting.value
$out.DcuiTimeOut= $DcuiTimeOut.value
$out.AccountLockFailures= $AccountLockFailures.value
$out.AccountUnlockTime= $AccountUnlockTime.value
$out.PasswordQualityControl= $PasswordQualityControl.value
$out.ESXiVPsDisabledProtocols= $ESXiVPsDisabledProtocols.value
$out.loghost= $loghost.value
$out.UseATSForHBOnVMFS5= $UseATSForHBOnVMFS5.value
$out.DiskMaxIOSize= $DiskMaxIOSize.value
$out
	 
 }
  
 $info| Export-Csv $output -NoTypeInformation