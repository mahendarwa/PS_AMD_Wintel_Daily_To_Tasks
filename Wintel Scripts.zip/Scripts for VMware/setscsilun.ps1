﻿(" ")
("This Script will set path policy for the luns on hosts to MRU.")
("You will need to provide a .csv file with the hosts and lun naa ids.")
(" ")
$server = Read-Host "Enter the name of the vCenter"
$filename = Read-Host "Enter the name of the .csv file with the with the hosts and lun naa ids"

$luns = Import-Csv .\$filename

Connect-VIServer $server

"Setting PSP for LUN $($luns.canonicalname) on host $($luns.hostname)"
Get-ScsiLun -CanonicalName $luns.canonicalname -VmHost $luns.hostname |?{ $_.MultipathPolicy -notlike "RoundRobin" } |Set-ScsiLun -MultipathPolicy RoundRobin
#Get-ScsiLun -CanonicalName $luns.canonicalname -VmHost $luns.hostname

Disconnect-VIServer -Server $server -Confirm:$false -Force:$true